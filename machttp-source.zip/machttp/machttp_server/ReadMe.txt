Read Me!
--------

Getting Started with MacHTTP source code
----------------------------------------

First, and foremost, this is an "historical" piece of software. It was originally
authored in 1993 and has remained untouched since 1995, when MacHTTP 3.x turned into
WebSTAR 1.0. Furthermore, it is based on software written as early as 1988, so please 
bear with some of the anachronisms old, techniques, and just plain wrong stuff you'll 
find in the code. It's the goal of MacHTTP.Org and the people working on MacHTTP to 
fix all this stuff, so please help!!!

IMPORTANT! This version of the project will build with Metrowerks CodeWarrior 11.
This was the last version of CodeWarrior that MacHTTP was ever built with and all
versions of CodeWarrior Pro have problems that require significant code rework. If you
do not have CodeWarrior 11 but want to work with the source code, please send a note
to the MacHTTP mailing list. Info can be found at www.machttp.org.

Building
--------

If you have a stock installation of CodeWarrior 11, all you'll need to do is open the
MacHTTP.mcp file and build it. Then open the MacHTTP_PPC.mcp project, build it, and run
the resulting fat binary.

Note that you may need to "Reset File Paths" before building to avoid incorporating
incompatible MacTCP headers into the compiler's search paths.