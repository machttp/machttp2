/** FILE: TTY_Messages.c **/
/** Manage scrolling message area **/
/******************************************************
 *
 * Lawyer stuff:
 *
 * MacHTTP 2.x, source code
 * Copyright �1993-2001 Chuck Shotton
 * All Rights Reserved.
 *
 * This source code is made available under the terms of the MacHTTP Source License.
 * This license grants you the right to use the source code to create new versions
 * of and derivative works from the original MacHTTP source code. Under the terms of
 * this license, any modifications made to the source code must be made available in
 * source code form to the general public and the MacHTTP.Org organization. You may not
 * redistribute source code or binary versions of the MacHTTP application that make use of
 * the MacHTTP name, logo, or icons without the expressed written consent of MacHTTP.Org
 * or Chuck Shotton.
 *
 * MacHTTP is a trademark of Chuck Shotton. Permission is granted
 * to MacHTTP.Org and its assignees use the MacHTTP name, logo, and icons.
 * Any use not authorized by MacHTTP.Org or Chuck Shotton is prohibited.
 *
 * Additional information can be found at http://www.machttp.org/
 *
 ******************************************************
 * Modifications:
 *
 * 03/01/01 - cshotton - initial verison
 * 11/18/01 - rpatters1 - modernized and de-linted
 * 11/19/01 - rpatters1 - made MPW-compatibile
 ******************************************************/
#include "config.h"

#define DEBUG 0 /*turn on for main program*/

#include <MacTypes.h>
#include <MacMemory.h>
#include <MacWindows.h>
#include <Controls.h>
#include <ControlDefinitions.h>
#include <Toolutils.h>
#include <Fonts.h>
#include <TextEdit.h>
#include <Scrap.h>

#include <cstdio>
#include <cstring>

#include "Template.h"
#include "TTY_Messages.h"

static short MSG_FONT = kFontIDMonaco;
static short MSG_FONT_SIZE = 9;

#define MSG_SIZE 1024  /*** Increase for larger messages ***/

static Rect msgBounds;
static Rect topBounds;

static short lineIndex;
static char topLine[100];

#define maxTElines 300	/*Max lines in TErec before deletion*/
#define minTElines 200	/*Number of lines in TErec after deletion*/
#define maxint		32767


static TEHandle  msgEdit;	/*TErec for one and only message area*/
static WindowPtr ttyWin;	/*Window containing the message area*/
static Rect      destRect;	/*Destination Rect for TE stuff*/
static Rect	  viewRect;	/*TE view rectangle */
static short		  fontNum;	/*Font number of Venice 12 */
static Rect	origR;		/*Original bounds rect passed to TTY_Init...*/
static ControlHandle scrollH;
static short wc, hc;
static FontInfo finfo;
static short TTY_LINES;

static ControlActionUPP trackingUPP;

/****************************/


void TTY_Die()
{
	ExitToShell();
}

/****************************/

void TTY_ScrollToEnd()
{
#if INTERACTIVE
short	freeChars;

	freeChars = 32000-(**msgEdit).teLength;
	if (freeChars<8000) 
	{
		TESetSelect(0, 10000, msgEdit);
		TEDelete(msgEdit);
	}/**/
	TESetSelect(32767, 32767, msgEdit);
	TESelView(msgEdit);
	TTY_AdjustScroll();
#endif
}

/********************************/

void TTY_Resize()
{
Rect tr;
#if INTERACTIVE
	origR = ttyWin->portRect;
	origR.top += STAT_AREA_HEIGHT;
	origR.right -= 15;
	SetRect(&msgBounds,origR.left,origR.top,origR.right,origR.bottom);
	destRect = msgBounds;
	SetPort(ttyWin);
	viewRect = destRect;
	InsetRect(&viewRect,0,4);
	InsetRect(&destRect,4,4);
	(**msgEdit).viewRect = viewRect;
	(**msgEdit).destRect = destRect;
	TTY_LINES = ((**msgEdit).viewRect.bottom - (**msgEdit).viewRect.top) / (**msgEdit).lineHeight;
	tr = origR;
	tr.top -= 2;
	tr.bottom -= 14;
	tr.left = tr.right;
	tr.right = tr.left+16;
	MoveControl(scrollH,tr.left,tr.top);
	SizeControl(scrollH,tr.right-tr.left,tr.bottom-tr.top);
	ShowControl(scrollH);
	TTY_ScrollToEnd();
	TEUpdate(&msgBounds,msgEdit);
#endif
}

/****************************/

void TTY_Activate(short active)
{
#if INTERACTIVE
	if (active) {
		HiliteControl ( scrollH, 0 );
		TEActivate (msgEdit);
	}
	else {
		HiliteControl ( scrollH, 255 );
		TEDeactivate (msgEdit);
	}
#endif
}

/**********************/
void TTY_InitMessages(WindowPtr theWin, Rect r, short font, short font_size, short scroll_bar)
/* Init for programs with windows already */
{
short winw, winh;
Rect tr;
	origR = r;
#if INTERACTIVE
	if (scroll_bar) origR.right -= 15;
	SetRect(&msgBounds,origR.left,origR.top,origR.right,origR.bottom);
	lineIndex = 0;
/**/
	MSG_FONT = font;
	MSG_FONT_SIZE = font_size;
	ttyWin = theWin;
	destRect = msgBounds;
	SetPort(ttyWin);
	viewRect = destRect;
	InsetRect(&viewRect,0,4);
	InsetRect(&destRect,4,4);
	TextFont(MSG_FONT);
	TextSize(MSG_FONT_SIZE);
	msgEdit = TENew(&destRect, &viewRect);
	(**msgEdit).crOnly = 1;			
	TESetAlignment(0, msgEdit);			
	TEAutoView(1, msgEdit);
	//TESetSelect (32767, 32767, msgEdit);
	TTY_LINES = ((**msgEdit).viewRect.bottom - (**msgEdit).viewRect.top) / (**msgEdit).lineHeight;
	
	trackingUPP = NewControlActionProc(TTY_TrackScroll);
	
	if (scroll_bar) {
		/* set up scroll bar */
		tr = origR;
		tr.top -= 2;
		tr.bottom -= 14;
		tr.left = tr.right;
		tr.right = tr.left+16;
		
		scrollH = NewControl ( ttyWin, &tr, nil, TRUE, 0, 0, 0, scrollBarProc, 0 );
		if (!scrollH) Error((char *)"\p can't make scroll bar");
		TTY_Activate(TRUE);
		
		wc = finfo.widMax;
		hc = finfo.ascent + finfo.descent + finfo.leading;
		winw = wc * 80 + 10;
		winh = hc * 24 + finfo.descent;
		EraseRect(&(ttyWin->portRect));
	}
#endif
}

/*********************/

void TTY_RedrawMessages()
/*repaint the message area*/
{
Rect r;
#if INTERACTIVE
	SetPort(ttyWin);
	r=msgBounds;
	InsetRect(&r,0,-1);
	EraseRect(&r);
	InsetRect(&r,-1,-1);
	FrameRect(&r);
	
	(**msgEdit).txFont = MSG_FONT;
	TEUpdate(&viewRect, msgEdit);
	DrawControls ( ttyWin );
#endif
}

/*********************/

void TTY_WriteMessage(char *str, short cr)
/** writes a message to the debug window, adding a CR at the end **/
{
short freeChars,len;
#if INTERACTIVE
	SetPort(ttyWin);
	freeChars = 32000-(**msgEdit).teLength;
	len = strlen (str);
	if (len>freeChars) len=freeChars;
	
	TESetSelect(maxint, maxint, msgEdit);
	TEInsert(str, len, msgEdit);
	if (len==freeChars)
		TEInsert (".....", 5, msgEdit);
	if (cr)
		TEInsert ("\r", 1, msgEdit);

	TTY_ScrollToEnd();
#endif
}

/**********************/

void TTY_ClearMessages()
/** clear out top line and message area*/
{
#if INTERACTIVE
	TESetSelect(0, 32767, msgEdit);
	TEDelete(msgEdit);
#endif
}


/**********************/

void TTY_Click()
/*wait for a mouse click*/
{
EventRecord event;
#if INTERACTIVE
	while (!Button())
		if (EventAvail(everyEvent,&event))
			;
	while (Button())
		;
#endif
}

/**********************/

short TTY_Lines()
{
#if INTERACTIVE
	return (**msgEdit).nLines;
#endif
}

/**********************/

void TTY_ScrollMessages(short delta)
{
#if INTERACTIVE
	TEScroll ( 0, (short) (-delta * (**msgEdit).lineHeight), msgEdit );
#endif
}

/**********************/

void TTY_Scroll(short dv)
{
#if INTERACTIVE
short cur, max;
	cur = GetControlValue ( scrollH );
	max = GetControlMaximum ( scrollH );
	
	if (dv>0) {
		if (cur+dv<=max)
			TTY_ScrollMessages(dv);
		else
			TTY_ScrollMessages(dv=max-cur);
	}
	else {
		if (cur+dv>=0)
			TTY_ScrollMessages(dv);
		else
			TTY_ScrollMessages(dv=-cur);
	}
	SetControlValue ( scrollH, dv+cur );
#endif
}

/**********************/

pascal void TTY_TrackScroll(ControlHandle PARM_UNUSED(h), short part)
{
#if INTERACTIVE
		switch (part) {
		
			case kControlUpButtonPart:
				TTY_Scroll(-1);
				break;
				
			case kControlDownButtonPart:
				TTY_Scroll(1);
				break;
				
			case kControlPageUpPart:
				TTY_Scroll(-TTY_LINES);
				break;
				
			case kControlPageDownPart:
				TTY_Scroll(TTY_LINES);
				break;
			
			case kControlIndicatorPart:
				break;
		}
#endif
}

/**********************/

void TTY_HandleScroll(EventRecord *event)
{
#if INTERACTIVE
short part;
ControlHandle h;
short before, after, shiftDown;
Rect teRect;
Point pt;
	SetPort(ttyWin);
	pt = event->where;
	GlobalToLocal(&pt);
	
	teRect= (**msgEdit).viewRect;
	if ( PtInRect(pt, &teRect) ) {
		/* see if we need to extend the selection */
		shiftDown = (event->modifiers & shiftKey) != 0;	/* extend if Shift is down */
		TEClick (pt,(Boolean) shiftDown, msgEdit);
		return;
	}
	else {
		part = FindControl ( pt, ttyWin, &h );
		if (part) {
			if (h==scrollH) {
				if (part != kControlIndicatorPart)
					TrackControl(h, pt, trackingUPP);
				else {
					before = GetControlValue ( scrollH );
					if (TrackControl(h, pt, NULL)) {
						after = GetControlValue ( scrollH );
						if (after-before) {
							TTY_ScrollMessages(after-before);
						}
					}
				}
			}
		}
	}
#endif
}

/**********************/

void TTY_AdjustScroll()
{
#if INTERACTIVE
short lines;
	lines = TTY_Lines();
	lines = lines>TTY_LINES ? lines-TTY_LINES : 0;
	SetControlMaximum ( scrollH, lines );
	SetControlValue ( scrollH, lines );
#endif
}

/**********************/

void TTY_Idle()
{
#if INTERACTIVE
	TEIdle (msgEdit);
#endif
}

/**********************/

void TTY_Copy()
{
#if INTERACTIVE
	ZeroScrap ();
	TECopy (msgEdit);
	TEToScrap ();
#endif
}