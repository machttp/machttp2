/*globals.c*/
/******************************************************
 *
 * Lawyer stuff:
 *
 * MacHTTP 2.x, source code
 * Copyright �1993-2001 Chuck Shotton
 * All Rights Reserved.
 *
 * This source code is made available under the terms of the MacHTTP Source License.
 * This license grants you the right to use the source code to create new versions
 * of and derivative works from the original MacHTTP source code. Under the terms of
 * this license, any modifications made to the source code must be made available in
 * source code form to the general public and the MacHTTP.Org organization. You may not
 * redistribute source code or binary versions of the MacHTTP application that make use of
 * the MacHTTP name, logo, or icons without the expressed written consent of MacHTTP.Org
 * or Chuck Shotton.
 *
 * MacHTTP is a trademark of Chuck Shotton. Permission is granted
 * to MacHTTP.Org and its assignees use the MacHTTP name, logo, and icons.
 * Any use not authorized by MacHTTP.Org or Chuck Shotton is prohibited.
 *
 * Additional information can be found at http://www.machttp.org/
 *
 ******************************************************
 * Modifications:
 *
 * 3/1/01 - cshotton - initial verison
 ******************************************************/
#include "config.h"

#include <MacWindows.h>
#include <Files.h>

#include "constants.h"
#include "global_types.h"
#include "globals.h"

/*globals.c*/
ContentType defaultDocType = FILE_BINARY;
char default_html[256];
char error_html[256];
char error_html_mime_type [MIME_TYPE_SIZE];
ContentType error_content_type;
char noaccess_html[256];
char noaccess_html_mime_type [MIME_TYPE_SIZE];
ContentType noaccess_content_type;

MinimalTCPStream default_info, error_info, noaccess_info;

char footer_html[256];
char footer_html_mime_type [MIME_TYPE_SIZE];
ContentType footer_content_type;
char defaultMIMEType [MIME_TYPE_SIZE];
char doc_root[256];
char log_file[256];

unsigned short kHTTPPort = 80;
short MAX_STREAMS = 8;
short MAX_TIMEOUT = 180;
short MAX_LISTENS = 5;
short PIG_DELAY = 30;
long DUMP_BUF_SIZE = 10240;	/* Output chunk size for text file transmissions */

Boolean gCancel = false;	/* this is set to true if the user cancels an operation */
unsigned long lastLogCut = 0;	// last time in ticks the log file was cut
unsigned long logCutInterval = 0;	// interval to next time in ticks for the log file to be cut

short debugLevel = 0;
long totalConnections;
short  currConnections, highConnections, busyConnections, deniedConnections, timeoutConnections;
short  currListens;
short refuseConnections=0;
unsigned long maxMem;
unsigned long connectionID;
long gHasComponents;
short inForeground;
short hideInBack = 0;

short logging, no_dns;
WindowPtr theWin;
Rect theWinDefaultRect;
short done;
short running_AUX;
short threadsOK = FALSE;

unsigned long foregroundTicks = 1;	//values passed to WaitNextEvent
unsigned long backgroundTicks = 5;
unsigned short gUseThreads = 0;		//override for whether or not threads are to be used

FSSpec gServerRootFS;				//top level server folder FSSpec

char *tcpStreamStateText [terminated+1] = { "inactive", "listening", "reading", "writing", 
		"still_writing", "closing", "closed", "terminated"};