/*HTTP_Threads.c*/
/******************************************************
 *
 * Lawyer stuff:
 *
 * MacHTTP 2.x, source code
 * Copyright �1993-2001 Chuck Shotton
 * All Rights Reserved.
 *
 * This source code is made available under the terms of the MacHTTP Source License.
 * This license grants you the right to use the source code to create new versions
 * of and derivative works from the original MacHTTP source code. Under the terms of
 * this license, any modifications made to the source code must be made available in
 * source code form to the general public and the MacHTTP.Org organization. You may not
 * redistribute source code or binary versions of the MacHTTP application that make use of
 * the MacHTTP name, logo, or icons without the expressed written consent of MacHTTP.Org
 * or Chuck Shotton.
 *
 * MacHTTP is a trademark of Chuck Shotton. Permission is granted
 * to MacHTTP.Org and its assignees use the MacHTTP name, logo, and icons.
 * Any use not authorized by MacHTTP.Org or Chuck Shotton is prohibited.
 *
 * Additional information can be found at http://www.machttp.org/
 *
 ******************************************************
 * Modifications:
 *
 * 03/01/01 - cshotton - initial verison
 * 11/17/01 - rpatters1 - modernized and de-linted
 * 01/14/02 - instantware - switch to threaded multitasking
 * 01/14/02 - instantware - immediately terminates Code Red requests
 * 02/10/02 - instantware - call only YieldToAnyThread() at the end of HTTP_Thread()
 ******************************************************/
#include "config.h"
#include <cstdio>
#include <cstring>
#include <ctime>

#include <MacTypes.h>
#include <MacMemory.h>
#include <MacWindows.h>
#include <Files.h>
#include <Controls.h>
#include <Dialogs.h>
#include <Fonts.h>
#include <Events.h>
#include <AppleEvents.h>
#include <Gestalt.h>
#include <Threads.h>
#include <ToolUtils.h>

#include "MacTCPCommonTypes.h"
#include "TCPPB.h"
#include "TCPHi.h"
#include "TTY_Messages.h"
#include "Template.h"
#include "http.h"
#include "HTTP_Scripts.h"
#include "HTTP_Response.h"
#include "StatusGraphs.h"
#include "HTTP_Properties.h"
#include "HTTP_IPCaching.h"
#include "Logic.h"
#include "HTTP_Threads.h"

#include "globals.h"

static long threadResult;

/**********************************************/

void TLogInitStream (TCPStreamPtr stream)
{
ThreadID tid;
	if (stream) {
		tid = stream->thread_id;
		memset (stream, 0, sizeof (TCPStream));
		stream->thread_id = tid;
		
		stream->stream = 0;
		stream->s_event = 0;
		stream->state = inactive;
		//stream->thread_id = 0; //leave this alone. It's set once at startup and shouldn't need to change.
		stream->rblock = NULL;
		stream->remoteHost = 0;
		stream->method = METHOD_UNKNOWN;
		
		stream->request = NULL;
		stream->request_buffer_size = 0;
		stream->request_byte_count = 0;
		stream->post_arg_byte_count = 0;
		
		strcpy (stream->mime_type, "text/html");
		//stream->next = streams->prev = NULL;
		stream->timeout = 0;
		stream->terminate_reason = 0;
		stream->asr_time = 0;
		stream->last_query_time = 0;
		if ((connectionID & 0x0000FFFF) == 65535) //accomodate a potential AppleEvent id problem with 2^16-1 by skipping it
			connectionID++;
		stream->id = connectionID++;
		stream->content_size = 0;
		stream->content_length = 0;
		stream->content_range = NULL;
		stream->commandDone = FALSE;
		stream->is_http10 = FALSE;
		stream->found = 0;
		stream->action = NULL;
		stream->actionTaken = A_UNKNOWN;
		stream->log_this = L_UNKNOWN;
		stream->f = NULL;
		stream->post_args = NULL;
		stream->path_args[0] = '\0';
		stream->reply_str = NULL;
		stream->host_name[0] = stream->user_name[0] = stream->password[0] = stream->content_type[0] =
			stream->from_user[0] = '\0';
		stream->user_agent[0] = '\0';
		stream->url_referer[0] = '\0';
		stream->whichRealm = NULL;
		stream->t_k = 0;
		stream->flags = 0;
		
	}
}

/**********************************************/
void TLogReleaseStream (TCPStreamPtr stream)
{
	if (stream->stream) {
		/*** Close network connection ***/
		ReleaseStream(stream->stream);
		stream->stream = 0;
		stream->s_event = 0;
		stream->state = inactive;
		stream->rblock = NULL;
		if (stream->reply_str) {
			DisposePtr (stream->reply_str);
			stream->reply_str = NULL;
			stream->reply_len = 0;
		}
		HTTP_DisposeContentRange(stream);
	}
}

/**********************************************/

void TDeleteStream(TCPStreamPtr s)
{
	char str[80];
	OSErr err;

	if (!s) {
		TTY_WriteMessage ("ERROR!!! MacHTTP tried to delete a stream that doesn't exist!",TRUE);
		TTY_WriteMessage (" This is a SERIOUS problem. Please restart MacHTTP and notify the author.", TRUE);
		return;
	}
	
/*Check to see if a file is still open by accident. close it!*/
	if (s->f) {
		if (debugLevel) {
			sprintf (str, "Stream %lu had an unclosed file! Type was %d (%s).", s->id, s->fileType, s->mime_type);
			TTY_WriteMessage (str, TRUE);
		}
		fclose (s->f);
	}
	else if (debugLevel) {
		sprintf (str, "Stream %lu, File closed already.", s->id);
		TTY_WriteMessage (str, TRUE);
	}
	
	/*clean up any buffers associated with the stream if they exist*/
//	if (s->post_args) DisposePtr ((Ptr) s->post_args);

	if (s->request) {
		DisposePtr ((Ptr) s->request);
		s->request_buffer_size = 0;
		s->request_byte_count = 0;
		s->post_arg_byte_count = 0;
	}

	if (s->reply_str) {
		DisposePtr (s->reply_str);
		s->reply_str = NULL;
		s->reply_len = 0;
	}
	HTTP_DisposeContentRange(s);

#if THREAD_SUPPORT
	if (threadsOK) {
		err = 0;//DisposeThread (s->thread_id, 0, FALSE);
		if (err != noErr)
		{
			sprintf (str, "Error disposing thread %d", err);
			TTY_WriteMessage (str, TRUE);
		}
	}
#endif

return;

}

#if 0 //dead code
/*********************************************************/

void HTTP_Yield (long thread_id, unsigned long id, TCPStreamState st)
{
char s[256];
	if (st!=1) {
		sprintf (s, "Thread: %ld, Con: %lu, State: %d", thread_id, id, st);
		TTY_WriteMessage (s, TRUE);
	}
	YieldToAnyThread();
}
#endif

/*********************************************************/

unsigned long gDataBeforeListen = 0;

pascal ThreadEntryProcPtr HTTP_Thread (void *threadParam)
{
#if THREAD_SUPPORT
	TCPStreamPtr stream;
	OSErr err;
	byte state;
	unsigned short pending;
	unsigned long bytesRead;
	long remoteHost;
	short remotePort;
	short commandDone, stillListening;
	char s[REQUEST_SIZE+2];
	
	unsigned long bytes;
	short stillWriting;
	
	extern short done;
	
	stream = (TCPStreamPtr) threadParam;
	
	while (!done)
	{
		stream->last_query_time = TickCount (); //we're reusing the somewhat unused last_query_time field here to track the last time this thread got CPU time

		switch (stream->state)
		{
			case inactive:
				TDeleteStream (stream);
				
				/*queue a new listen*/
				TLogInitStream (stream);
				err = LogOpenPassive (stream);
				if (err) {
					sprintf (s, "####Error %s, TLogOpenPassive", err);
					TTY_WriteMessage (s, TRUE);
				}
				else {
					currListens++;
					stillListening = TRUE;
				}

				break;
			
			case listening:
				stream->flags |= STREAM_FLAG_LISTEN;
				
				if (StreamIsTerminated (stream)) { //transitions to state terminated if true
					stream->flags |= STREAM_FLAG_LISTEN_TERMINATE;
					break;
				}
					
				if ((stream->rblock)->ioResult <= 0 || stream->s_event != 0) { /*got a connection*/
					
					if (stream->s_event == TCPDataArrival) { //this is a special case that MAY not be correct to allow in as a connection. worst case should be a timeout/
						gDataBeforeListen++;
						stream->flags |= STREAM_FLAG_LISTEN_DATA;
					}
					else if (stream->s_event != 0) {
						stream->flags |= STREAM_FLAG_LISTEN_OTHEREVT;
					}
						
#if AUX_SUPPORT		//obsolete code for A/UX removed						
					stillListening = FALSE;
					
					if (running_AUX) {
						err = StreamStatus (stream->stream, &state, &pending);
						if (debugLevel) {
							sprintf (s, "Con: %lu Stream Status (L) err=%d", stream->id, err);
							TTY_WriteMessage(" ", TRUE);
							TTY_WriteMessage(s, TRUE);
						}
						
						if (err == connectionDoesntExist)
							stillListening = TRUE;
							
						LogReportState (stream, "Listening", state, pending);
					}
					
					if (!stillListening) {
#endif
						err = AsyncGetConnectionData (stream->rblock, &remoteHost, &remotePort);
						stream->remoteHost = remoteHost;
						HTTP_IPAddrToName(remoteHost, stream->host_name);
						if (debugLevel) {
							sprintf (s, "Connected %lu to %s", stream->id, stream->host_name);
							TTY_WriteMessage(s, TRUE);
						}
						stream->rblock = NULL;
						LogStartTimeout (stream, MAX_TIMEOUT); /*start the timer up*/
						currListens--;
						
						/*too busy to queue listen?*/
						if (currConnections>=(MAX_STREAMS)) {
							if (debugLevel) {
								TTY_WriteMessage (" ", TRUE);
								TTY_WriteMessage ("Server is busy.", TRUE);
							}
							
							stream->is_http10 = TRUE;
							HTTP_Respond (stream, R_TOO_BUSY, "Sorry. The server is too busy now.");
							
							sprintf(s,"Closing connection. Too busy.");
							TTY_WriteMessage(s, TRUE);
							currConnections++;
							busyConnections++;
							stream->state = closing;
							stream->flags |= STREAM_FLAG_LISTEN_BUSY;
						}
						else if (refuseConnections) {
							if (debugLevel) {
								TTY_WriteMessage(" ", TRUE);
								TTY_WriteMessage ("Connection Refused.", TRUE);
							}
							
							HTTP_RefusedResponse (stream);
							currConnections++;
							stream->state = closing;
						}
						else { /*not too busy, open a new "listen"*/
							currConnections++;
							stream->state = reading;
							stream->flags |= STREAM_FLAG_LISTEN_READING;
						}
						LogUpdateStats();
#if AUX_SUPPORT
					}
#endif
				}
				break;
				
			case reading:
				if (StreamIsTerminated (stream))
					break;
					
				pending = state = commandDone = 0;
				err = StreamStatus (stream->stream, &state, &pending);
				if (err) {
					if (debugLevel) {
						sprintf (s, "Con: %lu Stream Status (1) err=%d", stream->id, err);
						TTY_WriteMessage(" ", TRUE);
						TTY_WriteMessage(s, TRUE);
					}
					if (err==connectionDoesntExist)
						stream->state = closed;
				}
				else {
					LogReportState (stream, "Reading", state, pending);
					
					if (pending) { /*there's data to read*/
						LogStartTimeout (stream, MAX_TIMEOUT); /*reset the timer*/
						bytesRead = 0;
						err = ReadData (stream->stream, s, &bytesRead);
						if (err) {
							if (err == connectionClosing) {
								TTY_WriteMessage("###early exit!!!", TRUE);
								stream->state = closing;
							}
							else {
								sprintf (s, "Error reading data %d", err);
								TTY_WriteMessage(s, TRUE);
							}
						}
						else { /*read was OK*/
							stream->commandDone = HTTP_AddData(s, bytesRead, stream);
							LogStartTimeout (stream, MAX_TIMEOUT); /*reset the timer*/
						}
					}
					/*else*/ 
					if (stream->commandDone) {
						//code red type checks here instead of inside ReadData
						err = HTTP_CheckTriggers (stream);
						
						if (err == CodeRedErr) {
							//sprintf (s, "Code Red type request %05ld ignored, connection to %s closed.", stream->id, stream->host_name);
							//TTY_WriteMessage(s, TRUE);
							err = CloseStreamConnection(stream->stream);
							stream->state = closed;
							stream->log_this = L_LOG_IT;
							stream->found = 3; //ultimately will represent a disconnect action, but is PRIV for now
							safecpy (stream->url_fname, "Windows_Virus_Request", ARG_SIZE);
							stream->search_args [0] = '\0';
						}
						else {					
							stream->state = writing;
						}
					}
				}
				
				if (LogTimeout(stream)) {
					stream->state = closing; /*clean up defunct connections*/
					if (debugLevel) {
						sprintf (s, "Reading Timeout stream %lu", stream->id);
						TTY_WriteMessage(s, TRUE);
					}
				}
				
				break;
	
			case writing:				
				if (StreamIsTerminated (stream))
					break;
					
				HTTP_DoGetCommand(stream);

				if (stream->fileType == FILE_VERSION) { /*report the server version info*/
					sprintf (s, "<title>MacHTTP Version</title>%s<br>%s<br>%s version<p>", COPYRIGHT1, COPYRIGHT2, PROCESSOR_STRING);
					LogMakeStatusReport (s);
					strcat (s,HTTP_RESP_2CRLF);
					err = SendData(stream->stream, s, (unsigned short) strlen (s),false);
#if REMOTE_TCP_REPORT
					LogTCPIPReport (stream);
#endif
					stream->log_this = L_LOG_IT;
					stream->state = closing;
				}
				else {
					if (debugLevel) {
						sprintf (s, "File Found = %d", stream->found);
						TTY_WriteMessage(s, TRUE);
					}
					if (stream->found==2) { /*security violation*/
						if (stream->method != METHOD_AUTHORIZE) {
							deniedConnections++;
							LogUpdateStats();
						}
					}
					bytes = LogDumpFile (stream); /*open and send (part of?) the file*/
					LogStartTimeout (stream, MAX_TIMEOUT); /*reset the time-out*/
					if (stream->state == writing) {
						sprintf (s, "%s\t%s\t%s%s%s\t%ld", 
								stream->found ? (stream->found==1?"OK  ":"PRIV") :"ERR!", 
								stream->host_name, stream->url_fname, stream->search_args[0] ? "?" : "", stream->search_args, bytes);
						HTTP_LogMessage(s);
						stream->log_this = L_LOGGED_IT;
						stream->state = closing;
					}
					/*else the state has been changed to still_writing internal to LogDumpFile*/
					else stillWriting = TRUE;
				}

				if (LogTimeout(stream)) {
					stream->state = closing; /*clean up defunct connections*/
					if (debugLevel) {
						sprintf (s, "Writing Timeout stream %lu", stream->id);
						TTY_WriteMessage(s, TRUE);
					}
				}
				break;
			
			case still_writing:
				if (StreamIsTerminated (stream))
					break;
					
				if (!LogStillWriting (stream)) { /*only transition to close if writing is complete*/
					sprintf (s, "%s\t%s\t%s%s%s\t%ld", 
								stream->found ? (stream->found==1?"OK  ":"PRIV") :"ERR!", 
								stream->host_name, stream->url_fname, stream->search_args[0] ? "?" : "", 
								stream->search_args, stream->t_k);
					HTTP_LogMessage(s);
					stream->log_this = L_LOGGED_IT;
					stream->state = closing;
				}
				else {
					if (debugLevel) {
//						sprintf (s,"Still writing %ld", stream->id);
//						TTY_WriteMessage (s, TRUE);
					}
					stillWriting = TRUE;
				}
				
				if (LogTimeout(stream)) {
					stream->state = closing; /*clean up defunct connections*/
					if (debugLevel) {
						sprintf (s, "Writing Timeout stream %lu", stream->id);
						TTY_WriteMessage(s, TRUE);
					}
				}
				break;
				
			case closing:
				LogReportState (stream, "Closing", state, pending);
				if (stream->stream) {
					err = CloseStreamConnection(stream->stream);
					if (err && debugLevel) {
						sprintf (s, "Closing Err (%lu) %d", stream->id, err);
						TTY_WriteMessage(s, TRUE);
					}
				}

				//LogStartTimeout (stream, CLOSE_TIMEOUT); /*hack to fix Mac Mosaic's close problem*/

				/*if (LogTimeout(stream))*/	stream->state = closed;
				break;
			
			case closed:
				if (stream->log_this == L_LOG_IT) {
					sprintf (s, "%s\t%s\t%s%s%s\t%ld", 
							stream->found ? (stream->found==1?"OK  ":"PRIV") :"ERR!", 
							stream->host_name, stream->url_fname, stream->search_args[0] ? "?" : "", stream->search_args, stream->t_k);
					HTTP_LogMessage(s);
					stream->log_this = L_LOGGED_IT;
				}

				err = StreamStatus (stream->stream, &state, &pending);
				if (err) {
					if (err != connectionDoesntExist && debugLevel) {
						if (debugLevel) {
							sprintf (s, "Stream Status (2) err=%d", err);
							TTY_WriteMessage(" ", TRUE);
							TTY_WriteMessage(s, TRUE);
						}
					}
				}
				
				LogReportState (stream, "Closed", state, pending);

				if (pending && !LogTimeout(stream) && state != 0 && stream->s_event!=TCPTerminate ) {
					bytesRead = 0;
					err = ReadData(stream->stream, s, &bytesRead);
					if (err && debugLevel) {
						sprintf (s, "Closed Read error %d", err);
						if (debugLevel) TTY_WriteMessage (s, TRUE);
					}
//					else
//						if (debugLevel) TTY_WriteMessage(s, TRUE);
				}
				else if (state==0 || /*state==12 ||*/ stream->s_event==TCPTerminate || LogTimeout (stream)) { /*closing or terminated*/
					if (LogTimeout(stream)) {
						timeoutConnections++;
						if (debugLevel) {
							sprintf (s, "Timed out %lu", stream->id);
							TTY_WriteMessage(s, TRUE);
						}
					}
					stream->state = terminated;
					if (stream->method != METHOD_UNKNOWN) { /*we must have already done something, log it!*/
						sprintf (s, "%s\t%s\t%s%s%s\t%ld", 
								stream->found ? (stream->found==1?"OK  ":"PRIV") :"ERR!", 
								stream->host_name, stream->url_fname, stream->search_args[0] ? "?" : "", stream->search_args, bytes);
					//	HTTP_LogMessage(s);
					}
				}
				
				break;
				
			case terminated:
				TLogReleaseStream(stream); //sets state to inactive
				currConnections--;
				LogUpdateStats();
				break;
				
			default:
				sprintf (s, "Conn: (%lu(, Unknown HTTP State %d", stream->id, stream->state);
				TTY_WriteMessage(s, TRUE);
				break;
		} /*switch*/
		
		if (stream->state != inactive)  { //proceed directly to respawning the listen if we're inactive, no yield!
			YieldToAnyThread ();
			/*
			//	This code forces all threads to run in order. More useful for debugging that actual operation
			
			if (stream->next == NULL) {
				YieldToAnyThread();
			}
			else {
				YieldToThread ((stream->next)->thread_id);
			}
			*/
		}
	}
#endif
	return nil;
}

/*********************************************************/

short HTTP_ThreadsAreOK ()
{
#if THREAD_SUPPORT
OSErr returnErr;
long res;
short comparebit;

	//return FALSE;
	returnErr = Gestalt (gestaltThreadMgrAttr, &res);
	
	if ( returnErr != noErr ) {
		TTY_WriteMessage ("Thread Manager is not present. Running unthreaded.", TRUE);
		return FALSE;
	}
	
	comparebit = gestaltThreadMgrPresent;
	
	if (BitTst(&res, 31 - comparebit) == FALSE) { /* If Thread Mgr isn't loaded */
		TTY_WriteMessage ("Thread Manager is not present. Running unthreaded.", TRUE);
		return FALSE;
	}
	
	if (gUseThreads) {
		TTY_WriteMessage ("Running Thread Manager version.", TRUE);
		return TRUE;
	}
	else
		return FALSE;
		
#else
	return FALSE;
#endif
}

/*********************************************************/

OSErr HTTP_InitThreads ()
{
	threadsOK = HTTP_ThreadsAreOK ();
#if THREAD_SUPPORT
	if (threadsOK) {
		
	}
	return noErr;
#endif
	return noErr;
}

/*********************************************************/

OSErr HTTP_ShutdownThreads ()
{	
#if THREAD_SUPPORT
	if (threadsOK) {
	}
	return noErr;
#endif
	return noErr;
}

/*********************************************************/

void HTTP_ThreadQueueListens(TCPStreamPtr sptr)
{
OSErr err;
ThreadID nThread;
#if THREAD_SUPPORT
	if (threadsOK) {
		err = NewThread ( kCooperativeThread, (ThreadEntryProcPtr) HTTP_Thread, (void *) sptr, 0x00010000, kCreateIfNeeded, nil, &nThread);
		sptr->thread_id = nThread;
	}
#endif
}

/*********************************************************/
// apparently obsolete and uncalled.
#if 0

void HTTP_ThreadIdle(TCPStreamPtr streams)
{
TCPStreamPtr stream, sptr;
short i;
#if THREAD_SUPPORT
	YieldToAnyThread();
return;

/*************** Dead code below *******************************************/
	/*now see if any dead threads need to be cleaned up*/
	stream = streams;
i=0;
	while (stream) {
		if (i++ > 30) {
			TTY_WriteMessage ("Stuck!", TRUE);
			break;
		}
		if (stream->state == inactive) {
			sptr = stream;
			stream = stream->next;

			TDeleteStream (sptr);			
//			YieldToAnyThread();
		}
		else {
//			YieldToThread(stream->thread_id);
			stream = stream->next;
		}
	}
	
#endif
}
#endif