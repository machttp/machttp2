/*HTTP_Properties.c*/
/******************************************************
 *
 * Lawyer stuff:
 *
 * MacHTTP 2.x, source code
 * Copyright �1993-2001 Chuck Shotton
 * All Rights Reserved.
 *
 * This source code is made available under the terms of the MacHTTP Source License.
 * This license grants you the right to use the source code to create new versions
 * of and derivative works from the original MacHTTP source code. Under the terms of
 * this license, any modifications made to the source code must be made available in
 * source code form to the general public and the MacHTTP.Org organization. You may not
 * redistribute source code or binary versions of the MacHTTP application that make use of
 * the MacHTTP name, logo, or icons without the expressed written consent of MacHTTP.Org
 * or Chuck Shotton.
 *
 * MacHTTP is a trademark of Chuck Shotton. Permission is granted
 * to MacHTTP.Org and its assignees use the MacHTTP name, logo, and icons.
 * Any use not authorized by MacHTTP.Org or Chuck Shotton is prohibited.
 *
 * Additional information can be found at http://www.machttp.org/
 *
 ******************************************************
 * Modifications:
 *
 * 03/01/01 - cshotton - initial verison
 * 11/17/01 - rpatters1 - modernized and de-linted
 * 02/10/02 - instantware - allow PIG_DELAY of zero
 ******************************************************/
#include <cstdio>
#include <cstring>

#include <TextUtils.h>
#include <MacTypes.h>
#include <MacMemory.h>
#include <MacWindows.h>
#include <Files.h>
#include <Controls.h>
#include <AppleEvents.h>
#include <Threads.h>

#include "config.h"
#include "MacTCPCommonTypes.h"
#include "TCPPB.h"
#include "TCPHi.h"
#include "http.h"
#include "TTY_Messages.h"
#include "CTemplateAEVT.h"
#include "HTTP_IPCaching.h"
#include "HTTP_Properties.h"
#include "Template.h"

#include "globals.h"

/********************************************/

Boolean Get_VerboseFlag ()
{
	return (Boolean) debugLevel;
}

/********************************************/

void Set_VerboseFlag (Boolean flag)
{
OSErr err;
	err = SendFlagToSelf (kMyAEVerbose, flag);
}

/********************************************/

Boolean Get_RefuseConFlag ()
{
	return (Boolean) refuseConnections;
}

/********************************************/

void Set_RefuseConFlag (Boolean flag)
{
OSErr err;
	err = SendFlagToSelf (kMyAERefuseConnections, flag);
}

/********************************************/

Boolean Get_SuspendLogFlag ()
{
	return (Boolean) !logging;
}

/********************************************/

void Set_SuspendLogFlag (Boolean flag)
{
OSErr err;
	err = SendFlagToSelf (kMyAESuspendLogging, flag);
}

/********************************************/

Boolean Get_HideWinFlag ()
{
	return (Boolean) hideInBack;
}

/********************************************/

void Set_HideWinFlag (Boolean flag)
{
OSErr err;
	err = SendFlagToSelf (kMyAEHideWindow, flag);
}

/********************************************/

void Get_StatusWinRect (Rect *r)
{
#if INTERACTIVE
Rect temp;
WindowPtr p;
Point pt;
	GetPort (&p);
	SetPort (theWin);
	SetPt (&pt, 0,0);
	LocalToGlobal (&pt);
	SetPort (p);
	
	temp = theWin->portRect;
	OffsetRect (&temp, pt.h, pt.v);
	*r = temp;
#endif
}

/********************************************/

void Set_StatusWinRect (Rect *r)
{
#if INTERACTIVE
Rect temp;
	temp = *r;
	if (Button())
		temp = theWinDefaultRect;
	MoveWindow(theWin,temp.left,temp.top,FALSE);
	SizeWindow(theWin, temp.right-temp.left, temp.bottom-temp.top, (Boolean) TRUE);
	TTY_Resize ();
	DrawOnlyGrowIcon (theWin);
	InvalRect(&theWin->portRect);
#endif
}

/********************************************/

short Get_DumpBufSize ()
{
	return DUMP_BUF_SIZE;
}

/********************************************/

OSErr Set_DumpBufSize (short i)
{
	if (!i)
		DUMP_BUF_SIZE = MAX_DUMP_BUF_SIZE;
	else
		DUMP_BUF_SIZE = i;
		
	if (DUMP_BUF_SIZE<256 || DUMP_BUF_SIZE>MAX_DUMP_BUF_SIZE)
		DUMP_BUF_SIZE = MAX_DUMP_BUF_SIZE;
	return noErr;
}

/********************************************/

short Get_PigDelay ()
{
	return PIG_DELAY;
}

/********************************************/

OSErr Set_PigDelay (short i)
{
	if (0 <= i && i <= 120)
		PIG_DELAY = i;
	else
		PIG_DELAY = 0;

	return noErr;
}

/********************************************/

unsigned long Get_ForegroundTicks ()
{
	return foregroundTicks;
}

/********************************************/

OSErr Set_ForegroundTicks (unsigned long i)
{
	if (0 <= i && i <= 120)
		foregroundTicks = i;
	else
		foregroundTicks = 5;

	return noErr;
}

/********************************************/

unsigned long Get_BackgroundTicks ()
{
	return backgroundTicks;
}

/********************************************/

OSErr Set_BackgroundTicks (unsigned long i)
{
	if (0 <= i && i <= 120)
		backgroundTicks = i;
	else
		backgroundTicks = 5;

	return noErr;
}

/********************************************/

short Get_MaxStreams ()
{
	return MAX_STREAMS;
}

/********************************************/

OSErr Set_MaxStreams (short i)
{
	if (!i)
		MAX_STREAMS = 8;
	else
		MAX_STREAMS = i;
	if (MAX_STREAMS<3 || MAX_STREAMS>46)
		MAX_STREAMS = 8;
	return noErr;
}

/********************************************/

Boolean Get_NoDNS ()
{
	return (Boolean) no_dns;
}

/********************************************/

OSErr Set_NoDNS (Boolean i)
{
	no_dns = i;
	HTTP_EmptyCache();

	return noErr;
}

/********************************************/

short Get_Timeout ()
{
	return MAX_TIMEOUT;
}

/********************************************/

OSErr Set_Timeout (short i)
{
	if (!i)
		MAX_TIMEOUT = 90;
	else
		MAX_TIMEOUT = i;
	if (MAX_TIMEOUT<5 || MAX_TIMEOUT>600)
		MAX_TIMEOUT = 90;
	return noErr;
}

/********************************************/

short Get_MaxListens ()
{
	return MAX_LISTENS;
}

/********************************************/

OSErr Set_MaxListens (short i)
{
	if (!i)
		MAX_LISTENS = 5;
	else
		MAX_LISTENS = i;
	if (MAX_LISTENS<3 || MAX_LISTENS>50)
		MAX_LISTENS = 5;
	return noErr;
}

/********************************************/

void Get_DefaultMIMEType (char *s, Size *max_len)
{
Size len;
	len = strlen(defaultMIMEType);
	len = len<*max_len ? len : *max_len;
	
	strncpy (s, defaultMIMEType, len);
	s [len] = '\0';
	*max_len = len;
}

/********************************************/

void Set_DefaultMIMEType (char *s)
{
Size len;
	len = strlen (s);
	len = len<MIME_TYPE_SIZE-1 ? len : MIME_TYPE_SIZE-1;
	
	strncpy (defaultMIMEType, s, len);
	defaultMIMEType [len] = '\0';
	
}

/********************************************/

unsigned short Get_IPPort ()
{
	return (kHTTPPort);
}

/********************************************/

void Set_IPPort (unsigned short port)
{
	/*@@@ kill all active listens and tell them to re-listen on another port
	  NOT CURRENTLY IMPLEMENTED CORRECTLY!!!
	*/
	kHTTPPort = port;
}

/********************************************/
//private, internal property. Not for user manipulation.
unsigned long Get_LastLogCut ()
{
	return (lastLogCut);
}

/********************************************/

void Set_LastLogCut (unsigned long llc)
{
	lastLogCut = llc;
}

/********************************************/

unsigned long Get_LogCutInterval ()
{
	return (logCutInterval / (24 * 60 * 60));
}

/********************************************/

unsigned long Get_LogCutIntervalSecs ()
{
	return logCutInterval;
}

/********************************************/

void Set_LogCutInterval (unsigned long lci) //in days
{
	logCutInterval = lci * 24 * 60 * 60; //save as seconds
}
