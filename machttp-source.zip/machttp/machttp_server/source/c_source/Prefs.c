/*Prefs.c*/
/******************************************************
 *
 * Lawyer stuff:
 *
 * MacHTTP 2.x, source code
 * Copyright �1993-2001 Chuck Shotton
 * All Rights Reserved.
 *
 * This source code is made available under the terms of the MacHTTP Source License.
 * This license grants you the right to use the source code to create new versions
 * of and derivative works from the original MacHTTP source code. Under the terms of
 * this license, any modifications made to the source code must be made available in
 * source code form to the general public and the MacHTTP.Org organization. You may not
 * redistribute source code or binary versions of the MacHTTP application that make use of
 * the MacHTTP name, logo, or icons without the expressed written consent of MacHTTP.Org
 * or Chuck Shotton.
 *
 * MacHTTP is a trademark of Chuck Shotton. Permission is granted
 * to MacHTTP.Org and its assignees use the MacHTTP name, logo, and icons.
 * Any use not authorized by MacHTTP.Org or Chuck Shotton is prohibited.
 *
 * Additional information can be found at http://www.machttp.org/
 *
 ******************************************************
 * Modifications:
 *
 * 03/01/01 - cshotton - initial verison
 * 11/17/01 - rpatters1 - modernized and de-linted
 ******************************************************/

#include "config.h"
#include <cstring>
#include <ctime>

#include <MacTypes.h>
#include <MacMemory.h>
#include <Controls.h>
#include <Dialogs.h>
#include <Resources.h>
#include <Errors.h>
#include <OSUtils.h>

#include "HTTP_Properties.h"
#include "PW_UI.h"
#include "Prefs.h"
#include "TTY_Messages.h"
#include "Template.h"

#define PREFS_FILE_NAME "\pMacHTTP Settings"

static PrefStruct prefs;
static short resRef;

/*******************************************/

void Prefs_GetPassword (StringPtr name, StringPtr password)
{
Handle rh;
	if (resRef) {
		UseResFile (resRef);
		rh = (Handle) GetNamedResource ('STR ', name);
		if (rh) {
			strncpy ((char *) password,(char *) (*rh), (*rh)[0]+1);
			ReleaseResource (rh);
		}
		else
			password[0]='\0';
	}
	else
		password[0]='\0';
}

/******************************************/

OSErr Prefs_WriteNewPassword (StringPtr name, StringPtr password, short interactive)
{
Handle h;
char temp[256];
	if (resRef) {
		UseResFile (resRef);
		/*see if the resource already exists*/
		Prefs_GetPassword (name, (StringPtr) temp);
		if (temp[0]) {
			if (interactive)
				UI_Error ("\pUnable to add duplicate user name. Delete the old one first.");
			return (-2);
		}
		else {
			h = (Handle) NewHandle (password[0]+2);
			if (h) {
				BlockMove (password, *h, password[0]+1);
				AddResource (h, 'STR ', Unique1ID ('STR '), name);
				//HNoPurge (h);
				ChangedResource (h);
				WriteResource (h);
				ReleaseResource (h);
				
				/*add the name to the list*/
				PtoCstr (name);
				UI_AddToList ((char *) name);
				/*blank out the entry fields*/
				UI_SetUserName ("�");
				UI_SetPassword ("\p");

				return noErr;
			}
		}
	}
	else if (interactive) 
		UI_Error ("\pUnable to write to MacHTTP Settings file.");
	return -1;
}

/******************************************/

OSErr Prefs_DeletePassword (StringPtr name, short interactive)
{
Handle rh;
	if (resRef) {
		UseResFile (resRef);
		rh = GetNamedResource ('STR ', name);
		if (rh) {
			RemoveResource (rh);
			UpdateResFile(resRef);
			DisposeHandle (rh);

			/* update the list */
			if (!interactive) {
				UI_DeleteFromList (name);
			}
			return (noErr);
		}
		else {
			if (interactive) 
				UI_Error ("\pUsername not found! Select a name from the Users list.");
			return -1;
		}
	}
	else {
		if (interactive)
			UI_Error ("\pUnable to access MacHTTP Settings file!");
		return -1;
	}
}

/******************************************/

OSErr Prefs_OpenPrefs()
{
	return noErr;
}

/******************************************/

OSErr Prefs_ReadSettings()
{
PrefStructHandle rh;
	if (resRef) {
		UseResFile (resRef);
		rh = NULL;
		rh = (PrefStructHandle) GetResource ('PREF', kPrefsResID);
		if (rh) {
			if (((PrefStructPtr) *rh)->version <= kPrefsVersion)
				prefs = ** ((PrefStructHandle) rh);
			ReleaseResource ((Handle) rh);
		}
		else
			prefs.version = 0;
	}
	else
		prefs.version = 0;
		
	if (!prefs.version) { /*supply some defaults*/
		prefs.version = kPrefsVersion;
		prefs.verboseFlag = FALSE;
		prefs.refuseFlag = FALSE;
		prefs.suspendFlag = FALSE;
		prefs.hideWinFlag = FALSE;
		Get_StatusWinRect (&prefs.statusWinRect);
		prefs.lastLogCut = time (NULL) + Get_LogCutIntervalSecs ();
	}
	else if (prefs.version < 0x00020400) {	// this version added lastLogCut, so init
		prefs.lastLogCut = time (NULL) + Get_LogCutIntervalSecs ();
	}

	Set_VerboseFlag (prefs.verboseFlag);
	Set_RefuseConFlag (prefs.refuseFlag);
	Set_SuspendLogFlag (prefs.suspendFlag);
	Set_HideWinFlag (prefs.hideWinFlag);
	Set_StatusWinRect (&prefs.statusWinRect);
	Set_LastLogCut (prefs.lastLogCut);
	return noErr;
}

/******************************************/

OSErr Prefs_WriteSettings()
{
PrefStructHandle rh;
	
	prefs.version = kPrefsVersion;
	prefs.verboseFlag = Get_VerboseFlag();
	prefs.refuseFlag = Get_RefuseConFlag();
	prefs.suspendFlag = Get_SuspendLogFlag();
	prefs.hideWinFlag = Get_HideWinFlag();
	Get_StatusWinRect (&prefs.statusWinRect);
	prefs.lastLogCut = Get_LastLogCut ();
	
	if (resRef) {
		UseResFile (resRef);
		rh = NULL;
		rh = (PrefStructHandle) GetResource ('PREF', kPrefsResID);
		if (rh) {
			if (((PrefStructPtr) *rh)->version <= kPrefsVersion) {
				**rh = prefs;
				ChangedResource ((Handle) rh);
				WriteResource ((Handle) rh);
				ReleaseResource ((Handle) rh);
			}
		}
		else { /*no resource yet. Let's make one!*/
			rh = (PrefStructHandle) NewHandle (sizeof (prefs));
			*((PrefStructPtr) *rh) = prefs;
			AddResource ((Handle) rh, 'PREF', kPrefsResID, "\pMacHTTP Prefs");
		}
	}

	return noErr;
}

/******************************************/

OSErr Prefs_Init()
{
short resErr;
short count, i;
short rID;
ResType rType;
Handle rh;
Str255 rName;
OSErr err;
	resErr = noErr;
	
	resRef = OpenResFile (PREFS_FILE_NAME);
	
	if (resRef == -1) { /*couldn't open it*/
		resErr = ResError();
		if (resErr == resFNotFound || resErr == fnfErr) { /*create a new one!*/
			err = Create(PREFS_FILE_NAME,0, CREATOR_CODE,'rsrc');
			CreateResFile (PREFS_FILE_NAME);
			resErr = ResError();
			if (!resErr) {
				resRef = OpenResFile (PREFS_FILE_NAME);
				if (resRef == -1) {/*still couldn't open it*/
					resErr = ResError();
					resRef = 0;
				}
			}
		}
		else resRef = 0;
	}

	if (!resErr) { /*read all the user names and store them in the list*/
		UseResFile (resRef);
		count = Count1Resources ('STR ');
		for (i=1;i<=count;i++) {
			rh = Get1IndResource ('STR ', i);
			if (rh) {
				GetResInfo (rh, &rID, &rType, rName);
				ReleaseResource (rh);
				UI_AddToList ((char *)PtoCstr(rName));
			}
		}
	}
	else TTY_WriteMessage ("Unable to read usernames", TRUE);
	
	if (!resErr) { /*load the preferences*/
		resErr = Prefs_ReadSettings ();
	}
	else TTY_WriteMessage ("Unable to load settings", TRUE);
	
	return resErr;
}

/******************************************/

void Prefs_Shutdown()
{
OSErr err;
	err = Prefs_WriteSettings ();
	//CloseResFile (resRef);
}

/******************************************/
extern short done;
void Unload_Seg()
{
#if BETA_VERSION
unsigned long secs,exp_secs;
DateTimeRec d;
	GetDateTime (&secs);
	d.year = BETA_EXP_YEAR;
	d.month = BETA_EXP_MONTH;
	d.day = BETA_EXP_DAY;
	d.hour = d.minute = d.second = 0;
	DateToSeconds (&d, &exp_secs);
	if (exp_secs<secs) {
		Error ((char*)"\pSorry, this beta has expired. Quitting now.");
		done = TRUE;
	}
#endif
}