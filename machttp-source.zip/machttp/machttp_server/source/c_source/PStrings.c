/******************************************************
 *
 * Lawyer stuff:
 *
 * MacHTTP 2.x, source code
 * Copyright �1993-2001 Chuck Shotton
 * All Rights Reserved.
 *
 * This source code is made available under the terms of the MacHTTP Source License.
 * This license grants you the right to use the source code to create new versions
 * of and derivative works from the original MacHTTP source code. Under the terms of
 * this license, any modifications made to the source code must be made available in
 * source code form to the general public and the MacHTTP.Org organization. You may not
 * redistribute source code or binary versions of the MacHTTP application that make use of
 * the MacHTTP name, logo, or icons without the expressed written consent of MacHTTP.Org
 * or Chuck Shotton.
 *
 * MacHTTP is a trademark of Chuck Shotton. Permission is granted
 * to MacHTTP.Org and its assignees use the MacHTTP name, logo, and icons.
 * Any use not authorized by MacHTTP.Org or Chuck Shotton is prohibited.
 *
 * Additional information can be found at http://www.machttp.org/
 *
 ******************************************************
 * Modifications:
 *
 * 11/11/01 - cshotton - initial verison
 * 11/17/01 - rpatters1 - modernized and de-linted
 ******************************************************/

#include "config.h"

#include <MacMemory.h>

#include <cstring>

#include "PStrings.h"

/******************************/

/* Translate a Pascal source string into a C string */
void p2ccpy(char *dest, StringPtr source)
{
	BlockMove(source + 1, dest, source[0]);
	dest[source[0]] = '\0';
}

/******************************/
/* Translate a C source string into a Pascal string */
/* (truncate as necessary)                          */
void c2pcpy(StringPtr dest, char * source)
{
	short	len;
	
	len = strlen(source);
	if (len > 255)
		len = 255;
	BlockMove(source, dest+1, len);
	dest[0] = len;
}

/******************************/
/* Copy one Pascal string to anothere */
void pstrcpy(StringPtr dst, StringPtr src)
{
	/* copy string */
	BlockMove(src, dst, src[0]+1);
}

/******************************/
/* Concatenate two Pascal strings */
void pstrcat(StringPtr dst, StringPtr src)
{
unsigned char len = 0;
	/* copy string in */
	if (*dst+*src > 255)
		len = 255 - *dst;
	else
		len = *src;
		
	BlockMove(src + 1, dst + *dst + 1, len);
	/* adjust length byte */
	*dst += len;
}

/******************************/
/* Insert one Pascal string at the beginning of another */
void pstrinsert(StringPtr dst, StringPtr src)
{
	/* make room for new string */
	BlockMove(dst + 1, dst + *src + 1, *dst);
	/* copy new string in */
	BlockMove(src + 1, dst + 1, *src);
	/* adjust length byte */
	*dst += *src;
}


/******************************/
Boolean pstreq(StringPtr s1, StringPtr s2)
{
	if (s1 && s2)
		if (s1[0] == s2[0])
			if (!memcmp(&s1[1], &s2[1], s1[0]))
				return true;
	return false;
}
