/** Logic.c (1.1)**/
/******************************************************
 * 
 * Lawyer stuff:
 *
 * MacHTTP 2.x, source code
 * Copyright �1993-2001 Chuck Shotton
 * All Rights Reserved.
 *
 * This source code is made available under the terms of the MacHTTP Source License.
 * This license grants you the right to use the source code to create new versions
 * of and derivative works from the original MacHTTP source code. Under the terms of
 * this license, any modifications made to the source code must be made available in
 * source code form to the general public and the MacHTTP.Org organization. You may not
 * redistribute source code or binary versions of the MacHTTP application that make use of
 * the MacHTTP name, logo, or icons without the expressed written consent of MacHTTP.Org
 * or Chuck Shotton.
 *
 * MacHTTP is a trademark of Chuck Shotton. Permission is granted
 * to MacHTTP.Org and its assignees use the MacHTTP name, logo, and icons.
 * Any use not authorized by MacHTTP.Org or Chuck Shotton is prohibited.
 *
 * Additional information can be found at http://www.machttp.org/
 *
 ******************************************************
 * Modifications:
 *
 * 03/01/01 - cshotton - initial verison
 * 11/17/01 - rpatters1 - modernized and de-linted
 * 11/19/01 - rpatters1 - made MPW-compatibile
 * 11/24/01 - rpatters1 - log most recent connection time per Hostfolder
 * 01/14/02 - instantware - rewritten GiveTime() for better multitasking
 * 01/14/02 - instantware - immediately terminates Code Red requests
 * 01/14/02 - instantware - changed LogDumpBinaryFile() -> added content-range preparation before call of HTTP_Respond()
 * 01/14/02 - instantware - new fread_Ranges()
 * 01/14/02 - instantware - changed LogStillWritingBinary() -> calls fread_Ranges() instead of fread()
 * 01/15/02 - instantware - compatible method for setting EOF in fread_Ranges()
 * 01/16/02 - instantware - dispose stream->content_ranges for non binarys in LogDumpFile()
 * 02/10/02 - instantware - use PIG_DELAY in GiveTime()
 * 02/17/02 - rpatters1 - separated combined assignment/comparison in ContentRange while() stmt
 * 02/22/02 - cshotton - reordered LogInit to prevent unwanted DNS lookups, added Code Red signature check
 ******************************************************/
#include "config.h"
#include <cstdio>
#include <cstring>
#include <ctime>

#include <MacTypes.h>
#include <MacMemory.h>
#include <MacWindows.h>
#include <Files.h>
#include <Controls.h>
#include <Dialogs.h>
#include <Fonts.h>
#include <Events.h>
#include <AppleEvents.h>
#include <Threads.h>

#include "MacTCPCommonTypes.h"
#include "TCPPB.h"
#include "TCPHi.h"
#include "MOT.h"
#include "TTY_Messages.h"
#include "Template.h"
#include "http.h"
#include "HTTP_Scripts.h"
#include "HTTP_Response.h"
#include "StatusGraphs.h"
#include "HTTP_Properties.h"
#include "HTTP_IPCaching.h"
#include "HTTP_Threads.h"
#include "Logic.h"
#include "Plugin.h"
#include "HTTP_Notification.h"
#include "PW_UI.h"
#include "ResolvePath.h"

#include "globals.h"

/*internal prototypes*/

static char local_h_name [200];

TCPStreamPtr streams;

static unsigned long minMem, currMem, bytesSent;
static Handle emergency_mem = NULL;
static short memory_error = FALSE;

static LevelGraph levelCon, levelMem;

static char upTimeStr[24];

static TCPNotifyUPP MyASRUPP;

static int log_initialized = 0;

/**********************************************/

void LogDrawMemoryErrorIcon ()
{
#if INTERACTIVE
	if (memory_error) {
		SetPort (theWin);
		TextFont (kFontIDGeneva);
		TextSize (9);
		TextFace (bold);
		MoveTo (theWin->portRect.left+4, STAT_AREA_HEIGHT-5);
		ForeColor (redColor);
		DrawString ("\pMemory Err");
		ForeColor (blackColor);
	}
#endif
}

/**********************************************/
 
void LogDrawRefuseIcon (short draw_it)
{
#if INTERACTIVE
Rect r;
	SetRect (&r, 4, 0, 70, 12);
	if (draw_it) {
		SetPort (theWin);
		TextFont (kFontIDGeneva);
		TextSize (9);
		TextFace (bold);
		MoveTo (r.left, r.top+9);
		ForeColor (redColor);
		DrawString ("\pRefused");
		ForeColor (blackColor);
	}
	else
		EraseRect (&r);
#endif
}

/**********************************************/

void LogMemoryError()
{
	memory_error = TRUE;
	LogDrawMemoryErrorIcon();
	HTTP_Notify();
}

/**********************************************/

void LogMemCheck(long *memfree)
{
	currMem = FreeMem();
	if (currMem>maxMem)
		maxMem=currMem;
	else if (currMem<minMem)
		minMem=currMem;
	if (currMem < MIN_MEMORY) {
		PurgeMem (maxMem);
		currMem = FreeMem();
		if (currMem < MIN_MEMORY) {
			if (emergency_mem) 
				DisposeHandle (emergency_mem);
			emergency_mem = NULL;	
			/*stop connections and report the problem*/
	//		MRefuseConnections (TRUE);
			TTY_WriteMessage (" ", TRUE);
			TTY_WriteMessage ("**********************", TRUE);
			TTY_WriteMessage ("ERROR!!! MacHTTP has run out of memory. Quit and allocate more in the Finder.", TRUE);
	//		TTY_WriteMessage ("         All new incoming connections are being refused. You may", TRUE);
	//		TTY_WriteMessage ("         enable connections again with the Refuse Connections menu", TRUE);
	//		TTY_WriteMessage ("         selection under the Options menu.", TRUE);
			TTY_WriteMessage ("**********************", TRUE);
			
			LogMemoryError();
		}
	}
	else if (emergency_mem == NULL && (MIN_MEMORY*2 < currMem)) { /*reallocate the emergency memory*/
		emergency_mem = NewHandle (MIN_MEMORY);
	}
	*memfree = currMem;
}

/**********************************************/

void LogLowMemoryReport (unsigned long memfree)
{
unsigned long required;
char s[256];
	required = STREAM_AVG_SIZE * (MAX_STREAMS-MAX_LISTENS) + DESIRED_FREE_MEM;
	if (required>memfree) {
		TTY_WriteMessage( " ", TRUE);
		TTY_WriteMessage ("########", TRUE);
		sprintf (s, "WARNING: MacHTTP needs at least %ld bytes of free memory to support %d users.",
				required, MAX_STREAMS);
		TTY_WriteMessage (s, TRUE);
		sprintf (s, "You only have a maximum of %ld bytes free. You should quit MacHTTP now ", memfree);
		TTY_WriteMessage (s, TRUE);
		sprintf (s, "and increase the application's memory partition by at least %ld bytes", required-memfree);
		TTY_WriteMessage (s, TRUE);
		sprintf (s, "using the Finder's \"Get Info\" command to change the Preferred Memory size.");
		TTY_WriteMessage (s, TRUE);
		TTY_WriteMessage (" ", TRUE);
	}
}

/**********************************************/

void LogInitStream (TCPStreamPtr stream)
{
ThreadID tid;
	if (stream) {
		tid = stream->thread_id;
		memset (stream, 0, sizeof (TCPStream));
		stream->thread_id = tid;
		
		stream->stream = 0;
		stream->s_event = 0;
		stream->state = inactive;
		stream->thread_id = 0;
		stream->rblock = NULL;
		stream->remoteHost = 0;
		stream->method = METHOD_UNKNOWN;
		
		stream->request = NULL;
		stream->request_buffer_size = 0;
		stream->request_byte_count = 0;
		stream->post_arg_byte_count = 0;
		
		strcpy (stream->mime_type, "text/html");
		stream->next = streams->prev = NULL;
		stream->timeout = 0;
		stream->terminate_reason = 0;
		stream->asr_time = 0;
		stream->last_query_time = 0;
		if ((connectionID & 0x0000FFFF) == 65535) //accomodate a potential AppleEvent id problem with 2^16-1 by skipping it
			connectionID++;
		stream->id = connectionID++;
		stream->content_size = 0;
		stream->content_length = 0;
		stream->content_range = NULL;
		stream->commandDone = FALSE;
		stream->is_http10 = FALSE;
		stream->found = 0;
		stream->action = NULL;
		stream->actionTaken = A_UNKNOWN;
		stream->log_this = L_UNKNOWN;
		stream->f = NULL;
		stream->post_args = NULL;
		stream->path_args[0] = '\0';
		stream->reply_str = NULL;
		stream->host_name[0] = stream->user_name[0] = stream->password[0] = stream->content_type[0] =
			stream->from_user[0] = '\0';
		stream->user_agent[0] = '\0';
		stream->url_referer[0] = '\0';
		stream->whichRealm = NULL;
		stream->t_k = 0;
		stream->flags = 0;
		stream->virtual_dir = &gServerRootFS; //default to the server root document tree unless overridden later by hostfolder stuff
	}
}

/**********************************************/
/* Determines if an ASR event indicates the connection is terminated. If so, the stream is
   transitioned to the terminated state and everything is cleaned up and restarted as necessary.
 */
 
unsigned long gTerminatedConnections = 0;

int StreamIsTerminated (TCPStreamPtr stream) 
{
OSErr err;
//char s [256];
long remoteHost;
short remotePort;

	if (stream->s_event==TCPTerminate) { //listen is dead, start over
		err = AsyncGetConnectionData (stream->rblock, &remoteHost, &remotePort); //clean up any dangling async data structures. May not be necessary, but better safe than sorry.
		currListens--;
		currConnections++;
		stream->state = terminated;
		gTerminatedConnections++;
//sprintf (s, "\rCon: %ld listen was terminated, reason %d", stream->id, stream->terminate_reason);
//TTY_WriteMessage(s, TRUE);
		return true;
	}
	
	return false;
}
				
/**********************************************/

void LogHostName(char *s)
{
	strcpy (s, local_h_name);
}

/**********************************************/

TCPStreamPtr MakeNewStream()
{
TCPStreamPtr s;
	s = (TCPStreamPtr) NewPtr (sizeof (TCPStream));
	if (!s) {
		TTY_WriteMessage("Out of memory in MakeNewStream", TRUE);
		LogMemoryError();
	}
	else {
		LogInitStream (s);
	}
	return s;
}

/**********************************************/

void InsertStream(TCPStreamPtr s)
{
	s->next = streams;
	streams = s;
}

/**********************************************/

void DeleteStream(TCPStreamPtr s)
{
TCPStreamPtr temp;
char str[80];
OSErr err;

	temp = streams;

	if (!s) {
		TTY_WriteMessage ("ERROR!!! MacHTTP tried to delete a stream that doesn't exist!",TRUE);
		TTY_WriteMessage (" This is a SERIOUS problem. Please restart MacHTTP and notify the author.", TRUE);
		return;
	}
	
/*Check to see if a file is still open by accident. close it!*/
	if (s->f) {
		if (debugLevel) {
			sprintf (str, "Stream %lu had an unclosed file! Type was %d (%s).", s->id, s->fileType, s->mime_type);
			TTY_WriteMessage (str, TRUE);
		}
		fclose (s->f);
	}
	else if (debugLevel) {
		sprintf (str, "Stream %lu, File closed already.", s->id);
		TTY_WriteMessage (str, TRUE);
	}
	
	/*clean up any buffers associated with the stream if they exist*/
//	if (s->post_args) DisposePtr ((Ptr) s->post_args);

	if (s->request) {
		DisposePtr ((Ptr) s->request);
		s->request_buffer_size = 0;
		s->request_byte_count = 0;
		s->post_arg_byte_count = 0;
	}

	if (s->reply_str) {
		DisposePtr (s->reply_str);
		s->reply_str = NULL;
		s->reply_len = 0;
	}
	
	HTTP_DisposeContentRange(s);

#if THREAD_SUPPORT
	if (threadsOK) {
		err = 0;//DisposeThread (s->thread_id, 0, FALSE);
		if (err != noErr) {
sprintf (str, "Error disposing thread %d", err);
TTY_WriteMessage (str, TRUE);
		}
	}
#endif
	
	if (streams == s) { /*delete the head of the list*/
		streams = streams->next;
		DisposePtr ((Ptr)temp);
		return;
	}
	else {	
		while (temp) {
			if (temp->next == s) {
				temp->next = s->next;
				DisposePtr ((Ptr) s);
				return;
			}
			temp = temp->next;
		}
	}				
}

/**********************************************/

pascal void MyASR ( StreamPtr PARM_UNUSED(s), unsigned short event, TCPStreamPtr userData,
					unsigned short termReason, struct ICMPReport *PARM_UNUSED(icmp))
{
	userData->s_event = event;
	userData->asr_time = TickCount();
	switch (event) {
		case TCPClosing:
//			if (userData->state == active) 
//				userData->state = closing;
			break;
		case TCPULPTimeout:
//			if (userData->state == active) 
//				userData->state = closing;
//			if (LogTimeout (userData)) {
//			}
			break;
		case TCPDataArrival:
		case TCPUrgent:
		case TCPICMPReceived:
			break;
		case TCPTerminate:
			if (userData->state == reading || userData->state == writing || 
				userData->state == still_writing) 
				userData->state = closed;
			userData->terminate_reason = termReason;
			userData->flags |= STREAM_FLAG_TERMINATED;
			break;
	}
//	userData->asr_time = TickCount();
}

/**********************************************/

short ASRIsValid(TCPStreamPtr stream)
{
	return (stream->asr_time > stream->last_query_time);
}

/**********************************************/

OSErr LogOpenPassive (TCPStreamPtr s)
{
OSErr err;
char str[90];
	/*** Open Stream ***/
	err = CreateStream((unsigned long *) &(s->stream),(long) kBufSize, (TCPNotifyProcPtr) MyASRUPP, (long) s);
	if (err!=noErr) {
		sprintf (str, "ERROR: Unable to create IP stream for listen. Probably out of memory. (%d)", err);
		TTY_WriteMessage (str, TRUE);
		LogMemoryError();
		s->stream=0;
		return (-1);
	} 
	
	/*start passive listen*/
	AsyncWaitForConnection (s->stream, 0, kHTTPPort, 0, 0, &(s->rblock));
	s->state = listening;
	return 0;
}

/**********************************************/

void LogCloseStream (TCPStreamPtr stream)
{
	if (stream->stream) {
		/*** Close network connection ***/
		CloseStreamConnection(stream->stream);
		ReleaseStream(stream->stream);
		stream->stream = 0;
		stream->s_event = 0;
		stream->state = inactive;
		stream->rblock = NULL;
		if (stream->reply_str) {
			DisposePtr (stream->reply_str);
			stream->reply_str = NULL;
			stream->reply_len = 0;
		}
		HTTP_DisposeContentRange(stream);
	}
}

/**********************************************/
void LogReleaseStream (TCPStreamPtr stream)
{
	if (stream->stream) {
		/*** Close network connection ***/
		ReleaseStream(stream->stream);
		stream->stream = 0;
		stream->s_event = 0;
		stream->state = inactive;
		stream->rblock = NULL;
		if (stream->reply_str) {
			DisposePtr (stream->reply_str);
			stream->reply_str = NULL;
			stream->reply_len = 0;
		}
		HTTP_DisposeContentRange(stream);
	}
}

/**********************************************/

void LogStartTimeout(TCPStreamPtr stream, short seconds)
{
	if (stream) stream->timeout = TickCount() + seconds*60;
}

/**********************************************/

short LogTimeout(TCPStreamPtr stream)
{
	if (stream)
		return (TickCount()>stream->timeout);
	else 
		return (TRUE);
}

/**********************************************/

void LogQueueListens()
{
TCPStreamPtr sptr;
short count, i;
char s[80];
	
	if (!gUseThreads && currListens == 0)  //voodoo code to make non-threaded stuff work. Dunno exactly why, unfortunately.
		currListens = 1;
		
	count = MAX_LISTENS-currListens;
	if ((MAX_LISTENS + currConnections)>=MAX_STREAMS)
		count = MAX_STREAMS - (currListens + currConnections);
	if (currListens<=0)
		count = 1;
if (count && debugLevel) {
	sprintf(s,"Queueing %d new listens", count);
	TTY_WriteMessage (s, TRUE);
}
	
	if (threadsOK)
		count = MAX_STREAMS;

	for (i=0;i<count;i++) {
		sptr = MakeNewStream();
		if (sptr) {
			InsertStream (sptr);
			LogOpenPassive (sptr);
			currListens++;
			
			HTTP_ThreadQueueListens(sptr);
		}
	}
}

void LogConnection(TCPStreamPtr stream)
{
	HostFolderPtr pHF = HTTP_GetHostFolderPtr (stream);
	if ( pHF )
	{
		pHF->connections++;
		time ( (time_t *) &pHF->most_recent );
	}
	totalConnections++;
}

/**********************************************/

OSErr LogInit()
{	
	OSErr err;
	time_t now;
	struct tm *date;
	Rect r;
	long memfree;
	Str255 s;
	char temp[256];
	unsigned long addr;
	unsigned long mask;

	/* set aside some memory for emergencies */
	emergency_mem = NewHandle (MIN_MEMORY);

	/*** Open drivers ***/
	err = InitNetwork();
	if (err!=noErr) {
		Error((char *) "\pUnable to Initialize Network! MacTCP may not be loaded. Quitting now.");
		return (-1);
	}
	
//MOT test code
//if (1) {
//MOTErr merr;
//merr = MOTLocalHostName (temp, 256);
//}
	// Set up UPP for MyASR.
	MyASRUPP = NewTCPNotifyProc ( MyASR );
	
	HTTP_Init();
	
	totalConnections = 0;
	connectionID = 1;
	currConnections = highConnections = busyConnections = deniedConnections = timeoutConnections = 0;
	currListens = 0;
	maxMem = currMem = 0;
	minMem = 0xFFFFFFFF;
	bytesSent = 0;
	
	/*get the name of the local host the server is running on*/
	
	err = GetMyIPAddr (&addr, &mask);
	if (err) {
		sprintf (temp, "Error %d getting local host address.", err);
		TTY_WriteMessage (temp, TRUE);
		strcpy (local_h_name, "localhost");
	}
	else 
		HTTP_IPAddrToName(addr, local_h_name);
	
	/*save the current working directory for server root as a FSSpec*/
	err = ResolvePathAlias (":", NULL, 0, &gServerRootFS, NULL, NULL);
	
	/*Set the start-up time string*/
	time (&now);
	date = localtime (&now);
	strftime (upTimeStr, 24, "%m/%d/%y:%H:%M", date);
	
	/*Init the thread manager stuff */
	err = HTTP_InitThreads();
	
	if (MAX_LISTENS>=MAX_STREAMS)
		MAX_LISTENS = MAX_STREAMS-1;
		
	if (threadsOK) {
		LogQueueListens();
	}
	else {
		/*Open a Passive connection*/
		streams = MakeNewStream();
		if (streams) {
			LogOpenPassive(streams);
			LogQueueListens();
		}
		else {
			TTY_WriteMessage (" ", TRUE);
			TTY_WriteMessage ("ERROR! Unable to listen for clients!", TRUE);
		}
	}
	
	/*Once the config file is loaded, finish setting up the realm info in the password dialog*/
	HTTP_GetRealm (1, s); /*get the realmName from the list of realms*/
	UI_SetRealm (s);	/*stuff it in the dialog button*/

	HTTP_InitCaching();
	HTTP_InitNotify();
	LogMemCheck(&memfree);
	LogLowMemoryReport (memfree);

	/*Initialize the status graphs*/
	SetRect (&r, 72, 3, 72+MAX_STREAMS*8, 9);
	InitLevelBar (&levelCon, (WindowPtr) theWin, &r, MAX_STREAMS, 1);

	SetRect (&r, 72, 34, 262, 40);
	InitLevelBar (&levelMem, (WindowPtr) theWin, &r, memfree, memfree/(r.right-r.left));
	
	HTTP_ResponseInit ();
	
	log_initialized = 1;
	
	return 0;
}

/**********************************************/

void LogMakeStatusReport (char *s)
{
char s1[512];
char t[512];
HostFolderPtr hf;

	sprintf (s1, "totalCon %ld, maxCon %d, listening %d, current %d, high %d, busy %d, denied %d, timeout %d, maxMem %lu, currMem %lu, minMem %lu, bytesSent %lu",
		totalConnections, MAX_STREAMS, currListens, currConnections, highConnections, busyConnections, 
		deniedConnections, timeoutConnections, maxMem, currMem, minMem, bytesSent);
	sprintf (t, ", port %d, maxTimeout %d, verboseMessages %s, disableLogging %s, hideWindow %s, refuseConnections %s, upSince %s, version %s(%s), product %s",
		kHTTPPort, MAX_TIMEOUT,
		debugLevel ? "true" : "false", logging ? "false" : "true", 
		hideInBack ? "true" : "false", refuseConnections ? "true" : "false",
		upTimeStr, C_VERSION_STR, PROCESSOR_STRING, PRODUCT_NAME); //note that PRODUCT_NAME should always be the last token. Insert new ones before it.
	strcat (s,s1);
	strcat (s,t);
	for (hf = HTTP_GetHostFolderListHead(); hf; hf = hf->next) {
		char hfs[512];
		sprintf (hfs, ", %s-Con %ld", hf->hostname, hf->connections);
		strcat (s, hfs);
	}
}

/**********************************************/

void LogDrawStatus()
{
Rect r;
char s[128], m[128];

#if INTERACTIVE
	sprintf(s, "Connections  : Total %ld   Max %d   Listening %d   Current %d   High %d   Busy %d   Denied %d   Timeout %d", 
			totalConnections, MAX_STREAMS, currListens, currConnections, 
			highConnections, busyConnections, deniedConnections, timeoutConnections);
	CtoPstr(s);
	
	sprintf (m, "Free Memory: Max %lu   Current %lu   Min %lu   Sent:%6.1fK   Up Since: %s", /*Max %lu   */
			maxMem, currMem, minMem, (float) bytesSent/1024, upTimeStr);
	CtoPstr(m);
	
	r = theWin->portRect;
	InsetRect(&r, 4, 4);
	r.bottom = r.top+29;
	r.top+=8;
	
	SetPort (theWin);
	TextFont (kFontIDGeneva);
	TextSize (9);
	TextFace (0);
	
	EraseRect(&r);
	MoveTo(r.left,r.bottom-14);
	DrawString((StringPtr) s);
	MoveTo(r.left, r.bottom - 3);
	DrawString((StringPtr) m);
	DrawLevelBar (&levelCon);
	DrawLevelBar (&levelMem);
	
	LogDrawMemoryErrorIcon();
	LogDrawRefuseIcon (refuseConnections);
#endif
}

/**********************************************/

static short o_curr=0, o_high=0, o_busy=0, o_denied, o_timeout=0;
static unsigned long o_mem=0, o_bytes=0;

void LogUpdateStats()
{
#if INTERACTIVE
	UpdateLevelBar (&levelCon, currConnections);
	UpdateLevelBar (&levelMem, maxMem-currMem);
#endif

	if (currConnections>highConnections) highConnections = currConnections;

	if (currConnections != o_curr || 
		highConnections != o_high ||
		busyConnections != o_busy ||
		deniedConnections!=o_denied ||
		timeoutConnections!= o_timeout ||
		currMem != o_mem ||
		bytesSent != o_bytes) {
		
		LogDrawStatus();
		
		o_curr=currConnections; 
		o_high=highConnections;
		o_busy=busyConnections;
		o_denied=deniedConnections;
		o_timeout=timeoutConnections;
		o_mem = currMem;
		o_bytes = bytesSent;
	}
}

/**********************************************/

void LogRedraw()
{
	if (threadsOK) {
		while (!log_initialized) {
			YieldToAnyThread ();		//this can ONLY happen in the threaded version, so we shouldn't deadlock.
		}								//you get here by having a TCP/IP operation in a HTTP thread give time to the main event loop. Convoluted...
	}
	
	LogDrawStatus();
}

/**********************************************/

void LogStopWriting (TCPStreamPtr stream)
{
char s[256];
	if (stream->f) 
		fclose (stream->f);
	stream->f = NULL;
	if (!(stream->t_timer=TickCount()-stream->t_timer)) stream->t_timer = 1;
	
	if (debugLevel) {
		sprintf(s, "Sent %ld bytes in %ld ticks (%ld CPS)", stream->t_k, stream->t_timer,
				(long) ((stream->t_k/stream->t_timer)*60) );
		TTY_WriteMessage(" ", TRUE);
		TTY_WriteMessage(s, TRUE);
	}
}

/**********************************************/

long LogDumpBinaryFile (TCPStreamPtr stream, Boolean header_needed)
{
	OSErr	err;
	Boolean	multipart;
	long	multiPartLength;
	char	s[256];
	ByteRangePtr ContentRange;

	stream->t_k=0;
	LogConnection (stream); //	totalConnections++;
	stream->t_timer=TickCount();
		
	if (!stream->f /*|| !stream->found*/) {
		HTTP_ErrorResponse (stream, R_NOT_FOUND, "Error. No such file.");
		err = SendData(stream->stream, "Error. No such file.", (unsigned short) 20,false);
		err = SendData(stream->stream, HTTP_RESP_2CRLF, (unsigned short) 4, false);
		if (stream->f)
			LogStopWriting (stream);
		return (stream->t_k);
	}
	else {
		if (stream->found == 1)
		{
			if (stream->content_range)
			{
				if (stream->content_size > 0)
				{
					err = R_PARTIAL_CONTENT;
					multipart = (stream->content_range->next != NULL);
					if (multipart)
						sprintf(stream->range_boundary, "%08lx.%08lx|MacHTTP", stream->creation_date, stream->id);
					
					// Loop through the content_range linked list in order
					// to resolve the content_size or the suffix-byte-range-spec
					// for unspecified begin and/or end values, and also to
					// find out the total length of the multipart content.
					multiPartLength = 0; 
					ContentRange = stream->content_range;
					do
					{
						if (ContentRange->end   == -1)						// resolve content_size if end is unspecified
							ContentRange->end  += stream->content_size;
						else if (ContentRange->end >= stream->content_size)	// PDFViewer sometimes specifies end to be beyond
							ContentRange->end   = stream->content_size - 1; // the EOF, set it to a valid value in this case.
						
						if (ContentRange->begin == -1)						// resolve suffix-byte-range-spec
						{
							ContentRange->begin = stream->content_size - ContentRange->end;
							ContentRange->end   = stream->content_size - 1;
						}
						else if (ContentRange->begin > ContentRange->end)	// Fatal error
						{
							err = R_RANGE_UNSATISFIABLE;					// respond with error code 416
							multipart = false;
							multiPartLength = 0;
							HTTP_DisposeContentRange(stream);
							ContentRange = NULL;
							break;
						}
						
						// --boundaryCRLF
						// Content-type: application/pdfCRLF
						// Content-range: bytes bbbbbbbb-eeeeeeee/ssssssssCRLF
						// CRLF
						// ...content...CRLF
						if (multipart)
							multiPartLength += ContentRange->end - ContentRange->begin + 1 +
								sprintf(s, "\r\n--%s\r\nContent-type: %s\r\nContent-range: bytes %ld-%ld/%ld\r\n\r\n",
										stream->range_boundary, stream->mime_type, ContentRange->begin, ContentRange->end, stream->content_size);
						
						ContentRange = ContentRange->next;
					}	
					while (ContentRange);
					
					if (multipart)
						multiPartLength += strlen(stream->range_boundary) + 8;	// CRLF--boundary--CRLF
						
					stream->content_length = multiPartLength;
					HTTP_Respond(stream, err, "");
					if (err == R_RANGE_UNSATISFIABLE)
					{
						if (stream->f)
							LogStopWriting(stream);
						return 0;
					}
				}

				else
				{
					HTTP_DisposeContentRange(stream);
					HTTP_Respond(stream, R_OK, "");
				}
			}
			
			else
				if (header_needed) //not needed for RAW! files
					HTTP_Respond(stream, R_OK, "");
		}
		
		else if (stream->found == 2)
			HTTP_Respond (stream, R_FORBIDDEN, "");
		
		else
			HTTP_Respond (stream, R_NOT_FOUND, "");
	}

	if (LogStillWritingBinary (stream)) { 	/*send the first chunk, see if we're finished*/
		stream->state = still_writing;		/*not finished, so transition to still_writing state*/
		return 0;
	}
	else 
		return (stream->t_k);
}



/**********************************************/
#define stretch 128

size_t fread_Ranges(char *ptr, size_t size, size_t nmemb, TCPStreamPtr stream)
{
	Boolean multipart;
	char	dummy;
	long	bcount, btotal;
//	ByteRangePtr ContentRange;


	if (!stream->content_range)
		return fread(ptr, size, nmemb, stream->f);	// no ranges, call standard fread() and return
	
	else
	{
		btotal = 0;
		multipart = (stream->content_range->prev || stream->content_range->next);
// this while stmt generates a warning on CWPro5
//		while (ContentRange = stream->content_range)
		while ( stream->content_range )
		{
			ByteRangePtr ContentRange = stream->content_range;
				
			if (ContentRange->begin < 0)
				ContentRange->begin *= -1;
			
			else if (multipart)						// put the range boundary into the output buffer
			{
				bcount = sprintf(ptr, "\r\n--%s\r\nContent-type: %s\r\nContent-range: bytes %ld-%ld/%ld\r\n\r\n",
								 stream->range_boundary, stream->mime_type, ContentRange->begin, ContentRange->end, stream->content_size);
				if (bcount < nmemb)
				{
					ptr    += bcount;
					btotal += bcount;
					nmemb  -= bcount;
				}
				else								// range boundary does not fit into the output buffer,
					return btotal;					// so simply skip it for the next run
			}

			// read the given range into the output buffer
			bcount = ContentRange->end - ContentRange->begin + 1;	
			fseek(stream->f, ContentRange->begin, SEEK_SET);
			if (bcount > nmemb)	
			{										// the whole range DOES NOT fit into the output buffer
				bcount = fread(ptr, size, nmemb, stream->f);
				btotal += bcount;
				
				if (feof(stream->f))
					return 0;						// unexpected EOF
				else
				{
					ContentRange->begin += bcount;
					ContentRange->begin *= -1;		// more to be read from this content
					return btotal;					// range during the next run
				}
			}
			
			else
			{										// the whole range DOES fit into the output buffer
				bcount = fread(ptr, size, bcount, stream->f);
				ptr    += bcount;
				btotal += bcount;
				nmemb  -= bcount;
				
				if (feof(stream->f))
					return 0;						// unexpected EOF
				else
				{									// switch to next range
					stream->content_range = ContentRange->next;
					DisposePtr((Ptr)ContentRange);
				}
			}
		}
		
		if (multipart)
			btotal += sprintf(ptr, "\r\n--%s--\r\n", stream->range_boundary);

		fseek(stream->f, 0, SEEK_END);
		fread(&dummy, 1, 1, stream->f);				// set the EOF flag
		
		return btotal; 
	}
}



short LogStillWritingBinary (TCPStreamPtr stream)
{
	OSErr	err;
	size_t	num;
	char	s[MAX_DUMP_BUF_SIZE + stretch];

	if (!stream) 
		return (FALSE);
	else if (stream->state == closed) { /* The ASR must've done this. Client is gone, clean up. */
		LogStopWriting (stream);
		return (FALSE);
	}

	if (!feof(stream->f)) {
		num = fread_Ranges (s, 1, DUMP_BUF_SIZE, stream);
		stream->t_k+=num;

		err = SendData(stream->stream, s, (unsigned short) num,false);	
		if (num && !err)
			LogStartTimeout (stream, MAX_TIMEOUT); /*reset the time-out*/
		else {
			if (!num)
				TTY_WriteMessage ("WARNING: File read 0 bytes while reading binary file.", TRUE);
		}	/*else*/
	}	/*if*/

	/*check to see if the whole file fit in one chunk. If so, close it now and save time*/
	if (feof (stream->f)) {
		fclose (stream->f);
		stream->f = NULL;
		if (!(stream->t_timer=TickCount()-stream->t_timer)) stream->t_timer = 1;
		
		if (debugLevel) {
			sprintf(s, "Sent %ld bytes in %ld ticks (%ld CPS)", stream->t_k, stream->t_timer,
					(long) ((stream->t_k/stream->t_timer)*60) );
			TTY_WriteMessage(" ", TRUE);
			TTY_WriteMessage(s, TRUE);
		}
		return (FALSE);
	}
	else 
		return (TRUE); /*more to write...*/
}

/**********************************************/
long LogDumpTextFile (TCPStreamPtr stream)
{
	stream->t_k=0;
	LogConnection (stream); //totalConnections++;
	stream->t_timer=TickCount();

	if (!stream->f /*|| !stream->found*/) {
		HTTP_Respond (stream, R_NOT_FOUND, "Error. No such file.");
		if (stream->f)
			LogStopWriting (stream);
		return (stream->t_k);
	}
	else {
		if (stream->found)
			HTTP_Respond (stream, R_OK, "");
		else if (stream->found == 2)
			HTTP_Respond (stream, R_FORBIDDEN, "");
		else
			HTTP_Respond (stream, R_NOT_FOUND, "");
	}

	if (LogStillWritingText (stream)) { 	/*send the first chunk, see if we're finished*/
		stream->state = still_writing;		/*not finished, so transition to still_writing state*/
		return 0;
	}
	else
		return (stream->t_k);
}

/**********************************************/

short LogStillWritingText (TCPStreamPtr stream)
{
OSErr err;
size_t num;
short buffSize;
short oldbuff = 0;
char s[MAX_LINE_LENGTH+1];
char outBuff[MAX_DUMP_BUF_SIZE+2];
char *temp;

	if (!stream) 
		return (FALSE);
	else if (stream->state == closed) { /*The ASR must've done this. Client is gone, clean up.*/
		LogStopWriting (stream);
		return (FALSE);
	}
	else { /*proceed as usual*/
		outBuff[0]='\0';
		buffSize = 0;
		while (!feof(stream->f)) {
			/*see if we're still connected, because the client could terminate on us.*/
			if (stream->state == closed) {
				LogStopWriting (stream);
				return (FALSE);
			}
			else {
				s[0] = (char) 0;
				temp = fgets (s, MAX_LINE_LENGTH, stream->f);
				if (temp) {
					num = strlen(s);
					if (num+buffSize < DUMP_BUF_SIZE) {
						strcat (outBuff, s);
						buffSize += num;
						/*delete this once the CodeWarrior libs are fixed*/
						if (buffSize == oldbuff) {
							if (stream->state == closed) 
								break;
						}
						else oldbuff = buffSize;
						/*end deleted section*/
					}
					else {
						stream->t_k+=buffSize;
						err = SendData(stream->stream, outBuff, (unsigned short) buffSize, false);
						if (buffSize && !err)
							LogStartTimeout (stream, MAX_TIMEOUT); /*reset the time-out*/
						outBuff[0]='\0';
						strcat (outBuff, s);
						buffSize = num;
						break; /*we've written 1 buffer, bail out of the loop*/
					}
				}
				else
					break;
			}/*else*/
		}/*while*/
	
		if (buffSize) {
			stream->t_k+=buffSize;
			err = SendData(stream->stream, outBuff, (unsigned short) buffSize, false);
			if (buffSize && !err)
				LogStartTimeout (stream, MAX_TIMEOUT); /*reset the time-out*/
		}
		
		/*check to see if the whole file fit in one chunk. If so, close it now and save time*/
		
		if (feof (stream->f) || stream->state == closed) {
			LogStopWriting (stream);
			return (FALSE);
		}
		else 
			return (TRUE); /*more to write...*/
	}
}

/**********************************************/

void LogMakeOSAGlobal (TCPStreamPtr stream, char *dest, char *PARM_UNUSED(source), char *PARM_UNUSED(args))
{
char cr, lf, eol[3], temp[16];

#if MPW || MPW_PPC
	cr = '\n'; lf = '\r';
	strcpy (eol, "\"\n");
#else
	cr = '\r'; lf = '\n';
	strcpy (eol, "\"\r");
#endif

	if (!stream) {
		dest[0]='\0';
		return;
	}

	strcat (dest, "set http_search_args to \"");
	strcat (dest, stream->search_args);
	strcat (dest, eol);
	
	strcat (dest, "set path_args to \"");
	strcat (dest, stream->path_args);
	strcat (dest, eol);
	
	strcat (dest, "set post_args to \"");
	if (stream->post_args) strcat (dest, stream->post_args);
	strcat (dest, eol);
	
	strcat (dest, "set method to \"");
	strcat (dest, methodTokens[stream->method]);
	strcat (dest, eol);
	
	strcat (dest, "set client_address to \"");
	strcat (dest, stream->host_name);
	strcat (dest, eol);
	
	strcat (dest, "set username to \"");
	strcat (dest, stream->user_name);
	strcat (dest, eol);
	
	strcat (dest, "set password to \"");
	strcat (dest, stream->password);
	strcat (dest, eol);

	strcat (dest, "set from_user to \"");
	strcat (dest, stream->from_user);
	strcat (dest, eol);
	
	strcat (dest, "set server_name to \"");
	strcat (dest, HTTP_GetVirtualHostname (stream));
	strcat (dest, eol);
	
	strcat (dest, "set server_port to \"");
	sprintf (temp, "%hd", kHTTPPort);
	strcat (dest, temp);
	strcat (dest, eol);
	
	strcat (dest, "set script_name to \"");
	strcat (dest, stream->url_realname);
	strcat (dest, eol);
	
	strcat (dest, "set content_type to \"");
	strcat (dest, stream->content_type);
	strcat (dest, eol);
	
	strcat (dest, "set referer to \"");
	strcat (dest, stream->url_referer);
	strcat (dest, eol);
	
	strcat (dest, "set user_agent to \"");
	strcat (dest, stream->user_agent);
	strcat (dest, eol);
	
}

/**********************************************/

long LogExecuteScriptFile (TCPStreamPtr stream)
{
OSErr err;
char *scriptText;
long i;
long timer, k;
char s[256];
	k=0;
	LogConnection (stream); //totalConnections++;
	timer=TickCount();
	
	if (!stream->f /*|| !stream->found*/) {
		HTTP_ErrorResponse (stream, R_NOT_FOUND, "Error. No such file.");
		err = SendData(stream->stream, "Error. No such file.", (unsigned short) 20,false);
		err = SendData(stream->stream, HTTP_RESP_2CRLF, (unsigned short) 4, false);
		if (stream->f)
			LogStopWriting (stream);
		return (k);
	}
/*	else {*/
/*		HTTP_Respond (stream, R_OK, "");*/
/*	}*/
	if (!(scriptText = (char *) NewPtr(SCRIPT_SIZE+1))) {
		err = SendData(stream->stream, 
				"Insufficient memory to execute script.", 
				(unsigned short) 37, false);
		TTY_WriteMessage("Insufficient memory to execute script.", TRUE);
		LogMemoryError();
	}
	else {
		/** Build the AppleScript global area **/
		for (i=0;i<SCRIPT_SIZE;scriptText[i++]='\0')
			;
		LogMakeOSAGlobal (stream, scriptText, stream->request, stream->search_args);
		i=fread (&scriptText[strlen(scriptText)], sizeof(char), 
				SCRIPT_SIZE-strlen(scriptText), stream->f);
		fclose(stream->f);
		stream->f = NULL;
		
		if (debugLevel) {
			TTY_WriteMessage(scriptText, TRUE);
		}
		
		HTTP_DoScript(scriptText);
		k = i = strlen(scriptText);
		if (k) {
			if (debugLevel) TTY_WriteMessage(scriptText, TRUE);
			err = SendData(stream->stream, scriptText, i, false);
			err = SendData(stream->stream, HTTP_RESP_2CRLF, 4, false);
			if (!err)
				LogStartTimeout (stream, MAX_TIMEOUT); /*reset the time-out*/
		}
		else {
			TTY_WriteMessage("Error executing script.", TRUE);
			err = SendData(stream->stream, 
				"Error executing script.", 
				(unsigned short) 23, false);
		}
		DisposePtr(scriptText);
	}
	
	timer=TickCount()-timer;
	if (debugLevel) {
		sprintf(s, "Ran & Sent %ld bytes in %ld ticks (%ld CPS)", k, timer,
				(long) /*((k/(timer/60))) */0);
		TTY_WriteMessage(" ", TRUE);
		TTY_WriteMessage(s, TRUE);
	}
	return (k);
}

/**********************************************/

long LogExecuteAPPLFile (TCPStreamPtr stream)
{
OSErr err;
char *result;
long i;
long timer, k;
Size len;
char s[256];

	k=0;
	LogConnection (stream); //totalConnections++;
	timer=TickCount();
	
	if (!stream->f /*|| !stream->found*/) {
		HTTP_ErrorResponse (stream, R_NOT_FOUND, "Error. No such file.");
		err = SendData(stream->stream, "Error. No such file.", (unsigned short) 20,false);
		err = SendData(stream->stream, HTTP_RESP_2CRLF, (unsigned short) 4, false);
		if (stream->f)
			LogStopWriting (stream);
		return k;
	}
/*	else {*/
/*		HTTP_Respond (stream, R_OK, "");*/
/*	}*/
	if (!(result = (char *) NewPtr(SCRIPT_SIZE+1))) {
		err = SendData(stream->stream, 
				"Insufficient memory to execute application.", 
				(unsigned short) 42, false);
		TTY_WriteMessage("Insufficient memory to execute application.", TRUE);
		LogMemoryError();
	}
	else {
		fclose(stream->f);
		stream->f = NULL;
		
		len = SCRIPT_SIZE;
		err = HTTP_DoApp (stream->mac_fname, stream->search_args, result, &len);
		
		k = i = strlen(result);
		if (k) {
			if (debugLevel) TTY_WriteMessage(result, TRUE);
			err = SendData(stream->stream, result, i, false);
			err = SendData(stream->stream, HTTP_RESP_2CRLF, 4, false);
		}
		else {
			TTY_WriteMessage("Error executing application.", TRUE);
			err = SendData(stream->stream, 
				"Error executing application.", 
				(unsigned short) 28, false);
		}
		DisposePtr(result);
	}
	
	timer=TickCount()-timer;
	if (debugLevel) {
		sprintf(s, "Ran & Sent %ld bytes in %ld ticks (%ld CPS)", k, timer,
				(long) /*((k/(timer/60))) */0);
		TTY_WriteMessage(" ", TRUE);
		TTY_WriteMessage(s, TRUE);
	}
	return (k);
}

/**********************************************/

OSErr LogAssignAppResults (unsigned short retID, char *temp, Size len, OSErr err)
{
TCPStreamPtr stream;
char s[100];
	stream = streams;
	while (stream) {
		if ((unsigned short) (stream->id & 0x0000FFFF) == retID){
			stream->reply_str = temp;
			stream->reply_len = len;
			if (err) {
				sprintf (temp, "Error receiving results from ACGI execution. (%d)", err);
				stream->reply_len = strlen (temp);
			}
			return (noErr);
		}
		stream = stream->next;
	}
	if (debugLevel) {
		sprintf (s, "Couldn't find stream %hd", retID);
		TTY_WriteMessage (s, TRUE);
	}
	return (errAEEventNotHandled);
}

/**********************************************/

long LogExecuteCGIFile (TCPStreamPtr stream)
{
OSErr err;
char *result;
long i;
long timer, k;
Size len;
char port[8];
Handle temph;
char s[256];

	k=0;
	LogConnection (stream); //totalConnections++;
	timer=TickCount();
	
	if (!stream->f /*|| !stream->found*/) {
		HTTP_ErrorResponse (stream, R_NOT_FOUND, "Error. No such file.");
		err = SendData(stream->stream, "Error. No such file.", (unsigned short) 20,false);
		err = SendData(stream->stream, HTTP_RESP_2CRLF, (unsigned short) 4, false);
		if (stream->f)
			LogStopWriting (stream);
		return k;
	}

	temph = NULL;
	result = NULL;
	temph = TempNewHandle (SCRIPT_SIZE+1, &err);
	if (err == noErr) {
		HLock (temph);
		result = *temph;
	}
	else { /*see if there's app memory*/
		result = (char *) NewPtr (SCRIPT_SIZE+2);
	}

	if (!result) {
		err = SendData(stream->stream, 
				"Insufficient memory to execute CGI application.", 
				(unsigned short) 42, false);
		TTY_WriteMessage("Insufficient memory to execute CGI application.", TRUE);
		LogMemoryError();
	}
	else {
		fclose(stream->f);
		stream->f = NULL;
		
		len = SCRIPT_SIZE;
		sprintf (port, "%hd", kHTTPPort);
		err = HTTP_DoCGI (stream, stream->method, stream->mac_fname, stream->path_args, stream->search_args,
				stream->post_args, stream->host_name, stream->user_name, stream->password, 
				stream->from_user, HTTP_GetVirtualHostname (stream), port, stream->url_realname, stream->content_type, 
				stream->url_referer, result, &len);
		
		k = i = strlen(result);
		if (k) {
			if (debugLevel) TTY_WriteMessage(result, TRUE);
			err = SendData(stream->stream, result, i, false);
			err = SendData(stream->stream, HTTP_RESP_2CRLF, 4, false);
		}
		else {
			TTY_WriteMessage("Error executing CGI application.", TRUE);
			err = SendData(stream->stream, 
				"Error executing CGI application.", 
				(unsigned short) 32, false);
		}
		if (temph) {
			HUnlock (temph);
			DisposeHandle (temph);
		}
		else {
			DisposePtr (result);
		}
	}
	
	timer=TickCount()-timer;
	if (debugLevel) {
		sprintf(s, "Ran CGI & Sent %ld bytes in %ld ticks (%ld CPS)", k, timer,
				(long) /*((k/(timer/60))) */0);
		TTY_WriteMessage(" ", TRUE);
		TTY_WriteMessage(s, TRUE);
	}
	return (k);
}

/**********************************************/

long LogExecuteACGIFile (TCPStreamPtr stream)
{
OSErr err;
//char *result;
long timer, k;
Size len;
char port[8];
	k=0;
	stream->t_k = 0;
	LogConnection (stream); // totalConnections++;
	timer=TickCount();
	
	if (!stream->f && !stream->action) {
		HTTP_ErrorResponse (stream, R_NOT_FOUND, "Error. No such file.");
		err = SendData(stream->stream, "Error. No such file.", (unsigned short) 20,false);
		err = SendData(stream->stream, HTTP_RESP_2CRLF, (unsigned short) 4, false);
		if (stream->f)
			LogStopWriting (stream);
		return k;
	}

	if (stream->fileType == FILE_ACGI) {
		if (stream->f)
			fclose(stream->f);
		stream->f = NULL;
	}
	
	/*The app is there, run it!*/
	len = SCRIPT_SIZE;
	
	sprintf (port, "%hd", kHTTPPort);
	
	if (stream->fileType == FILE_ACGI && !stream->action) {
		err = HTTP_DoACGI (stream, stream->method, stream->mac_fname, stream->path_args, stream->search_args,
				stream->post_args, stream->host_name, stream->user_name, stream->password,
				stream->from_user, HTTP_GetVirtualHostname (stream), port, stream->url_realname, stream->content_type);
	}
	else {
		if (stream->action)
			err = HTTP_DoACGI (stream, stream->method, (stream->action)->path, stream->path_args, stream->search_args,
					stream->post_args, stream->host_name, stream->user_name, stream->password,
					stream->from_user, HTTP_GetVirtualHostname (stream), port, stream->url_realname, stream->content_type);
	}
		
	if (err) {
		HTTP_ErrorResponse (stream, R_NOT_FOUND, "Error. Unable to launch ACGI application.");
		err = SendData(stream->stream, "Error. Unable to launch ACGI application.", (unsigned short) 39,false);
		err = SendData(stream->stream, HTTP_RESP_2CRLF, (unsigned short) 4, false);
		TTY_WriteMessage ("Error launching ACGI application!", TRUE);
		return (k);
	}
	else {
		stream->state = still_writing;
	}	
	
	timer=TickCount()-timer;
/*	if (debugLevel) {*/
/*		sprintf(s, "Ran CGI & Sent %ld bytes in %ld ticks (%ld CPS)", k, timer,*/
/*				(long) *//*((k/(timer/60))) *//*0);*/
/*		TTY_WriteMessage(" ", TRUE);*/
/*		TTY_WriteMessage(s, TRUE);*/
/*	}*/
	return (k);
}

/**********************************************/

LogStillWritingACGI(TCPStreamPtr stream)
{
OSErr err;
unsigned short len = 0;
unsigned long ix = 0;

	if (!stream) 
		return (FALSE);
	else if (stream->state == closed) { /*The ASR must've done this. Client is gone, clean up.*/
		LogStopWriting (stream);
		return (FALSE);
	}
	
	if (stream->action)
		if ((stream->action)->kind != A_ACGI) { //this was a plug-in, so we're done
			return FALSE;
		}
	
	if (stream->reply_str) { /*The reply AE has been returned. Process the reply*/
		if (stream->reply_len) {
			if (debugLevel && stream->reply_len<4096) {
				TTY_WriteMessage("ACGI Reply:", TRUE);
				TTY_WriteMessage(stream->reply_str, TRUE);
			}
			
			//break up large replies and send chunks as necessary
			ix = 0;
			while ((stream->reply_len - ix) > 0) {
				len = (stream->reply_len - ix) > ACGI_REPLY_CHUNK_SIZE ? ACGI_REPLY_CHUNK_SIZE : (stream->reply_len - ix);
				err = SendData (stream->stream, &(stream->reply_str [ix]), len, false);
				if (err) {
					break;
				}
				else {
					ix += len;
				}
			}
			
//			err = SendData(stream->stream, stream->reply_str, stream->reply_len, false);
			stream->t_k+=stream->reply_len;
		}
		else {
			TTY_WriteMessage("Error executing ACGI application. No results returned.", TRUE);
			err = SendData(stream->stream, 
				"Error executing ACGI application. No Results returned.", 
				(unsigned short) 49, false);
			stream->t_k = 0;
		}
		if (stream->reply_str) {
			DisposePtr(stream->reply_str);
			stream->reply_str = NULL;
			stream->reply_len = 0;
		}
		return (FALSE);
	}
	else return (TRUE);
}

/**********************************************/

short LogNotConditionalGet (TCPStreamPtr stream)
{
char mod_date [256];
	if (stream->method != METHOD_CONDITIONAL)
		return TRUE;
	else {
		HTTP_MakeDate (stream->modification_date, mod_date);
		if (strcmp (mod_date, stream->if_modified_date)) { /*mod dates are different, send the file*/
			if (debugLevel) TTY_WriteMessage (" Cached file modified.", TRUE);
			return TRUE;
		}
		else {	/*tell the proxy server the file is unchanged*/
			if (debugLevel) TTY_WriteMessage (" Cached file not modified.", TRUE);
			HTTP_Respond (stream, R_NOT_MODIFIED, "");
			if (stream->f) {
				fclose (stream->f);
				stream->f = NULL;
				LogConnection (stream); // totalConnections++;
			}
			return FALSE;
		}
	}
}

/**********************************************/

long LogDumpFile (TCPStreamPtr stream)
{
unsigned long bytes;
//ContentType ctype;
Boolean actionDone;
PluginRole role = Plugin_Standard_Role;

	bytes = 0;
	stream->log_this = L_LOG_IT;
	
	if (stream->fileType != FILE_BINARY)
		HTTP_DisposeContentRange (stream);

	if (stream->method == METHOD_AUTHORIZE) {
		HTTP_AuthorizeResponse (stream);
		LogConnection (stream); // totalConnections++;
		if (stream->f) fclose (stream->f);
		stream->f = NULL;
		return 0;
	}
	else if (stream->method == METHOD_HEAD && stream->fileType <= FILE_TEXT) {
		if (stream->found==1)
			HTTP_Respond (stream, R_OK, "");
		else
			HTTP_Respond (stream, R_NOT_FOUND, "");
		LogConnection (stream); // totalConnections++;
		if (stream->f) fclose (stream->f);
		stream->f = NULL;
		return 0;
	}
	else {
		//see if there are any special actions to take here. If so, do them.
		actionDone = FALSE;
		
		switch (stream->actionTaken) {
			case A_DIR_REDIRECT: //the client sent a malformed directory URL. It needs to be redirected.
				HTTP_DirRedirectResponse (stream);
				actionDone = TRUE;
				break;
				
			default:
				break;
		}
		
		if (!actionDone) {
			
			switch (stream->fileType) {
				case FILE_BINARY:
					if (debugLevel) TTY_WriteMessage("(Binary) ", FALSE);
					if (LogNotConditionalGet (stream))
						bytes = LogDumpBinaryFile (stream, TRUE);
					break;
					
				case FILE_RAW:
					if (debugLevel) TTY_WriteMessage("(RAW!) ", FALSE);
					if (LogNotConditionalGet (stream))
						bytes = LogDumpBinaryFile (stream, FALSE);
					break;
					
				case FILE_TEXT:
					if (debugLevel) TTY_WriteMessage("(Text) ", FALSE);
					if (LogNotConditionalGet (stream))
						bytes = LogDumpTextFile (stream);
					break;
				
				case FILE_SCRIPT:
					if (debugLevel) TTY_WriteMessage("(Script) ", FALSE);
					bytes = LogExecuteScriptFile (stream);
					break;
					
				case FILE_APPL:
					if (debugLevel) TTY_WriteMessage("(Application) ", FALSE);
					bytes = LogExecuteAPPLFile (stream);
					break;
					
				case FILE_CGI:
					if (debugLevel) TTY_WriteMessage("(CGI Application) ", FALSE);
					bytes = LogExecuteCGIFile (stream);
					break;
		
				case FILE_ACGI:
					if (debugLevel) TTY_WriteMessage("(ACGI Application) ", FALSE);
					bytes = LogExecuteACGIFile (stream);
					break;
		
				case FILE_ACTION:
					if (debugLevel) TTY_WriteMessage("(Action Application) ", FALSE);
					
					//adjust the role variable if we're running a plug-in. default is CGI role.
					if (stream->action && 
						((stream->action)->kind == A_PLUGIN || (stream->action)->kind == A_ACTION)) {
						if (stream->actionTaken == A_ERROR) {
							role = Plugin_Error_Role;
						}
						else if (stream->actionTaken == A_NOACCESS) {
							role = Plugin_NoAccess_Role;
						}
						else if (stream->actionTaken == A_INDEX) { 
							role = Plugin_Index_Role;
						}
						
						//run the plug-in
						bytes = Plugin_Action (stream, role); //more logic here when real plugins work
						//Do what's expected of us -- go to still_writing even though we're done
						stream->state = still_writing;
						stream->t_k = bytes;
					}
					else if ((stream->action)->kind == A_ACGI)
						bytes = LogExecuteACGIFile (stream);
					else 
						bytes = 0;
					break;
			}
			bytesSent += bytes;
			LogUpdateStats();
			return bytes;
		}/*if !actionDone*/
	}//else
	
	return 0;
}

/**********************************************/

short LogStillWriting (TCPStreamPtr stream)
{
short stillWriting;
	stillWriting = FALSE;
	switch (stream->fileType) {
		case FILE_BINARY:
			stillWriting = LogStillWritingBinary (stream);
			break;
			
		case FILE_TEXT:
			stillWriting = LogStillWritingText (stream);
			break;
		
		case FILE_SCRIPT:
			break;
			
		case FILE_APPL:
			break;			
		
		case FILE_CGI:
			break;
		
		case FILE_ACGI:
		case FILE_ACTION:
			stillWriting = LogStillWritingACGI(stream);
			break;
	}
	if (!stillWriting) {
		bytesSent += stream->t_k;
		LogUpdateStats();
	}

	return (stillWriting);
}

/**********************************************/

void LogReportState (TCPStreamPtr stream, char *msg, byte state, unsigned short pending)
{
char s[128];
char statestr[32], eventstr[64], reasonstr[24];
	if (stream->lastState != state || stream->lastPend != pending || 
						stream->lastEvt!=stream->s_event) {
		stream->lastState = state;
		stream->lastPend = pending;
		stream->lastEvt = stream->s_event;
		if (debugLevel) {
			switch (state) {
				case 0:
					strcpy (statestr, "Closed");
					break;
				case 2:
					strcpy (statestr, "Listen");
					break;
				case 4:
					strcpy (statestr, "SYN received");
					break;
				case 6:
					strcpy (statestr, "SYN sent");
					break;
				case 8:
					strcpy (statestr, "Established");
					break;
				case 10:
					strcpy (statestr, "FIN Wait 1");
					break;
				case 12:
					strcpy (statestr, "FIN Wait 2");
					break;
				case 14:
					strcpy (statestr, "Close Wait");
					break;
				case 16:
					strcpy (statestr, "Closing");
					break;
				case 18:
					strcpy (statestr, "Last Ack");
					break;
				case 20:
					strcpy (statestr, "Time Wait");
					break;
				default:
					sprintf (statestr, "Unknown (%d)", state);
					break;
			}
			
			if (ASRIsValid(stream))
				switch (stream->lastEvt) {
					case TCPClosing:
						strcpy (eventstr, "Closing");
						break;
					case TCPULPTimeout:
						strcpy (eventstr, "ULP Timeout");
						break;
					case TCPTerminate:
						switch (stream->terminate_reason) {
							case TCPRemoteAbort:
								strcpy (reasonstr, "TCPRemoteAbort");
								break;
							case TCPNetworkFailure:
								strcpy (reasonstr, "TCPNetworkFailure");
								break;
							case TCPSecPrecMismatch:
								strcpy (reasonstr, "TCPSecPrecMismatch");
								break;
							case TCPULPTimeoutTerminate:
								strcpy (reasonstr, "TCPULPTimeoutTerminate");
								break;
							case TCPULPAbort:
								strcpy (reasonstr, "TCPULPAbort");
								break;
							case TCPULPClose:
								strcpy (reasonstr, "TCPULPClose");
								break;
							case TCPServiceError:
								strcpy (reasonstr, "TCPServiceError");
								break;
							default:
								sprintf (reasonstr, "Unknown (%d)", stream->terminate_reason);
								break;
						}
						sprintf (eventstr, "Terminate (%s)", reasonstr);
						break;
					case TCPDataArrival:
						strcpy (eventstr, "Data Arrival");
						break;
					case TCPUrgent:
						strcpy (eventstr, "Urgent");
						break;
					case TCPICMPReceived:
						strcpy (eventstr, "ICMP Received");
						break;
					default:
						sprintf (eventstr, "Unknown (%d)", stream->lastEvt);
						break;
				}
			else
				strcpy (eventstr, "No ASR event");
				
			sprintf (s, "Con %lu: St: %s, Evt: %s, unread %u, %s", 
					stream->id, statestr, eventstr, pending, msg);
			TTY_WriteMessage(s, TRUE);
		}
		//stream->lastEvt = stream->s_event=0;
	}
}

/**********************************************/

#define CodeRedErr	-23050

void LogIdle()
{
	OSErr err;
	byte state;
	unsigned short pending;
	unsigned long bytesRead;
	long remoteHost;
	short remotePort;
	short commandDone;
#if AUX_SUPPORT
	short stillListening;
#endif
	TCPStreamPtr stream, sptr;
	char s[REQUEST_SIZE+2];
	
	unsigned long bytes;
	unsigned long timer;
	short stillWriting;
	time_t now;
	
	//DebugStr((StringPtr)"\pInside main idle routine");
	
	LogMemCheck((long *) &timer); /*timer is reused here...*/
	
	LogUpdateStats();
	
	Plugin_Idle();
	
	time(&now);
	
	//see if it's time to roll over the log file (assuming logging is enabled and the user wants it)
	if (Get_LogCutInterval () && !Get_SuspendLogFlag () && 
		(now > (Get_LogCutIntervalSecs () + Get_LastLogCut ()))) {
		HTTP_CutLogFile ();
	}
	
	timer = TickCount() + PIG_DELAY;	//get the current time once
	if (threadsOK)
	{
		do
		{
			YieldToAnyThread();
		} while (TickCount() <= timer);
	}
	
	else
	{
		do {
			stillWriting = FALSE;
			stream = streams;
		
			while (stream) {
				stream->last_query_time = TickCount (); //we're reusing the somewhat unused last_query_time field here to track the last time this thread got CPU time
				
				switch (stream->state) {
					case inactive:
						sptr = stream;
						stream = stream->next;
						DeleteStream (sptr);
						break;
					
					case listening:
						stream->flags |= STREAM_FLAG_LISTEN;
						
						if (StreamIsTerminated (stream)) { //transitions to state terminated if true
							stream->flags |= STREAM_FLAG_LISTEN_TERMINATE;
							break;
						}
							
						if ((stream->rblock)->ioResult <= 0 || stream->s_event != 0) { /*got a connection*/
							
							if (stream->s_event == TCPDataArrival) { //this is a special case that MAY not be correct to allow in as a connection. worst case should be a timeout/
								gDataBeforeListen++;
								stream->flags |= STREAM_FLAG_LISTEN_DATA;
							}
							else if (stream->s_event != 0) {
								stream->flags |= STREAM_FLAG_LISTEN_OTHEREVT;
							}
							
#if AUX_SUPPORT
							stillListening = FALSE;
							
							if (running_AUX) {
								err = StreamStatus (stream->stream, &state, &pending);
								if (debugLevel) {
									sprintf (s, "Con: %lu Stream Status (L) err=%d", stream->id, err);
									TTY_WriteMessage(" ", TRUE);
									TTY_WriteMessage(s, TRUE);
								}
								
								if (err == connectionDoesntExist)
									stillListening = TRUE;
									
								LogReportState (stream, "Listening", state, pending);
							}
							
																	
							if (!stillListening) {
#endif
								err = AsyncGetConnectionData (stream->rblock, &remoteHost, &remotePort);
								stream->remoteHost = remoteHost;
								HTTP_IPAddrToName(remoteHost, stream->host_name);
								if (debugLevel) {
									sprintf (s, "Connected %lu to %s", stream->id, stream->host_name);
									TTY_WriteMessage(s, TRUE);
								}
								stream->rblock = NULL;
								LogStartTimeout (stream, MAX_TIMEOUT); /*start the timer up*/
								currListens--;
								
								/*too busy to queue listen?*/
								if (currConnections>=(MAX_STREAMS)) {
									if (debugLevel) {
										TTY_WriteMessage (" ", TRUE);
										TTY_WriteMessage ("Server is busy.", TRUE);
									}
									
									stream->is_http10 = TRUE;
									HTTP_Respond (stream, R_TOO_BUSY, "Sorry. The server is too busy now.");
									
									//err = SendData(stream->stream, "Server is too busy. Sorry.\r\n\r\n",
									//				(unsigned short) 30,false, (Ptr) stream);	
									sprintf(s,"Closing connection. Too busy.");
									TTY_WriteMessage(s, TRUE);
									//LogCloseStream(stream);
									//LogOpenPassive (stream); /*listen again on last remaining stream*/ 
									//currListens++;
									currConnections++;
									busyConnections++;
									stream->state = closing;
									stream->flags |= STREAM_FLAG_LISTEN_BUSY;
								}
								else if (refuseConnections) {
									if (debugLevel) {
										TTY_WriteMessage(" ", TRUE);
										TTY_WriteMessage ("Connection Refused.", TRUE);
									}
									
									HTTP_RefusedResponse (stream);
		//							err = SendData(stream->stream, "Server is refusing new connections. Sorry.\r\n\r\n",
		//											(unsigned short) 46,false);	
									currConnections++;
									stream->state = closing;
									//LogCloseStream(stream);
									//LogOpenPassive (stream); /*listen again on last remaining stream*/ 
									//currListens++;
								}
								else { /*not too busy, open a new "listen"*/
									currConnections++;
									stream->state = reading;
									stream->flags |= STREAM_FLAG_LISTEN_READING;
								}
								LogUpdateStats();
#if AUX_SUPPORT
							}
#endif
						}
						stream = stream->next;
						break;
						
					case reading:
						if (StreamIsTerminated (stream))
							break;

						pending = state = commandDone = 0;
						err = StreamStatus (stream->stream, &state, &pending);
						if (err) {
							if (debugLevel) {
								sprintf (s, "Con: %lu Stream Status (1) err=%d", stream->id, err);
								TTY_WriteMessage(" ", TRUE);
								TTY_WriteMessage(s, TRUE);
							}
							if (err==connectionDoesntExist)
								stream->state = closed;
						}
						else {
							LogReportState (stream, "Reading", state, pending);
							
							if (pending) { /*there's data to read*/
								LogStartTimeout (stream, MAX_TIMEOUT); /*reset the timer*/
								bytesRead = 0;
								err = ReadData (stream->stream, s, &bytesRead);
								if (err) {
									if (err == connectionClosing) {
										TTY_WriteMessage("###early exit!!!", TRUE);
										stream->state = closing;
									}
									else {
										sprintf (s, "Error reading data %d", err);
										TTY_WriteMessage(s, TRUE);
									}
								}
								else { /*read was OK*/
									stream->commandDone = HTTP_AddData(s, bytesRead, stream);
									LogStartTimeout (stream, MAX_TIMEOUT); /*reset the timer*/
								}
							}
							
							if (stream->commandDone) {
								//code red type checks here instead of inside ReadData
								err = HTTP_CheckTriggers (stream);
								
								if (err == CodeRedErr) {
									//sprintf (s, "Code Red type request %05ld ignored, connection to %s closed.", stream->id, stream->host_name);
									//TTY_WriteMessage(s, TRUE);
									err = CloseStreamConnection(stream->stream);
									stream->state = closed;
									stream->log_this = L_LOG_IT;
									stream->found = 3; //ultimately will represent a disconnect action, but is PRIV for now
									safecpy (stream->url_fname, "Windows_Virus_Request", ARG_SIZE);
									stream->search_args [0] = '\0';
								}
								else {					
									stream->state = writing;
								}
							}
						}
						
						if (LogTimeout(stream)) {
							stream->state = closing; /*clean up defunct connections*/
							if (debugLevel) {
								sprintf (s, "Reading Timeout stream %lu", stream->id);
								TTY_WriteMessage(s, TRUE);
							}
						}
						
						stream = stream->next;
						break;
			
					case writing:				
						if (StreamIsTerminated (stream))
							break;

						HTTP_DoGetCommand(stream);
		
						if (stream->fileType == FILE_VERSION) { /*report the server version info*/
							sprintf (s, "<title>MacHTTP Version</title>%s", COPYRIGHT1);
							LogMakeStatusReport (s);
							strcat (s, HTTP_RESP_2CRLF);
							err = SendData(stream->stream, s, (unsigned short) strlen (s),false);
#if REMOTE_TCP_REPORT
							LogTCPIPReport (stream);
#endif

							stream->log_this = L_LOG_IT;
							stream->state = closing;
						}
						else {
							if (debugLevel) {
								sprintf (s, "File Found = %d", stream->found);
								TTY_WriteMessage(s, TRUE);
							}
							if (stream->found==2) { /*security violation*/
								if (stream->method != METHOD_AUTHORIZE) {
									deniedConnections++;
									LogUpdateStats();
								}
							}
							bytes = LogDumpFile (stream); /*open and send (part of?) the file*/
							LogStartTimeout (stream, MAX_TIMEOUT); /*reset the time-out*/
							if (stream->state == writing) {
								sprintf (s, "%s\t%s\t%s%s%s\t%ld", 
										stream->found ? (stream->found==1?"OK  ":"PRIV") :"ERR!", 
										stream->host_name, stream->url_fname, stream->search_args[0] ? "?" : "", stream->search_args, bytes);
								HTTP_LogMessage(s);
								stream->log_this = L_LOGGED_IT;
								stream->state = closing;
							}
							/*else the state has been changed to still_writing internal to LogDumpFile*/
							else stillWriting = TRUE;
						}
		
						if (LogTimeout(stream)) {
							stream->state = closing; /*clean up defunct connections*/
							if (debugLevel) {
								sprintf (s, "Writing Timeout stream %lu", stream->id);
								TTY_WriteMessage(s, TRUE);
							}
						}
						stream = stream->next;
						break;
					
					case still_writing:
						if (StreamIsTerminated (stream))
							break;

						if (!LogStillWriting (stream)) { /*only transition to close if writing is complete*/
							sprintf (s, "%s\t%s\t%s%s%s\t%ld", 
										stream->found ? (stream->found==1?"OK  ":"PRIV") :"ERR!", 
										stream->host_name, stream->url_fname, stream->search_args[0] ? "?" : "", 
										stream->search_args, stream->t_k);
							HTTP_LogMessage(s);
							stream->log_this = L_LOGGED_IT;
							stream->state = closing;
						}
						else {
							if (debugLevel) {
		//						sprintf (s,"Still writing %ld", stream->id);
		//						TTY_WriteMessage (s, TRUE);
							}
							stillWriting = TRUE;
						}
						
						if (LogTimeout(stream)) {
							stream->state = closing; /*clean up defunct connections*/
							if (debugLevel) {
								sprintf (s, "Writing Timeout stream %lu", stream->id);
								TTY_WriteMessage(s, TRUE);
							}
						}
						stream = stream->next;
						break;
						
					case closing:
						LogReportState (stream, "Closing", state, pending);
						if (stream->stream) {
							err = CloseStreamConnection(stream->stream);
							if (err && debugLevel) {
								sprintf (s, "Closing Err (%lu) %d", stream->id, err);
								TTY_WriteMessage(s, TRUE);
							}
						}
		
						//LogStartTimeout (stream, CLOSE_TIMEOUT); /*hack to fix Mac Mosaic's close problem*/
		
						/*if (LogTimeout(stream))*/ stream->state = closed;
						stream = stream->next;
						break;
					
					case closed:
						if (stream->log_this == L_LOG_IT) {
							sprintf (s, "%s\t%s\t%s%s%s\t%ld", 
									stream->found ? (stream->found==1?"OK  ":"PRIV") :"ERR!", 
									stream->host_name, stream->url_fname, stream->search_args[0] ? "?" : "", stream->search_args, stream->t_k);
							HTTP_LogMessage(s);
							stream->log_this = L_LOGGED_IT;
						}
		
						err = StreamStatus (stream->stream, &state, &pending);
						if (err) {
							if (err != connectionDoesntExist && debugLevel) {
								if (debugLevel) {
									sprintf (s, "Stream Status (2) err=%d", err);
									TTY_WriteMessage(" ", TRUE);
									TTY_WriteMessage(s, TRUE);
								}
							}
						}
						
						LogReportState (stream, "Closed", state, pending);
		
						if (pending && !LogTimeout(stream) && state != 0 && stream->s_event!=TCPTerminate ) {
							bytesRead = 0;
							err = ReadData(stream->stream, s, &bytesRead);
							if (err && debugLevel) {
								sprintf (s, "Closed Read error %d", err);
								if (debugLevel) TTY_WriteMessage (s, TRUE);
							}
//							else
//								if (debugLevel) TTY_WriteMessage(s, TRUE);
						}
						else if (state==0 || /*state==12 ||*/ stream->s_event==TCPTerminate || LogTimeout (stream)) { /*closing or terminated*/
							if (LogTimeout(stream)) {
								timeoutConnections++;
								if (debugLevel) {
									sprintf (s, "Timed out %lu", stream->id);
									TTY_WriteMessage(s, TRUE);
								}
							}
							stream->state = terminated;
							if (stream->method != METHOD_UNKNOWN) { /*we must have already done something, log it!*/
								sprintf (s, "%s\t%s\t%s%s%s\t%ld", 
										stream->found ? (stream->found==1?"OK  ":"PRIV") :"ERR!", 
										stream->host_name, stream->url_fname, stream->search_args[0] ? "?" : "", stream->search_args, bytes);
							//	HTTP_LogMessage(s);
							}
						}
						
						stream = stream->next;
						break;
						
					case terminated:
						LogReleaseStream(stream);
						stream = stream->next;
						currConnections--;
						LogUpdateStats();
						break;
						
					default:
						sprintf (s, "Conn: (%lu(, Unknown HTTP State %d", stream->id, stream->state);
						TTY_WriteMessage(s, TRUE);
						stream = stream->next;
						break;
				} /*switch*/
				
				/*if things aren't too busy, make sure the max # of listens are queued*/
				if ((currListens<MAX_LISTENS && currConnections<MAX_STREAMS) || currListens<=0)
					LogQueueListens();
			
			} /*while streams*/
			
		} while (timer > TickCount() && stillWriting);
	} /*else not threaded*/	
}

/**********************************************/

void LogShutdown()
{
TCPStreamPtr s;
	s = streams;
	while (s) {
		if (s->stream || s->state != inactive)
			LogCloseStream(s);
		s = s->next;
	}
	
	HTTP_Shutdown();
	ShutdownNetwork ();
}


/**********************************************/

OSErr ReadData (unsigned long stream, char *s, unsigned long *bytesRead)
//read bytesRead bytes, or the default amount if *bytesRead is zero
{
	OSErr			err;
	unsigned short	dataLength;
	
	if (bytesRead == NULL)
		return -1;
		
	if (*bytesRead == 0)
		dataLength = REQUEST_SIZE - 2;
	else
		dataLength = *bytesRead;
		
	*bytesRead = 0;
	
	err = RecvData(stream, s, &dataLength, false, kTimeOut);
	s[dataLength] = '\0';
	*bytesRead = dataLength;
	
	return(err);
}

/**********************************************/

void GetDStr(short item, char *str)
{
	Rect r;
	short len,type;
	Handle h;

	GetDialogItem(theWin, item, &type, &h, &r);
	GetDialogItemText(h, (StringPtr) str);
	len = str[0];
	strncpy(str, &str[1], len);
	str[len] = '\0';
}

/**********************************************/

void LogRefuseConnections (short refuse)
{
	refuseConnections = refuse;
	LogDrawRefuseIcon (refuseConnections);
	if (debugLevel) {
		if (refuse)
			TTY_WriteMessage("Incoming connections are being refused.", TRUE);
		else
			TTY_WriteMessage("Incoming connections are being accepted.", TRUE);
	}
}

/**********************************************/

void LogDebug(short level)
{
	debugLevel = level;
}

/**********************************************/

void LogRun()
{

}

/**********************************************/
/* this routine would normally be a callback for giving time to background apps */
#define GT_DELAY 15
static long lastTime = 0;
	
Boolean mainGiveTime(short sleepTime);

Boolean GiveTime(short sleepTime)
{
#if THREAD_SUPPORT
	unsigned long idle;
	
	if (threadsOK)
	{
		idle = TickCount() + PIG_DELAY;
		do
		{
			YieldToAnyThread();
		} while (TickCount() <= idle);
		
		return true;
	}
#endif

	return mainGiveTime(sleepTime);
}

#if REMOTE_TCP_REPORT
/**********************************************/

void LogTCPIPReport (TCPStreamPtr cstream) {

TCPStreamPtr sptr = streams;
char s [512];
char *output = NULL;
OSErr err = noErr;
unsigned long curTick = 0;
char star = ' ';
char stateStr [32];
ThreadState threadState;

	output = (char *) NewPtr (32768);
	if (output == NULL)
		return;
	else 
		output [0] = '\0';
		
	if (cstream != NULL)
		strcpy (output, "<p><pre>");
			
	strcat (output, "\r-------------------------------------------------\r  TCP/IP Stream and Thread Report\r\r");
	
	sprintf (s, "Globals - MAX_STREAMS: %hd, MAX_LISTENS: %hd, currConnections: %hd, currListens: %hd\r",
		MAX_STREAMS, MAX_LISTENS, currConnections, currListens);
	strcat (output, s);
	
	sprintf (s, "threadsOK %d, OS version %lX, OT version %s, MacTCP version %s\r",
		threadsOK, gOSVersion, "?", "?");
	strcat (output, s);
	
	sprintf (s, "%lu connections terminated by client, %lu connections had data arrive before listen completed.\r",
		gTerminatedConnections, gDataBeforeListen);
	strcat (output, s);
	
	sprintf (s, "Current TickCount: %lu\r", curTick = TickCount ());
	strcat (output, s);
	
	while (sptr != NULL) {
		strcpy (stateStr, "ready to run");
		if ((unsigned long) (curTick - sptr->last_query_time) > 1200) {
			star = '*';
			if (threadsOK) {
				err = GetThreadState (sptr->thread_id, &threadState);
				sprintf (stateStr, "%s (%d)", threadState == kStoppedThreadState ? "stopped!!!" : "ready to run");
			
				if (threadState == kStoppedThreadState) 
					err = SetThreadState (sptr->thread_id, kReadyThreadState, sptr->thread_id);
			}
		}
		else {
			star = ' ';
		}
			
		sprintf (s, "\r%c ID: %lu, Thread ID: %lu, Last ran: %lu, Last ASR: %lu, State: %s\r", star, sptr->id, sptr->thread_id, sptr->last_query_time, sptr->asr_time, tcpStreamStateText [sptr->state]);
		strcat (output, s);
		sprintf (s, "s_event: %hu, timeout: %lu, terminate_reason: %hu\r", sptr->s_event, sptr->timeout, sptr->terminate_reason);
		strcat (output, s);
		if (sptr->rblock) {
			sprintf (s, "rblock->ioResult: %ld, ", (long) (sptr->rblock)->ioResult);
			strcat (output, s);
		}
		sprintf (s, "thread state: %s, commandDone: %hu, found: %hu, Flags: %0lX\r", stateStr, sptr->commandDone, sptr->found, sptr->flags);
		strcat (output, s);
		sptr = sptr->next;
	}
	
	if (cstream != NULL) {
		strcat (output, "</pre>");
		err = SendData(cstream->stream, output, (unsigned short) strlen (output),false);
	}
	else
		TTY_WriteMessage (output, TRUE);
		
	DisposePtr (output);
}
#endif