/*http.c*/
/******************************************************
 *
 * Lawyer stuff:
 *
 * MacHTTP 2.x, source code
 * Copyright �1993-2001 Chuck Shotton
 * All Rights Reserved.
 *
 * This source code is made available under the terms of the MacHTTP Source License.
 * This license grants you the right to use the source code to create new versions
 * of and derivative works from the original MacHTTP source code. Under the terms of
 * this license, any modifications made to the source code must be made available in
 * source code form to the general public and the MacHTTP.Org organization. You may not
 * redistribute source code or binary versions of the MacHTTP application that make use of
 * the MacHTTP name, logo, or icons without the expressed written consent of MacHTTP.Org
 * or Chuck Shotton.
 *
 * MacHTTP is a trademark of Chuck Shotton. Permission is granted
 * to MacHTTP.Org and its assignees use the MacHTTP name, logo, and icons.
 * Any use not authorized by MacHTTP.Org or Chuck Shotton is prohibited.
 *
 * Additional information can be found at http://www.machttp.org/
 *
 ******************************************************
 * Modifications:
 *
 * 03/01/01 - cshotton - initial version
 * 10/22/01 - rpatters1 - added changes to implement HOSTFOLDER
 * 10/23/01 - rpatters1 - moved prepend code to beginning of routine, so it gets copied to url_realname
 * 10/28/01 - rpatters1 - changed HOSTFOLDER code to use HTTP_UpCase()
 * 10/28/01 - rpatters1 - changed all conversion of ip address to string to use HTTP_AddrToStr()
 * 10/28/01 - rpatters1 - implemented DNS_EXCLUDE logic
 * 11/16/01 - rpatters1 - remove port number (if any) from hostname
 * 11/18/01 - rpatters1 - modernized and de-linted
 * 11/21/01 - rpatters1 - split HTTP_GetHostFolder into that plus HTTP_GetHostFolderPtr
 * 11/24/01 - rpatters1 - initialize most_recent field in HostFolderStruct
 * 01/14/02 - instantware - new HTTP_DisposeContentRange() -> dispose linked list of ByteRanges
 * 01/14/02 - instantware - changed HTTP_InterpretHeaderField() -> added handling of "range:" header requests
 * 01/14/02 - instantware - rewritten HTTP_ParseHeaderFields() now handles almost unlimited line length
 * 01/16/02 - instantware - bug fix: HTTP_ParseHeaderFields() [introduced on 01/14/02] skipped the last header line
 * 02/02/02 - instantware - 68000 bug fix: HTTP_ParseHeaderFields() [introduced on 01/14/02] word/long access to an odd address
 * 02/02/02 - instantware - bug fix: HTTP_DoGetCommand() very long referer strings are now truncated
 * 02/10/02 - instantware - disable smart catenation of overlapping content ranges in HTTP_InterpretHeaderField()
 * 02/17/02 - rpatters1 - allow HOSTFOLDER * as a catchall
 * 03/10/02 - cshotton - significant changes to AddData, IsComplete, etc. to improve object body handling
 ******************************************************/
#include "config.h"

#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>

#include <MacTypes.h>
#include <MacMemory.h>
#include <MacWindows.h>
#include <Files.h>
#include <Controls.h>
#include <StringCompare.h>
#include <Threads.h>

#include "MacTCPCommonTypes.h"
#include "TCPPB.h"
#include "TCPHi.h"
#include "http.h"
#include "ResolvePath.h"
#include "TTY_Messages.h"
#include "Template.h"
#include "HTTP_ParseRequest.h"
#include "Prefs.h"
#include "HTTP_Properties.h"
#include "HTTP_IPCaching.h"
#include "Error_Messages.h"
#include "Plugin.h"
#include "Logic.h"
#include "PW_UI.h"
#include "HTUU.h"

#include "global_types.h"
#include "globals.h"

char *methodTokens[METHOD_UNKNOWN+1] = {"GET", "HEAD", "POST", "CONDITIONAL_GET", "Authorize", "UNKNOWN"};

char *typeTokens[FILE_UNKNOWN] = {"BINARY", "TEXT", "SCRIPT", "APPL", "CGI", "ACGI", "PLUGIN", "RAW",
								"!@#$", "DEFAULT", "INDEX", "ERROR", "LOG",
								"ALLOW", "DENY", "NOACCESS", "PORT", 
								"MAXUSERS", "MAXLISTENS", "TIMEOUT",
								"MIME", "DOC_ROOT", "VERSION", 
								"PIG_DELAY", "DUMP_BUF_SIZE", "NO_DNS", "REALM",
								"ACTION", "SUFFIX", "LOG_FORMAT",
								"LOG_ROLLOVER", "HOSTFOLDER", "DNS_EXCLUDE",
								"FOREGROUNDTICKS", "BACKGROUNDTICKS", "USE_THREADS"};

static SuffixListNodePtr suffix_list = NULL, suffix_list_tail = NULL;

static FILE *log_f;

static AccessCtlPtr access_list;
static RealmStructPtr realms = NULL, realms_tail = NULL;
static ActionPtr actions = NULL;
static HostFolderPtr hostfolder_list = NULL;
static DNSExcludePtr dns_exclude_list = NULL;

/******************************/
void safecpy (char *d, char *s, short len)
{
	if (strlen(s)<len)
		strcpy (d, s);
	else {
		strncpy (d, s, len-1);
		d [len-1] = '\0';
	}
}

/*********************************************/

char *HTTP_UpCase (char *s);
char *HTTP_UpCase (char *s)
{
	short x;
	for (x=0;x<strlen(s); x++)
		s[x]=toupper(s[x]);
	return (s);
}

/*********************************************/

short HTTP_strcmp (char *s1, char *s2)
{
//	return strcmp (s1, s2);
	return IUMagIDString((Ptr) s1, (Ptr) s2, strlen (s1), strlen (s2));
}

/*********************************************/

short HTTP_strncmp (char *s1, char *s2, size_t n)
{
//	return strncmp (s1, s2, n);
	return IUMagIDString((Ptr) s1, (Ptr) s2, (short) n, (short) n);
}

/*********************************************/

ContentType HTTP_TokenType(char *token)
{
ContentType i;
		
	for (i=(ContentType)0;i<FILE_UNKNOWN;i++)
		if (!strcmp(token,typeTokens[i]))
			return i;
			
	return FILE_UNKNOWN;
}

/*********************************************/

FILE *HTTP_fopen(char *fname, char *mode)
{
char path[258];
char s[512];
OSErr err;
Boolean wasAlias, wasFolder;
FSSpec spec;

	err = ResolvePathAlias (fname, path, sizeof (path)-1, &spec, &wasFolder, &wasAlias);
//old code...
//	safecpy (path, fname, sizeof (path));
//	err = HTTP_ResolvePath(path, 256, FALSE, &wasAlias);

	if (err) {
		if (debugLevel) {
			TTY_WriteMessage(" ", TRUE);
			sprintf (s, "WARNING: Can't open file! (%s) Path=%s",
				Error_Message (err), path);
			TTY_WriteMessage(s, TRUE);
		}
		return NULL;
	}
	else {
		return (fopen (path, mode));
	}
}

/*********************************************/

void HTTP_AddSuffix (ContentType kind, ActionPtr act, short argct, char *arg, char *arg2, char *arg3, char *arg4, short userDefined)
{
SuffixListNodePtr list_node;
SuffixTypePtr new_suffix;

	//First, check to make sure this is a legit suffix mapping. Don't add it if it's not.
	if (kind == FILE_ACTION && act == NULL) {
		TTY_WriteMessage ("###ERR: A suffix mapping was encountered with an undefined Action!", TRUE);
		return;
	}
	
	/*make the new suffix type node*/
	new_suffix = (SuffixTypePtr) NewPtr (sizeof (SuffixType));
	if (new_suffix) {

		/*hook it to a new list node*/
		list_node = (SuffixListNodePtr) NewPtr (sizeof (SuffixListNode));
		if (list_node) {

			/*fill it in*/
			list_node->next = NULL;
			list_node->suffix = new_suffix;
			
			new_suffix->kind = kind;
			new_suffix->action = act;
			new_suffix->userDefined = userDefined;
			safecpy (new_suffix->str, HTTP_UpCase(arg), SUFFIX_LEN-2);

			/*type*/
			if (argct>2) {
				HTTP_TranslateString (arg2, 32);
				strncpy ((char *) &(new_suffix->ftype), arg2, 4);
			}
			else
				new_suffix->ftype = '???\?';
				
			/*creator*/
			if (argct>3) {
				HTTP_TranslateString (arg3, 32);
				strncpy ((char *) &(new_suffix->fcreator), arg3, 4);
			}
			else
				new_suffix->fcreator = '???\?';
				
			/*MIME Type*/
			if (argct>4)
				safecpy (new_suffix->mime_type, arg4, MIME_TYPE_SIZE-1);
			else
				safecpy (new_suffix->mime_type, "*/*", MIME_TYPE_SIZE-1);
			
			/*hook it into the suffix list*/
			if (suffix_list_tail != NULL) {
				suffix_list_tail->next = list_node;
				suffix_list_tail = list_node;
			}
			else {
				suffix_list = suffix_list_tail = list_node;
			}
		}
		else {
			TTY_WriteMessage ("ERROR: Unable to allocate memory for suffix list node!", TRUE);
			LogMemoryError();
		}
	}
	else {
		TTY_WriteMessage ("ERROR: Unable to allocate memory for suffix mapping data!", TRUE);
		LogMemoryError();
	}

}

/*********************************************/

void HTTP_AddRealm (char *r, char *rname)
{
RealmStructPtr new_realm;

	/*make the new realm node*/
	new_realm = (RealmStructPtr) NewPtr (sizeof (RealmStruct));
	if (new_realm) {

		/*fill it in*/
		new_realm->next = NULL;
		safecpy (new_realm->realm, HTTP_UpCase(r), 32);
		safecpy (new_realm->realmName, rname, 64);

		/*hook it into the realm list*/
		if (realms_tail) {
			realms_tail->next = new_realm;
			realms_tail = new_realm;
		}
		else {
			realms = realms_tail = new_realm;
		}
		
		UI_BuildRealmMenu ((unsigned char*)CtoPstr (rname));
	}
	else {
		TTY_WriteMessage ("ERROR: Unable to allocate memory for realm list!", TRUE);
		LogMemoryError();
	}
}

/*********************************************/

void HTTP_GetRealm (short num, StringPtr s)
{
	RealmStructPtr temp;
	short i;
	
	if (!realms) {
		s[0] = '\0';
	}
	else {
		temp = realms;
		for (i=0; i< (num-1); i++)
			if (temp)
				temp = temp->next;
		safecpy ((char *) s, temp->realmName, 64);
		CtoPstr ((char *) s);
	}
}

/*********************************************/

ActionPtr HTTP_AddAction (char *atag, char *apath, ActionTakenKind kind, short userDefined, void *ref)
{
ActionPtr new_action;
char path[1024];
OSErr err;
Boolean wasAlias, wasFolder;
FSSpec spec;

	/*make the new realm node*/
	new_action = (ActionPtr) NewPtr (sizeof (ActionStruct));
	if (new_action) {

		/*fill it in*/
		new_action->next = actions;
		new_action->userDefined = userDefined;
		safecpy(new_action->tag, HTTP_UpCase(atag), ACTION_TAG_SIZE-2);
		
		HTTP_TranslateString (apath, FILE_NAME_SIZE-2);
		
		safecpy(new_action->path, apath, FILE_NAME_SIZE-2);		

		err = ResolvePathAlias (apath, path, sizeof (path), &spec, &wasFolder, &wasAlias);
//		safecpy (path, apath, 1023);
//		err = HTTP_ResolvePath (path, sizeof (path), FALSE, &wasAlias);
		
		if (!err) {
    		CtoPstr (path);
   			err = FSMakeFSSpec(0, 0, (StringPtr) path, &(new_action->fs));
		}

		if (err) { //make sure the fsspec is invalid
			new_action->fs.vRefNum = 0;
			new_action->fs.parID = 0;
			new_action->fs.name [0] = '\0';
		}
				
		new_action->kind = kind;
		new_action->refcon = ref;

		actions = new_action;
		return (actions);
	}
	else {
		TTY_WriteMessage ("ERROR: Unable to allocate memory for action list!", TRUE);
//		LogMemCheck(&memcheck);;
		return (NULL);
	}
}

/*********************************************/

ActionPtr HTTP_FindAction (char *act)
{
ActionPtr temp;
	temp = actions;
	while (temp) {
		if (!HTTP_strcmp (temp->tag, act))
			return (temp);
		else
			temp = temp->next;
	}
	return (NULL);
}

/*********************************************/

void HTTP_DeleteAllActions ()
{
//delete all actions except those defined by plug-ins, etc.
ActionPtr temp,act,keepers;
	act = actions;
	keepers = NULL;
	while (act) {
		if (act->userDefined) {
			temp = act;
			act = act->next;
			if (temp == actions)
				actions = act;
			DisposePtr ((Ptr) temp);
		}
		else {
			temp = act;
			act = act->next;
			temp->next = keepers;
			keepers = temp;
		}
	}
	actions = keepers;
}

/*********************************************/

void HTTP_LoadConfig()
{
FILE *f;
short ix, argct;
char s[256];
char token[34], arg[64], arg2[256], arg3[64], arg4[64], arg5[64]; //, arg6[6];
ContentType kind;
AccessCtlPtr ctl, taccess;
short version_match = 0;
OSErr err;
HostFolderPtr thostfolder;
DNSExcludePtr tdnsexclude;
int j;
	strcpy (default_html, DEFAULT_HTML);
	strcpy (error_html, ERROR_HTML);
	strcpy (log_file, LOG_FILE);
	strcpy (noaccess_html, NOACCESS_HTML);
	strcpy (defaultMIMEType, DEFAULT_MIME_TYPE);
	strcpy (doc_root, DEFAULT_DOC_ROOT);
	access_list = taccess = ctl = NULL;
	no_dns = FALSE;
	suffix_list = suffix_list_tail = NULL;
	hostfolder_list = thostfolder = NULL;
	dns_exclude_list = tdnsexclude = NULL;
	
	f = HTTP_fopen(CONFIG_FILE, "r");
	if (f) {
		TTY_WriteMessage("Loading MacHTTP.config...", TRUE);
		ix = 0;
		s [0] = '\0';
		fgets (s,200,f);
		
		while (!feof(f) || strlen (s)) {
			if (s [0] == '#' || s [0] == '\n') {
			s[0]='\0';
			if (!feof(f)) fgets (s,200,f);
				continue;
			}
				
//			for (i=0;i<strlen(s);i++) s[i]=toupper(s[i]);
			token[0] = arg[0] = arg2[0] = arg3[0] = arg4[0] = arg5[0] = '\0';
			argct = sscanf(s, "%62s %62s %254s %62s %62s %62s", token, arg, arg2, arg3, arg4, arg5);
			if (argct) {
				if (argct<2) arg[0]='\0';
				switch (kind = HTTP_TokenType(HTTP_UpCase(token))) {
					case FILE_UNKNOWN:
						break;
					case FILE_DEFAULT:
						if ((defaultDocType = HTTP_TokenType(arg))==FILE_UNKNOWN)
							defaultDocType = FILE_BINARY;
						else {
							/*set the default mime type*/
							if (argct>2) {
								strcpy (defaultMIMEType, arg2);
							}
							else {
								strcpy (defaultMIMEType, DEFAULT_MIME_TYPE);
							}
						}
						break;

					case FILE_BINARY:
					case FILE_TEXT:
					case FILE_SCRIPT:
					case FILE_APPL:
					case FILE_CGI:
					case FILE_ACGI:
					case FILE_RAW:
						HTTP_AddSuffix (kind, NULL, argct, arg, arg2, arg3, arg4, 1);
						break;
						
					case FILE_SUFFIX:
						
						if (argct==6) {
							kind = HTTP_TokenType(HTTP_UpCase(arg));
							switch (kind) {
								case FILE_BINARY://
								case FILE_TEXT://
								case FILE_SCRIPT://
								case FILE_APPL://
								case FILE_CGI://
								case FILE_ACGI://
								case FILE_PLUGIN:
								case FILE_RAW:
										HTTP_AddSuffix (kind, NULL, argct-1, arg2, arg3, arg4, arg5, 1);
										break;
								default:
									HTTP_AddSuffix (FILE_ACTION, HTTP_FindAction (arg), argct-1, arg2, arg3, arg4, arg5, 1);
									break;
							}
						}
						else if (debugLevel) 
							TTY_WriteMessage ("Note: Plug-in defined suffix mapping not loaded.", 1);
						break;
			
					case FILE_INDEX:
						strcpy (default_html, arg);
						break;
						
					case FILE_ERROR:
						strcpy (error_html, arg);
						break;
						
					case FILE_LOG:
						strcpy (log_file, arg);
						break;
						
					case FILE_NOACCESS:
						strcpy (noaccess_html, arg);
						break;
						
					case FILE_ALLOW:
					case FILE_DENY:
						ctl = (AccessCtlPtr) malloc (sizeof (AccessCtlStruct));
						if (ctl) {
							strcpy (ctl->data, arg);
							ctl->allow = kind;
							ctl->next = NULL;
						
							/*stuff it in the access list*/
							if (access_list == NULL) {
								access_list = ctl;
								taccess = access_list;
							}
							else {
								taccess->next = ctl;
								taccess = ctl;
							}
						}
						break;
						
					case FILE_HOST_FOLDER:
						{
							HostFolderPtr hf = (HostFolderPtr) malloc (sizeof (HostFolderStruct));
							if ( hf != NULL ) {
								strcpy (hf->hostname, arg);
								HTTP_UpCase (hf->hostname);
								strcpy (hf->foldername, arg2);
								hf->connections = 0;
								hf->most_recent = 0;
								hf->next = NULL;
								
								sprintf (s, ":%s", arg2);
								/* Translate / to :, for "real" path /'s */
								for (j=0; j<strlen(s); j++)
									if (s[j]=='/') s[j]=':';

								err = ResolvePathAlias (s, NULL, 0, &hf->fs, NULL, NULL); //fill in a FSSpec for the host folder
								
								/* stuff it in the hostfolder list*/
								if ( hostfolder_list == NULL ) {
									hostfolder_list = hf;
									thostfolder = hostfolder_list;
								}
								else {
									thostfolder->next = hf;
									thostfolder = hf;
								}
							}
						}
						break;
						
					case FILE_DNS_EXCLUDE:
						{
							DNSExcludePtr dnsexc = malloc (sizeof (DNSExcludeStruct));
							if (dnsexc != NULL) {
								strcpy (dnsexc->ip_string, arg);
								dnsexc->ip_strlen = strlen(arg);
								dnsexc->next = NULL;
							
								/*stuff it in the access list*/
								if (dns_exclude_list == NULL) {
									dns_exclude_list = dnsexc;
									tdnsexclude = dns_exclude_list;
								}
								else {
									tdnsexclude->next = dnsexc;
									tdnsexclude = dnsexc;
								}
							}
						}
						break;
						
					case FILE_PORT:
						if (!(kHTTPPort = atol (arg)))
							kHTTPPort = 80;
						if (kHTTPPort<1 || kHTTPPort>0xFFFF)
							kHTTPPort = 80;
						break;
						
					case FILE_MAXUSERS:
						err = Set_MaxStreams (atoi (arg));
						break;
						
					case FILE_MAXLISTENS:
						err = Set_MaxListens (atoi (arg));
						break;
						
					case FILE_TIMEOUT:
						err = Set_Timeout (atoi (arg));
						break;
						
					case FILE_CONFIG_VERSION:
						strcpy(s, (char *) VERSION_STR);
						if (!strncmp (arg, &s[1], s[0]))
							version_match = 2;
						else
							version_match = 1;
						break;
						
					case FILE_DOC_ROOT:
						strcpy (doc_root, arg);
						HTTP_TranslateString (doc_root, 256);
						break;
						
					case FILE_PIG_DELAY:
						err = Set_PigDelay (atoi (arg));
						break;
						
					case FILE_FOREGROUNDTICKS:
						err = Set_ForegroundTicks (atol (arg));
						break;
						
					case FILE_BACKGROUNDTICKS:
						err = Set_BackgroundTicks (atol (arg));
						break;
						
					case FILE_USE_THREADS:
						gUseThreads = TRUE;
						break;
						
					case FILE_DUMP_BUF_SIZE:
						err = Set_DumpBufSize (atoi (arg));
						break;
						
					case FILE_NO_DNS:
						err = Set_NoDNS (TRUE);
						break;
						
					case FILE_REALM:
						if (argct>2) {
							HTTP_AddRealm (arg, arg2);
						}
						else {
							sprintf (s, "### ERROR: Realm definition for \"%s\" is missing args!", arg);
							TTY_WriteMessage (s, TRUE);
						}
						break;
						
					case FILE_ACTION:
						if (argct==3 || (argct>3 && atoi(arg3))) {			//don't load actions from plug-ins
							HTTP_AddAction (arg, arg2, A_ACGI, 1, NULL);
						}
						else if (argct<3) {
							sprintf (s, "### ERROR: Action definition for \"%s\" is missing args!", arg);
							TTY_WriteMessage (s, TRUE);
						}
						break;
						
					case FILE_LOG_ROLLOVER:
						Set_LogCutInterval (atoi (arg));
						break;
				}
			}
			s[0]='\0';
			if (!feof(f)) fgets (s,200,f);
		}
		fclose (f);
	}
	else TTY_WriteMessage("No config file found. Using internal defaults.", TRUE);
	
	/*Now make sure everything is consistent*/
	
	if (MAX_LISTENS>=MAX_STREAMS)
		MAX_LISTENS = MAX_STREAMS-1;
	
	if (version_match<2) {
		TTY_WriteMessage (" ", TRUE);
		if (!version_match) {
			TTY_WriteMessage ("########", TRUE);
			TTY_WriteMessage ("WARNING!!! The config file doesn't contain a VERSION statement and may be", TRUE);
			TTY_WriteMessage ("   too old to use safely with MacHTTP. Please use the correct version.", TRUE);
			TTY_WriteMessage ("", TRUE);
		}
		else {
			TTY_WriteMessage ("########", TRUE);
			TTY_WriteMessage ("WARNING!!! The config file's version doesn't match MacHTTP's version.", TRUE);
			TTY_WriteMessage ("   This may cause problems with file types and suffix mapping.", TRUE);
			TTY_WriteMessage ("   Modify the VERSION statement in the config file.\r", TRUE);
		}
	}
}


/*********************************************/

void HTTP_SaveDefaultFileInfo (TCPStreamPtr stream, MinimalTCPStreamPtr min)
{
	if (!stream || !min) return;
	
	min->found = stream->found;
	min->fileType = stream->fileType;
	min->actionTaken = stream->actionTaken;
	min->action = stream->action;
//	min->saved_action = stream->saved_action;
	min->ftype = stream->ftype;
	min->fcreator = stream->fcreator;
//	min->whichRealm = stream->fc.whichRealm;
//	min->fs = stream->fs;
	strcpy (min->mime_type, stream->mime_type);
	strcpy (min->mac_fname, stream->mac_fname);
}

/*********************************************/

void HTTP_RestoreDefaultFileInfo (MinimalTCPStreamPtr min, TCPStreamPtr stream)
{
	if (!stream || !min) return;
	
	stream->found = min->found;
	stream->fileType = min->fileType;
	if (stream->actionTaken != A_DIR_REDIRECT)
		stream->actionTaken = min->actionTaken; //don't overwrite a directory redirect
	stream->action = min->action;
//	stream->saved_action = min->saved_action;
	stream->ftype = min->ftype;
	stream->fcreator = min->fcreator;
//	stream->fc.whichRealm = min->whichRealm;
//	stream->fs = min->fs;
	strcpy (stream->mime_type, min->mime_type);
//	strcpy (stream->mac_fname, min->mac_fname);
	strcpy (stream->mac_fname, min->mac_fname);
//	stream->mac_fname = min->mac_fname;
//	stream->cacheWhenDone = false;	//we don't want to accidentally cache this info
}

/*********************************************/

OSErr HTTP_DefaultNameToFileInfo (char *name, MinimalTCPStreamPtr min)
{
TCPStreamPtr stream;
char suffix[SUFFIX_LEN];

	stream = (TCPStreamPtr) NewPtr (sizeof (TCPStream));
	if (!stream) {
		TTY_WriteMessage("ERROR: Unable to make temporary stream variable for MIME defaults.", TRUE);
		return -1;
	}
	
	memset (stream, 0, sizeof (TCPStream));
	safecpy (stream->url_fname, name, URL_SIZE);
//	stream->mac_fname = stream->url_fname;
	safecpy (stream->mac_fname, name, FILE_NAME_SIZE);
	HTTP_ExtractSuffix(name, suffix);
	HTTP_UpCase(suffix);
	HTTP_FindFileType (stream, name, suffix);
	HTTP_SaveDefaultFileInfo (stream, min);
	
	DisposePtr ((Ptr) stream);
	return (noErr);	
}

/*********************************************/

void HTTP_GetMIMETypeForDefaults ()
{
OSErr err;
//char s[FILE_NAME_SIZE];
	err = HTTP_DefaultNameToFileInfo (error_html, &error_info);
	err = HTTP_DefaultNameToFileInfo (noaccess_html, &noaccess_info);

	if (noaccess_info.action != NULL) {
		/*Warning - no access has an action defined*/
		TTY_WriteMessage ("Warning - no access has an action defined as its handler!", TRUE);
	}
}

/*********************************************/

short HTTP_LoggingEnabled()
{
	return (strlen(log_file)>0);
}

/*********************************************/

void HTTP_InitLogging()
{
	char s [260];
	FInfo fi;
	OSErr err;
	
	if (logging && log_f) return;
	
	log_f = fopen(log_file, "ab");
	if (log_f) {
		logging = TRUE;
		//set the appropriate type and creator
		strcpy (s, log_file);
		CtoPstr (s);
		err = GetFInfo ((StringPtr) s, 0, &fi);
		if (err == noErr) {
			fi.fdType = 'TEXT';
			fi.fdCreator = 'R*ch';
			err = SetFInfo ((StringPtr) s, 0, &fi);
		}
	}
	else {
		logging = FALSE;
	}
}

/*********************************************/

void HTTP_LogMessage(char *s)
{
	time_t now;
	struct tm *date;
	char timeStr[80];
	char st[URL_SIZE+64];

	time (&now);
	date = localtime (&now);
	strftime (timeStr, 80, "%m/%d/%y\t%H:%M:%S ", date);
	sprintf (st, "%s\t", timeStr);
	strncat (st, s, URL_SIZE);
	strcat (st, "\r");
	TTY_WriteMessage(st, FALSE);
	
	if (logging)
	{
		fwrite (st, 1, strlen (st), log_f);
		fflush (log_f);
	}
}

/*********************************************/

void HTTP_StopLogging()
{
	if (logging) {
		fflush (log_f);
		fclose (log_f);
		logging = FALSE;
	}
}

/*********************************************/

void HTTP_CutLogFile ()
{
	OSErr err;
	time_t now;
	struct tm *date;
	char olds [256], news [256];
	
	if (Get_LogCutInterval ()) {
		TTY_WriteMessage ("Archiving log file now.", TRUE);
		if (!Get_SuspendLogFlag ()) {
		//if logging is enabled
			//close the log file
			HTTP_StopLogging ();
			//rename the old log file
			time (&now);
			date = localtime (&now);
			strftime (olds, 255, "%Y%m%d-%H%M", date);
			sprintf (news, "%s %s", log_file, olds);
			strcpy (olds, log_file);
			CtoPstr (news);
			CtoPstr (olds);
			Rename ((StringPtr) olds, 0, (StringPtr) news);
			//open a new log file
			HTTP_InitLogging ();
			//remember the time we cut the log file
			Set_LastLogCut (time (NULL));
			err = Prefs_WriteSettings ();
		}
	}
}

/*********************************************/

void HTTP_Init()
{
char s[512];

	Plugin_Register ();
	
	HTTP_LoadConfig();
	HTTP_GetMIMETypeForDefaults ();

	Plugin_Init ();
	
	logging = FALSE;
	log_f = NULL;
	if (strlen(log_file)) HTTP_InitLogging();
	
	sprintf (s, "%s Server is running on port %d.", PROCESSOR_STRING, kHTTPPort);
	TTY_WriteMessage(s,TRUE);
	TTY_WriteMessage(" ",TRUE);
#if BETA_VERSION
	sprintf (s, "WARNING! This beta version of MacHTTP expires %d/%d/%d. %s", 
			BETA_EXP_MONTH, BETA_EXP_DAY, BETA_EXP_YEAR, BETA_MSG);
	TTY_WriteMessage(s,TRUE);
	TTY_WriteMessage(" ",TRUE);
#endif
}

/*********************************************/

void HTTP_Shutdown()
{
	Plugin_Shutdown ();
	if (logging) HTTP_StopLogging();
}

/*********************************************/

short HTTP_IsComplete (TCPStreamPtr stream, unsigned long *post_start)
{
int i, j, len;
char cr = (char) 13, lf = (char) 10;
short crs, lfs;
short crsfound = FALSE, found = FALSE;
	
	//find the first line so we can see if this is a HTTP/1.0 request or not
	i=0;
	len = stream->request_byte_count;
	//skip the method
	while (i<len && stream->request [i] != ' ') i++;
	//skip the spaces
	while (i<len && stream->request [i] == ' ') i++;
	//skip the path
	while (i<len && stream->request [i] != ' ' && stream->request [i] != cr && stream->request [i] != lf) i++;
	// if anything is after the path besides EOL, it's a HTTP/1.x request
	if (i<len && stream->request [i] != cr && stream->request [i] != lf) {
		j=i;
		*post_start = 0;
		/*look for 2 crs or 2 lfs in a row*/
		crs = lfs = found = 0;
		for (i=j;i<len;i++) {
			if (stream->request[i]==cr && !found) {
				if (crs++>0) 
					crsfound = TRUE;
			}
			else if (stream->request[i]==lf && lfs<2) {
				if (lfs++>0 && crsfound) 
					found = TRUE;
			}
			else {
				crs = lfs = 0;
				if (found) {
					*post_start = i;
					break;
				}
			}
		}
	}
	else if (stream->request [i] == cr || stream->request [i] == lf) { //this is a HTTP 0.9 request, no more request to read
		found = TRUE;
		*post_start = 0;
	}
	
	return (found);
}	


/*********************************************/

OSErr HTTP_CheckTriggers (TCPStreamPtr stream) {
//ultimately, this routine will look up and process user defined patterns and associated actions.
//for now, it's  used to scan for Win32 virus signatures in HTTP requests which will trigger connection termination.
	char	s128;
	OSErr	err = noErr;
	
	if (stream == NULL || stream->request == NULL)
		return noErr;
	
	s128 = stream->request [128];		// backup char in position 128
	stream->request [128] = '\0';		// don�t want to look up the whole data for Code Red
						// signature, therefore terminate string at pos. 128.
	if (strstr(stream->request, ".exe?/c+")) {
		err = CodeRedErr;
	}
	else if (strstr (stream->request, "default.ida?")) {
		err = CodeRedErr;
	}
	
	stream->request [128] = s128;		// restore char in position 128
	
	return err;
}

/*********************************************/

unsigned char HexChar(unsigned char c)
{
char *hex = "0123456789ABCDEF";
short k;
	c=toupper(c);
	for (k=0;k<16;k++) 
		if (c==hex[k]) return k;
	return 0;
}

/*********************************************/

void HTTP_TranslateString(char *str, unsigned short size)
{
char temp[REQUEST_SIZE];
short i,j;
unsigned char bite;
	i=j=0;
	while (str[i] && j<REQUEST_SIZE-1) {
		if (str[i]=='%') {
			i++;
			bite = HexChar(str[i++])<<4;
			bite += HexChar(str[i++]);
			temp[j++] = bite;
		}
		else temp[j++] = str[i++];
	}
	temp[j]='\0';
	safecpy (str, temp, size);
}

/*********************************************/

short HTTP_ExtractMethod (TCPStreamPtr stream, char *s)
{
char command[64];
short i=0;
HTTPMethod m;
	command[0]='\0';
	i=sscanf (s, "%63s", command);
	for (i=0;i<strlen(command) && i<63;i++) {
		command[i] = toupper(command[i]);
	}
	
	for (m = METHOD_GET; m < METHOD_UNKNOWN; m++) {
		if (!strcmp (command, methodTokens [m])) break;
	}
	stream->method = m;
	
	return (m!=METHOD_UNKNOWN);
}

/*********************************************/

void HTTP_ExtractPath (TCPStreamPtr stream, char *s, char *filename, char *args)
{
short i=0;
short j, x;
char last;
short eff_filename_max = REQUEST_SIZE;
char hostfolder[URL_SIZE];
short hostfolder_len;
//char temp [FILE_NAME_SIZE];

	if (debugLevel) {
		TTY_WriteMessage (" ", TRUE);
		TTY_WriteMessage("### Received: ", TRUE);
		last = s [4000];
		s [4000] = '\0';
		TTY_WriteMessage(s, TRUE);
		s [4000] = last;
	}
	
	/* prepend host folder name, if any */
	hostfolder_len = HTTP_GetHostFolder (stream, hostfolder);
	if ( hostfolder_len > 0 ) {
		/* kill any trailing '/', since we only need one, and the real URL will supply it */
		if ( hostfolder[hostfolder_len-1] == '/' ) {
			hostfolder[hostfolder_len-1] = '\0';
			hostfolder_len--;
		}
		eff_filename_max -= hostfolder_len;
		
		if (debugLevel) {
			TTY_WriteMessage (" ", TRUE);
			TTY_WriteMessage("### Redirecting to HOSTFOLDER: ", TRUE);
			TTY_WriteMessage(hostfolder, TRUE);
		}	
	}
	
	//### following could be a buffer overrun problem
	strcpy ( filename, hostfolder );
	
	/*Skip the command*/
	while (isspace(s[i])) i++;
	while (!isspace(s[i])) i++;
	while (isspace(s[i])) i++;
	
	j = i; /*save the start*/
	
	/*Extract only the filename (breaks at whitespace or ? or $)*/
	while (isgraph(s[j]) && s[j]!='?' && s[j]!='$') j++;
	/* if the filename doesn't start with '/' and we prepended a hostfolder, better fix it */
	/* this code is mostly for peace of mind, since I don't know if it can actually happen */
	if ( (hostfolder_len > 0) && (s[i] != '/') ) {
		strcat ( filename, "/" );
		hostfolder_len++;
		eff_filename_max--;
	}
	strncat (filename, &s[i], (j-i) < eff_filename_max ? (j-i) : (eff_filename_max-1));
	filename[hostfolder_len+j-i] = '\0';
	//added the following, moving it from 3 lines below because we need the original path from the URL in realname
	x = (j-i) < (URL_SIZE-1) ? (j-i) : URL_SIZE-1;
	strncpy (stream->url_realname, &s[i], x);
	stream->url_realname [x] = '\0';
	
	if ((j-i)>=eff_filename_max) { /*file name is too long!*/
		TTY_WriteMessage ("ERROR! File name in URL is too long!", TRUE);
	}
//###%CTS this is not the right place to do this. realname should be the unadulterated URL path.	safecpy (stream->url_realname, filename, URL_SIZE-1);

	/*now parse the path args,if any*/
	i=0;
	if (s[j]=='$') {
		j++;
		while (s[j]!='?' && isgraph(s[j]) && i<(PATH_ARG_SIZE-1))
			stream->path_args[i++] = s[j++];
		stream->path_args[i]='\0';
		
		if (i>=(PATH_ARG_SIZE-1)) {
			TTY_WriteMessage ("ERROR! Path argument in URL is too long!", TRUE);
		}
			
	}
	else args[0]='\0';

	/*now parse the search args,if any*/
	i=0;
	if (s[j]=='?') {
		while (isgraph(s[++j])  && i<(PATH_ARG_SIZE-1))
			args[i++] = s[j];
		args[i]='\0';

		if (i>=(PATH_ARG_SIZE-1)) {
			TTY_WriteMessage ("ERROR! Search argument in URL is too long!", TRUE);
		}
	}
	else args[0]='\0';

	/*look for HTTP/1.0 info... This is a lame check and needs to be fixed*/
	if (s[j]) {
		while (isspace(s[j])) j++;
		if (isgraph(s[j]))
			stream->is_http10 = TRUE;
	}
/*	strcpy (temp, doc_root);*/
/*	strcat (temp, filename);*/
/*	strcpy (filename, temp);*/
	
//	HTTP_TranslateString (args, PATH_ARG_SIZE-1);

/* Translate / to :, for "real" path /'s */
	for (j=0; j<strlen(filename); j++)
		if (filename[j]=='/') filename[j]=':';

/* convert specials (to allow /'s in file names) */
	HTTP_TranslateString (filename, REQUEST_SIZE-1);
	
/*now look for "::" and turn into ":"*/
	last=' ';
	j=0;
	while (filename[j]) {
		if (filename[j]==':' && last==':')
			strcpy (&filename[j-1], &filename[j]);
		else last = filename[j++];
	}
	
	if (!strlen(filename) || !strcmp(filename, ":") || filename[j-1]==':') { /*no path or /, return default*/
		if (debugLevel) TTY_WriteMessage("Returning Home Page", TRUE);
		//strcpy(filename, default_html);
		strcat(filename, default_html);
	}
		
	//handle problems with no leading colon
	if (filename[0]!=':') {
		filename [strlen (filename)+1] = '\0';
		CtoPstr (filename);
		filename [0] = ':';
	}
}

/*********************************************/

void HTTP_IfModified (TCPStreamPtr stream, char *s)
{
/*stick the if-modified date in the post args bucket*/
short i=0;
	while (*s != ' ' && *s) s++;
	while (*s == ' ' && *s) s++;
	while (*s && *s!='\r' && *s!='\n')
		if (i<DATE_SIZE-1) (stream->if_modified_date)[i++] = *(s++);
	(stream->if_modified_date)[i] = '\0';
}

/*********************************************/

void HTTP_DisposeContentRange(TCPStreamPtr stream)
{
	Ptr		p;
	
	while (stream->content_range)
	{
		p = (Ptr)stream->content_range;
		stream->content_range = stream->content_range->next;
		DisposePtr(p);
	}; 
	stream->content_range = NULL;
}


long HTTP_InterpretHeaderField (TCPStreamPtr stream, char *s)
{
	Boolean b;
	char	c;
	short	i, j, mLen, sLen, tLen;
	long	cs;
	char	temp[MAX_LINE_LENGTH], mode[24], password[512], decoded[URL_SIZE];
	ByteRangePtr ContentRange;
	
	if (!(sLen = strlen(s)))
		return 0;
	
	sscanf (s, "%1023s", temp);
	tLen = strlen (temp);
	
	for (i = 0; i < tLen; i++)
		temp[i] = toupper (temp[i]);
		
/** Content-Length **/
	if (!strncmp (temp, "CONTENT-LENGTH:", tLen)) {
		cs = 0;
		sscanf (s, "%1023s %ld", temp, &cs);
		stream->content_length = cs;
		return (cs);
	}
/** Authorization **/
	else if (!strncmp (temp, "AUTHORIZATION:", tLen)) {
		mode [0] = '\0';
		password [0] = '\0';
		i = sscanf (s, "%1023s %23s %511s", temp, mode, password);
		if (debugLevel) {
			sprintf (s, "mode: %s, password: %s", mode, password);
			TTY_WriteMessage (s, TRUE);
		}
		mLen = strlen(mode);
		for (i = 0; i < mLen; i++)
			mode[i] = toupper (mode[i]);
		
		if (!strncmp (mode, "BASIC", mLen)) {
			i = HTUU_decode (password, (unsigned char*)decoded, 510);
			decoded [i]= '\0';
			i = sscanf (decoded, "%31[^:]%*[:]%31[^:]", stream->user_name, stream->password);
//			HTTP_UpCase (stream->user_name);
//			HTTP_UpCase (stream->password);

			if (debugLevel) {
				sprintf (s, "username: %s, password: %s", stream->user_name, stream->password);
				TTY_WriteMessage (s, TRUE);
			}
		}
		else /*this is an unsupported authentication mode, pass info as the username*/
			safecpy (stream->user_name, password, USER_NAME_SIZE-1);
	
		return 0;
	}

/** If-Modified-Since **/
	else if (!strncmp (temp, "IF-MODIFIED-SINCE:", tLen)) {
		HTTP_IfModified (stream, s);
		/*Don't do conditional stuff if password authorization is required.*/
		if (stream->method != METHOD_AUTHORIZE)
			stream->method = METHOD_CONDITIONAL;
		return 0;
	}
/** From **/
	else if (!strncmp (temp, "FROM:", tLen)) {
		decoded [0] = '\0';
		sscanf (s, "%s %s", temp, decoded);
		strncpy (stream->from_user, decoded, FROM_USER_SIZE);
		return 0;
	}
/** Content-Type **/
	else if (!strncmp (temp, "CONTENT-TYPE:", tLen)) {
		decoded [0] = '\0';
		sscanf (s, "%1023s %1023s", temp, decoded);
		strncpy (stream->content_type, decoded, MIME_TYPE_SIZE);
		return 0;
	}
/** Referer **/
	else if (!strncmp (temp, "REFERER:", tLen)) {
		decoded [0] = '\0';
		sscanf (s, "%1023s %1023s", temp, decoded);
		strncpy (stream->url_referer, decoded, URL_SIZE-2);
		return 0;
	}
/** User-Agent **/
	else if (!strncmp (temp, "USER-AGENT:", tLen)) {
		i=11;
		while (!isspace(s[i]) && i < sLen) i++;
		while (isspace (s[i]) && i < sLen) i++;
		strncpy (stream->user_agent, &s[i], FILE_NAME_SIZE-2);
		return 0;
	}
/** Host **/
	else if (!strncmp (temp, "HOST:", tLen)) {
		i=5;
		while (!isspace(s[i]) && i < sLen) i++;
		while (isspace (s[i]) && i < sLen) i++;
		strncpy (stream->hdr_host_name, &s[i], HOST_NAME_SIZE-2);
		// the raw Host: field includes the port number, if specified, so we
		// need to remove it.
		for (i=strlen(stream->hdr_host_name)-1; i>=0; i--) {
			if ( stream->hdr_host_name[i] == ':' ) {
				stream->hdr_host_name[i] = '\0';
				break;
			}
			if ( !isdigit(stream->hdr_host_name[i]) )
				break;
		}
		return 0;
	}
/** Ranges: **/
	else if (!strncmp (temp, "RANGE:", tLen))
	{
		i = 7;
		while (s[i] != '=' && i < sLen) i++;
		
		if (i < sLen)
		{
			ContentRange = (ByteRangePtr)NewPtrClear(sizeof(ByteRange));
			stream->content_range = ContentRange;
			do
			{
				j = 0;
				do
				{
					i++;
					c = s[i];
					b = ('0' <= c && c <= '9');
					if (b)
						temp[j++] = c;
				}
				while (b || c == ' ' || c == '\t');
				temp[j] = '\0';
				
				if (c == '-')
					ContentRange->begin = (temp[0]) ? atol(temp) : -1;
				
				else if (c == ',' || c == '\0')
				{
					ContentRange->end = (temp[0]) ? atol(temp) : -1;
				
					/**** Catenation of overlapping byte ranges ****/
					// PDF-Viewers seem to have problems with this HTTP/1.1 behaviour
					// For enabling catenation "false &&" needs to be removed
					if (false && ContentRange->prev && ContentRange->prev->end >= 0 && ContentRange->prev->end + 1 == ContentRange->begin)
					{
						ContentRange->prev->end = ContentRange->end;
						if (i >= sLen)
						{
							ContentRange = ContentRange->prev;
							DisposePtr((Ptr)ContentRange->next);
							ContentRange->next = NULL;
						}
					}
						
					else if (i < sLen)
					{
						ContentRange->next = (ByteRangePtr)NewPtrClear(sizeof(ByteRange));
						ContentRange->next->prev = ContentRange;
						ContentRange = ContentRange->next;
					}
				}
				
				else	// byte range error -> clean up and exit
				{
					HTTP_DisposeContentRange(stream);
					
					if (debugLevel)
						TTY_WriteMessage("Error in Range-Header", true);
						
					return 0;
				}
			}
			while (i < sLen);
		}
		
		return 0;
	}
/** not found **/
	else
		return 0;
}

/*********************************************/

void HTTP_ExtractPostArgs (TCPStreamPtr stream)
{
short i, j;
long content_size, k;
char cr, lf, ch, *req; //*pargs, 
short crs, lfs, found;
char temp[MAX_LINE_LENGTH];
short oops = FALSE;

	/*first, allocate a buffer to hold the post args.*/
//	if (stream->post_args = (char *) NewPtr (POST_ARG_SIZE+2)) {
//		pargs = stream->post_args;
		req = stream->request;
//		pargs[0] = '\0';

		if (!req) {
			TTY_WriteMessage ("ERROR: trying to parse args from null request", TRUE);
			return;
		}		

		/*now, look for the blank line indicating the end of the HTTP header*/
		/* while we're at it, look for the content-length tag*/
		cr = (char) 13;
		lf = (char) 10;

		i = 0;
		j=0;
		content_size = 0;
		lfs = crs = 0;
		found = FALSE;
		while ((ch=req[i]) && !found) {
			if (ch==cr) {
				if (crs++>0) 
					found = TRUE;
				else {
					temp [j] = '\0';
					if (j) {
						k = HTTP_InterpretHeaderField (stream, temp);
						if (k)
							content_size = k;
					}
					j=0;
					oops = FALSE;
				}
			}
			else if (ch==lf) {
				if (lfs++>0) 
					found = TRUE;
				else {
					temp [j] = '\0';
					if (j) {
						k = HTTP_InterpretHeaderField (stream, temp);
						if (k)
							content_size = k;
					}
					j=0;
					oops = FALSE;
				}
			}
			else {
				crs = lfs = 0;
				temp [j] = ch;
				if (j<MAX_LINE_LENGTH-1)
					j++;
				else {
					if (!oops) {
						TTY_WriteMessage ("Warning: the following HTTP header line is too long!", TRUE);
						temp [j] = '\0';
						TTY_WriteMessage (temp, TRUE);
						oops = TRUE;
					}
				}
			}
			
			i++;
		}
		
		if (found) {
			/*find the start of the POST args*/
			while (req[i]==cr || req[i]==lf) i++;
			/*copy the data*/
			if (content_size) {
//				strncpy (pargs, &(req[i]), content_size);
//				pargs [content_size] = '\0';
				stream->post_args = &req[i];
//				stream->post_args [content_size] = '\0'; //no longer needed because AddData ensures a null
			}
			else {
//				strcpy (pargs, &(req[i]));
				stream->post_args = &req[i];
			}
			stream->post_arg_byte_count = stream->request_byte_count - i + 1;
		}
//	}
//	else {
//		TTY_WriteMessage ("Error: Unable to allocate memory for POST arguments!", TRUE);
//		LogMemoryError();
//		stream->post_args = NULL;
//	}
}

/*********************************************/

void HTTP_ParseHeaderFields (TCPStreamPtr stream)
{
	#define CR 13
	#define LF 10

	Boolean	done;
	char	*req, *temp;
	short	i;
	long	hSize;
	Handle	h;
	
	// a search within .pdf-documents may produce a huge number of
	// content-range requests which might exceed all static limits
	// therefore the size of temp is now variable.
	hSize = MAX_LINE_LENGTH;
	h = NewHandle(hSize);
	MoveHHi(h);
	HLock(h);
	temp = *h;
	
	req = stream->request;
	
	/*now, look for the blank line indicating the end of the HTTP header*/
	i = 0;
	done = false;
	do
	{
		if (*req == CR && *(req+1) == LF)
		{
			req += 2;
			if (*req == CR && *(req+1) == LF)
				done = true;

			temp[i] = '\0';
			if (i)
			{
				HTTP_InterpretHeaderField(stream, temp);
				i = 0;
			}
		}
		
		else {
			temp[i++] = *req++;
			if (i == hSize)
			{
				HUnlock(h);
				SetHandleSize(h, hSize + MAX_LINE_LENGTH);
				if (MemError())
				{
					TTY_WriteMessage("Warning: the following HTTP header line is too long and is ignored!", true);
					temp[61] = temp[62] = temp[63] = '.';
					temp[64] = '\0';
					TTY_WriteMessage(temp, true);
				}
				else
				{
					hSize += MAX_LINE_LENGTH;
					MoveHHi(h);
				}
				HLock(h);
				temp = *h;
			}
		}
	} while (!done && *req);
	
	DisposeHandle(h);
}

/*********************************************/

short HTTP_LookupPassword (char *name, char *pw, char *realm)
{
/* Find the username�realm STR resource and check its value*/

char password [256];
char tpassword [256];
char username [256];
	

/*Build the username...*/
	safecpy (username, name, USER_NAME_SIZE-1);
	HTTP_UpCase (username);
	
	strcat (username, "�");
	if (realm)
		strcat (username, realm);

	if (debugLevel) {
		sprintf (password, " Looking for user name %s", username);
		TTY_WriteMessage (password, TRUE);
	}

	Prefs_GetPassword ((unsigned char*)CtoPstr(username), (StringPtr) password);
	PtoCstr ((StringPtr) password);
	HTTP_UpCase (password);
	
	safecpy (tpassword, pw, PASSWORD_SIZE-1);
	HTTP_UpCase (tpassword);
	
	if (strlen (password)) {
		return (!strcmp (password, tpassword));
	}
	else return 0;
}

/*********************************************/

short HTTP_NeedsAuthentication (TCPStreamPtr stream)
{
RealmStructPtr tRealms;
char fname [FILE_NAME_SIZE];
	safecpy (fname, stream->mac_fname, FILE_NAME_SIZE-1);
	HTTP_UpCase (fname);
	tRealms = realms;
	while (tRealms) {
		if (strstr (fname, tRealms->realm)) {
			stream->whichRealm = tRealms;
			return 1;
		}
		else
			tRealms = tRealms->next;
	}
	stream->whichRealm = NULL;
	return 0;
}

/*********************************************/

short HTTP_AuthorizationCheck (TCPStreamPtr stream)
{
char s[256];
	/*see if we need to demand authorization*/
	if (HTTP_NeedsAuthentication (stream)) {
		/*yes, so see if there is a valid password for the realm*/

		if (debugLevel) {
			sprintf (s, " Authentication required for realm %s", (stream->whichRealm)->realm);
			TTY_WriteMessage (s, TRUE);
		}

		/*see if there is a username supplied*/
		if (stream->user_name[0]) {
			/*is it a valid username/password/realm for this server?*/
			if (HTTP_LookupPassword (stream->user_name, stream->password, (stream->whichRealm)->realmName))
				return 0; /*it matched, let 'em in*/
			else if (debugLevel) {
				TTY_WriteMessage ("Password was incorrect!", TRUE);
			}
		}

		/*either the name wasn't supplied or it was a bad password*/
		/*so, see if the file requires authentication or not*/

		stream->method = METHOD_AUTHORIZE;
		return 1;
	}
	else
		return 0;
}

/*********************************************/

short HTTP_SecurityCheck (TCPStreamPtr stream)
{
char ip_str[32];
AccessCtlPtr p;
short allowed;
short t_len, h_len, i;
long ip;
char *filename;

	ip = stream->remoteHost;
	filename = stream->mac_fname;

	/*convert IP address to string*/
	HTTP_AddrToStr (ip, ip_str);
//	sprintf (ip_str, "%u.%u.%u.%u.", ((unsigned char *) &ip)[0], ((unsigned char *) &ip)[1],
//			((unsigned char *) &ip)[2], ((unsigned char *) &ip)[3]); 
			
	/*determine if the file can be accessed by the host in question*/
	p = access_list;
	allowed = access_list == NULL; /*if it's empty, no security applied*/
	
	h_len = strlen (stream->host_name);
	
	while (p) {
		t_len = strlen (p->data);
		if (isdigit (p->data[0])) { /*check by IP address*/
			if (!strncmp (ip_str, p->data, t_len)) {
				if (p->allow == FILE_ALLOW)
					allowed = TRUE;
				else
					allowed = FALSE;
			}
		}
		else { /*check by host name*/
			if (h_len<t_len)
				i = 0;
			else
				i = h_len - t_len;
			if (!strncmp (&(stream->host_name[i]), p->data, t_len)) {
				if (p->allow == FILE_ALLOW)
					allowed = TRUE;
				else
					allowed = FALSE;
			}
		}
		
		p = p->next;
	}
	
	if (!allowed) { /*access not allowed from remote address*/
		safecpy (filename, noaccess_html, FILE_NAME_SIZE-1);
		return 1;
	}
	else {
		return HTTP_AuthorizationCheck (stream);
	}
}

/*********************************************/

short HTTP_DontSendMacHTTP (TCPStreamPtr stream)
{
//char suffix[32];
	if (stream->fcreator == CREATOR_CODE && stream->ftype != APPL_FTYPE_RAW) { //don't send app or settings
		HTTP_RestoreDefaultFileInfo (&noaccess_info, stream);
		stream->actionTaken = A_NOACCESS;
		return 1;
	}
	return 0;
}


/*********************************************/

void HTTP_ExtractSuffix (char *s, char *suffix)
{
short i;
	suffix[0]='\0';
	i = strlen(s)-1;
	while (i>=0) {
		if (s[i]=='.') {
			safecpy (suffix, &s[i], SUFFIX_LEN-1);
			break;
		}
		i--;
	}
}

/*********************************************/

void HTTP_FindFileType (TCPStreamPtr stream, char *filename, char *suffix)
{
FInfo fi;
CInfoPBRec pb;
HFileInfo *fpb = (HFileInfo *) &pb;
DirInfo *dpb = (DirInfo *) &pb;
OSErr err;
char s[512];
char path[258], a_path[258];
short haveTypeMatch;
SuffixListNodePtr list_node;
Boolean wasAlias, wasFolder, wasFound=FALSE;
FSSpec spec;

	stream->content_size = 0;
	
	/*try for a suffix match first, as it takes priority*/
	stream->fileType = FILE_UNKNOWN;
	strcpy (stream->mime_type, defaultMIMEType);

	/*get the file info (or see if it's a directory*/
	safecpy (path, filename, sizeof (path)-1);
	err = ResolvePathAlias (filename, a_path, sizeof (a_path)-1, &spec, &wasFolder, &wasAlias);
//	safecpy (a_path, filename, sizeof (a_path)-1);
//	err = HTTP_ResolvePath(a_path, 256, FALSE, &wasAlias);

//sprintf (s, "$$$ err=%d, wasFolder=%d, wasAlias=%d", err, wasFolder, wasAlias);
//TTY_WriteMessage (s, true);

	fpb->ioCompletion = NULL;
	CtoPstr (a_path);
	fpb->ioNamePtr = (StringPtr) a_path;
	fpb->ioVRefNum = 0;
	fpb->ioFDirIndex = 0;
	fpb->ioDirID = 0;
	err = PBGetCatInfo ((CInfoPBPtr) fpb, false);
	if (!err && !(fpb->ioFlAttrib & 16)) {  /*it's a file*/

		fi = fpb->ioFlFndrInfo;
		
		stream->ftype = fi.fdType;
		stream->fcreator = fi.fdCreator;
		stream->content_size = fpb->ioFlLgLen;

		//stream->creation_date = fpb->ioFlCrDat; /*old http standard... wrong!*/
		GetDateTime (&(stream->creation_date));
		stream->modification_date = fpb->ioFlMdDat;
		if (debugLevel) {
			sprintf (s, "File size: %ld", fpb->ioFlLgLen);
			TTY_WriteMessage(s, TRUE);
		}
	} //it's a file
	
	//special case for RAW! file types. hard-wire the transfer type, etc.
	if ((stream->fcreator == APPL_CREATOR || stream->fcreator == WEBSTAR_CREATOR) && 
			stream->ftype == APPL_FTYPE_RAW) {
		stream->fileType = FILE_RAW;
		stream->action = NULL;
		strcpy (stream->mime_type, "application/x-raw-stuff");
	}
	else {
		list_node = suffix_list;
		
		while (list_node) {
			if (!strcmp(suffix, (list_node->suffix)->str) && (list_node->suffix)->kind != FILE_UNKNOWN) {
				stream->fileType = (list_node->suffix)->kind;
				stream->action = (list_node->suffix)->action;
				/*set MIME Type from table*/
				safecpy (stream->mime_type, (list_node->suffix)->mime_type, MIME_TYPE_SIZE);
				break;
			}
			else list_node = list_node->next;
		}
			
//sprintf (s, "$$$ fileType %d, action %d. %d", stream->fileType, stream->action, FILE_UNKNOWN);
//TTY_WriteMessage (s, TRUE);

		/*if the suffix doesn't match try looking at the type and creator to get the info*/
		if (stream->fileType == FILE_UNKNOWN) {
			if (err) {
				if (debugLevel) {
					sprintf (s, "Error getting Finder Info (%s)", Error_Message (err));
					TTY_WriteMessage (s, TRUE);
				}
			}
			else {
				// if we're here, we didn't find a suffix match, so we'll try type and creator.
				// just in case that fails, we want to fall back to the default mime type with a binary transfer.
				stream->fileType = FILE_BINARY;
				
				/**!!! The following still needs some work on the typing**/
				if (wasFolder /*fpb->ioFlAttrib & 16*/) { /*oops, this is a directory*/
					safecpy (stream->mime_type, defaultMIMEType, MIME_TYPE_SIZE);
					stream->fileType = FILE_BINARY;
					haveTypeMatch = TRUE;
					TTY_WriteMessage ("Warning: Client sent malformed URL for a directory. Returning error msg.", TRUE);
					//### redirect should happen here for directories with trailing slash added.
					// code will be...
					stream->actionTaken = A_DIR_REDIRECT;
				}
				else {
					fi = fpb->ioFlFndrInfo;
					
					if (debugLevel) {
						sprintf (s, "File Type %-4.4s, Creator %-4.4s, size: %ld", &(fi.fdType), 
							&(fi.fdCreator), fpb->ioFlLgLen);
						TTY_WriteMessage(s, TRUE);
					}
					/* look up the MIME type based on type and creator info */
					haveTypeMatch = FALSE;
					list_node = suffix_list;
					while (list_node) {
						/* if there's already a type match, there must be a creator match*/
						/* to change mime type from the current setting*/
						if (fi.fdType == (list_node->suffix)->ftype) { /*type matches*/
							if (fi.fdCreator == (list_node->suffix)->fcreator) { /*creator matches*/
								safecpy (stream->mime_type, (list_node->suffix)->mime_type, MIME_TYPE_SIZE);
								stream->fileType = (list_node->suffix)->kind;
								stream->action = (list_node->suffix)->action;
								break; /*this was an exact match*/
							}
							else if (!haveTypeMatch) { /*it's our best match so far, type only*/
								safecpy (stream->mime_type, (list_node->suffix)->mime_type, MIME_TYPE_SIZE);
								stream->fileType = (list_node->suffix)->kind;
								stream->action = (list_node->suffix)->action;
								haveTypeMatch = TRUE;
							}
						}
						list_node = list_node->next;
					}/*while*/
				}
			} /*else*/
		} //if no suffix match
	} //else !RAW
	if (debugLevel) {
		sprintf (s, "MIME type is %s", stream->mime_type);
		TTY_WriteMessage (s, TRUE);
	}
}

/*********************************************/

void HTTP_DoGetCommand(TCPStreamPtr stream)
{
	char filename[REQUEST_SIZE], suffix[32];
	char s[256];
	short i;

	if (!stream) {
		TTY_WriteMessage ("ERROR: DoGetCommand was passed a null stream pointer!", TRUE);
		return;
	}
	stream->fileType = defaultDocType;
	stream->mime_type[0]='\0';
	stream->content_size=0;
	stream->found = 0;
	stream->f = NULL;
			
	if (stream->method != METHOD_UNKNOWN) {

		/*start by figuring out the file name, suffix, and type. */
		HTTP_ExtractPath (stream, stream->request, filename, stream->search_args);
		
		safecpy (stream->url_fname, filename, ARG_SIZE-1);
		safecpy (stream->mac_fname, filename, FILE_NAME_SIZE-1);

		HTTP_ExtractSuffix(stream->mac_fname, suffix);

		for (i=0;i<strlen(suffix);i++)
			suffix[i] = toupper(suffix[i]);
		
		/*look up the suffix and type*/
		
		HTTP_FindFileType (stream, filename, suffix);

		if (HTTP_SecurityCheck (stream)) /*pass mac_fname*/
			stream->found = 2; /*Access violation*/
				
		//One last security check... make sure we aren't sending MacHTTP files.
		i = HTTP_DontSendMacHTTP (stream);
		
		if (i || stream->found == 2) { //the file won't be served, so bump the appropriate counters
			deniedConnections++;
//			stream->keepAlive = false;
		}
		
		/*check to see if this is a request for the server version number*/
		if (!strcmp(stream->mac_fname, COPYRIGHT_NAME))
			stream->fileType = FILE_VERSION;
		
		switch (stream->fileType) {
			case FILE_TEXT:
				stream->f = HTTP_fopen (stream->mac_fname, "r");
				//HTTP_ParseHeaderFields (stream);
				break;
			
			case FILE_BINARY:
			case FILE_RAW:
				stream->f = HTTP_fopen (stream->mac_fname, "rb");
				//HTTP_ParseHeaderFields (stream);
				break;
				
			case FILE_SCRIPT:
			case FILE_APPL:
			case FILE_CGI:
			case FILE_ACGI:
				stream->f = HTTP_fopen (stream->mac_fname, "rb");
				break;
				
			case FILE_ACTION:
				if (stream->action && (stream->action)->kind == A_ACGI) {
					//stream->f = HTTP_fopen ((stream->fc.action)->path, "rb"); //make sure that the action exists
					stream->found = 1;
				}
				else { //this is a plug-in
					if (!(stream->found))
						stream->found = 1;
					//stream->f = (FILE *) -1; //fake out the lame file existence checks
				}
				break;
				
			default:
				stream->f = NULL;
				break;
		}
		
		if (stream->found==2) /*access violation*/
			safecpy (stream->url_fname, filename, ARG_SIZE); /*return the real filename for logging*/
		else if (stream->f) /*normal return*/
			stream->found=1;
		
		if (!stream->found && stream->fileType != FILE_VERSION) {
			/*open the error file and fix up the stream fields*/
			HTTP_RestoreDefaultFileInfo (&error_info, stream);
			stream->f=HTTP_fopen(error_html, "rb");
			//safecpy (stream->mime_type, error_html_mime_type, MIME_TYPE_SIZE-1);
			//safecpy (stream->mac_fname, error_html, FILE_NAME_SIZE);
			//stream->fileType = error_content_type;
			stream->creation_date = stream->modification_date = 0;
			
			//let CGIs know what's up
			if (stream->actionTaken != A_DIR_REDIRECT) //don't override the URL redirection for bad URLs
				stream->actionTaken = A_ERROR;
			
			/*spit out the referer info to the screen*/
			if (stream->url_referer[0]) {
				sprintf (s, "Bad URL reference received from: %.200s", stream->url_referer);
				TTY_WriteMessage (s, TRUE);
			}
		}
		
	}
	else
		stream->f = NULL;
}

/*********************************************/

void HTTP_FillObjectBodyBuffer (TCPStreamPtr stream);
void HTTP_FillObjectBodyBuffer (TCPStreamPtr stream)
{
char *temp=NULL;
long post_start=0;
OSErr err = noErr;
byte state;
unsigned short pending=0;
unsigned long current_data_len=0, len=0;
long memcheck=0;
//char s[300];

	//compute how much data we already have
	current_data_len = stream->request_byte_count + stream->post_arg_byte_count;
//sprintf (s, "HTTP_FillObjectBodyBuffer cdl-%lu rbc-%lu pabc-%lu", current_data_len, 
//stream->request_byte_count, stream->post_arg_byte_count);
//TTY_WriteMessage (s, 1);
	
	while (!LogTimeout (stream) && !done && !err && stream->post_arg_byte_count < POST_ARG_SIZE) {

		//exit if we've read all there is to read
		if (stream->content_length && (stream->post_arg_byte_count >= stream->content_length))
			break;

		//see if there is data to read
		pending = 0;
		err = StreamStatus (stream->stream, &state, &pending);
		
		if (pending && !err) {
//sprintf (s, "HTTP_FillObjectBodyBuffer -- pending data %hu, err=%d", pending, err);
//TTY_WriteMessage (s, 1);
			LogStartTimeout (stream, MAX_TIMEOUT);
			
			//Make sure the buffer is big enough first			
			if (current_data_len + REQUEST_SIZE >= stream->request_buffer_size) {
//sprintf (s, "HTTP_FillObjectBodyBuffer -- resizing buffer to %lu", stream->request_buffer_size + REQUEST_SIZE);
//TTY_WriteMessage (s, 1);
				//we're out of buffer space and we're not sure if the request is complete, 
				// so let's make the buffer larger
				temp = NewPtr (stream->request_buffer_size + REQUEST_SIZE);
			
				if (temp == NULL) {
					TTY_WriteMessage ("\rERROR! Cannot allocate memory for HTTP Post Request (FillObjectBuffer).", TRUE);
					LogMemCheck(&memcheck);
					break;
				}
				else {
//sprintf (s, "HTTP_FillObjectBodyBuffer -- copying data to new buffer, %lu bytes", current_data_len);
//TTY_WriteMessage (s, 1);
		 			if (stream->request) {
		 				memcpy (temp, stream->request, current_data_len);
		 				DisposePtr (stream->request);
		 			}
		 			stream->request = temp;
		 			stream->request_buffer_size += REQUEST_SIZE;
		 		}
			}
			
			//now try to read the pending data and shove it in the existing buffer
			len = REQUEST_SIZE - 2;
//sprintf (s, "HTTP_FillObjectBodyBuffer -- reading pending data %lu bytes", len);
//TTY_WriteMessage (s, 1);
			err = ReadData (stream->stream, &(stream->request [current_data_len]), &len);
			if (!err) {
				current_data_len += len;
				stream->post_arg_byte_count += len;
//sprintf (s, "HTTP_FillObjectBodyBuffer -- read data cdl-%lu, pabc-%lu", current_data_len, stream->post_arg_byte_count);
//TTY_WriteMessage (s, 1);
			}
		}
		else if (!err) //no data yet, so yield time
			YieldToAnyThread ();
	}//while
	
	//fix up the object_body pointer
	stream->post_args = &(stream->request [stream->request_byte_count]);

//if (stream->post_arg_byte_count >= POST_ARG_SIZE)
//TTY_WriteMessage ("HTTP_FillObjectBodyBuffer -- done, buffer full", 1);
//else
//TTY_WriteMessage ("HTTP_FillObjectBodyBuffer -- done, got it all", 1);
}

/*********************************************/

OSErr HTTP_ReadFromObjectBody (TCPStreamPtr stream, void *data, long *dataLen)
// return data from the stream's object_body buffer or the IP stream (post args, for example)
{
unsigned long len;
OSErr err = noErr;

	if (!stream || !data || !dataLen) return -1;
	
	//see if there is any data in the internal stream request buffer before looking at the actual IP connection
	if (stream->post_arg_byte_count > 0) {
		//return as much (or all) of the data in the internal buffer
		if (*dataLen >= stream->post_arg_byte_count) {
			len = stream->post_arg_byte_count;
			memcpy (data, stream->post_args, len);
			stream->post_arg_byte_count = 0;
			stream->post_args = NULL;
		}
		else { //only return part of the object body that is buffered and move pointers along in the buffer
			len = *dataLen;
			memcpy (data, stream->post_args, len);
			stream->post_arg_byte_count -= len;
			stream->post_args = &(stream->post_args [len]);
		}
	}
	else {
		//otherwise, try to read dataLen bytes off the IP connection and return the actual amount read
		len = *dataLen;
		err = ReadData (stream->stream, data, &len);
	}
	
	*dataLen = len;
	LogStartTimeout (stream, MAX_TIMEOUT); /*reset the time-out*/

	return (err);
}

/*********************************************/

short HTTP_AddData(char *s, unsigned long data_len, TCPStreamPtr stream)
{
char *temp=NULL;
unsigned long post_start=0;
long memcheck=0;

	if (!stream) return -1;
	
	if (data_len + stream->request_byte_count >= stream->request_buffer_size) {
	//we're out of buffer space and we're not sure if the request is complete, so let's make the buffer larger
		temp = NewPtr (stream->request_buffer_size + data_len + REQUEST_SIZE);
	
		if (temp == NULL) {
			TTY_WriteMessage ("\rERROR! Cannot allocate memory for HTTP Post Request (AddData).", TRUE);
			LogMemCheck(&memcheck);
			return FALSE;
		}
		else {
 			if (stream->request) {
 				memcpy (temp, stream->request, stream->request_byte_count);
 				DisposePtr (stream->request);
 			}
 			stream->request = temp;
 			stream->request_buffer_size += data_len + REQUEST_SIZE;
		}
	}
	
	/*stick the new data in the buffer*/
	memcpy (&(stream->request[stream->request_byte_count]), s, data_len);
	stream->request_byte_count += data_len;
	stream->request[stream->request_byte_count] = '\0';

	post_start = 0;
	
	if (HTTP_IsComplete(stream, &post_start)) {
	
		//** call plug-in filters right here! this may result in a completely different request.
		//###%CTS - we need to do something smart with the post_start var. It could be different if the filter
		// changes the request text. It will definitely throw off the object body code below.
		Plugin_Filter (stream);
		
		//we have the full request now, so extract the method
		if (HTTP_ExtractMethod (stream, stream->request)) {
		
			//now parse the header fields
			HTTP_ParseHeaderFields (stream);
			
			//consume up to POST_ARG_SIZE bytes of object body and stuff it onto the end of
			//the stream->request field (after the object_body pointer)
			
			if (stream->content_length > 0) {
				if (post_start) {
					stream->post_args = &(stream->request [post_start]);
					stream->post_arg_byte_count = stream->request_byte_count - post_start;
					stream->request_byte_count = post_start;
				}
				HTTP_FillObjectBodyBuffer (stream);
			}
		}
		return (TRUE);
	}
	
	return (FALSE);
}

/*********************************************/

HostFolderPtr HTTP_GetHostFolderListHead()
{
	return hostfolder_list;
}

/*********************************************/

HostFolderPtr HTTP_GetHostFolderPtr (TCPStreamPtr stream)
{
HostFolderPtr hfFound = NULL;
HostFolderPtr hf = NULL;
HostFolderPtr hfCatchAll = NULL;
char host_name_temp[HOST_NAME_SIZE];
//short i;

	/* make an upper-case copy of the host name, for comparisons */
	safecpy (host_name_temp, stream->hdr_host_name, sizeof(host_name_temp));
	HTTP_UpCase (host_name_temp);
	
	for (hf=HTTP_GetHostFolderListHead(); hf!=NULL; hf=hf->next) {
		/* check for exact match */
		if ( !strcmp(hf->hostname, host_name_temp) ) {
			hfFound = hf;
			break;	// exit loop on exact match
		}
		/* check for wildcard match */
		if ( hfFound == NULL ) {
			short lenThis = strlen(hf->hostname);
			short lenHdr = strlen(host_name_temp);
			if ( (lenThis > 2) && (hf->hostname[0] == '*') && (lenHdr >= (lenThis-1)) ) {
				char *host_suffix = &hf->hostname[1];
				char *hdr_suffix = &host_name_temp[lenHdr - (lenThis-1)];
				if ( !strcmp(host_suffix, hdr_suffix) ) {
					hfFound = hf;	// remember this one, but continue loop in case we find exact match
				}
			}
			/* check for catchall wildcard */
			if ( hfCatchAll == NULL ) {				
				if ( (lenThis == 1) && (hf->hostname[0] == '*') )
					hfCatchAll = hf;	// remember this one, in case no wildcards match
			}
		}
	}
	
	if ( hfFound == NULL )
		hfFound = hfCatchAll;
		
	return hfFound;
}

/*********************************************/

short HTTP_GetHostFolder (TCPStreamPtr stream, char *foldername)
{
HostFolderPtr hfFound = HTTP_GetHostFolderPtr(stream);

	if ( hfFound != NULL ) {
		strcpy (foldername, hfFound->foldername);
		stream->virtual_dir = &hfFound->fs;
	}
	else {
		*foldername = '\0';
		stream->virtual_dir = &gServerRootFS;
	}
	
	return ( strlen(foldername) );
}

/*********************************************/

Boolean HTTP_CheckDNSExclude (long ip)
{
char ip_str[32];
DNSExcludePtr p;

	HTTP_AddrToStr (ip, ip_str);
	
	for (p=dns_exclude_list; p!=NULL; p=p->next) {
		if ( strncmp (ip_str, p->ip_string, p->ip_strlen) == 0 )
			return TRUE;
	}
	
	return FALSE;
}