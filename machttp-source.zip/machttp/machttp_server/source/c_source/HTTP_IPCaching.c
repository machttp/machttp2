/*HTTP_IPCaching.c*/
/******************************************************
 *
 * Lawyer stuff:
 *
 * MacHTTP 2.x, source code
 * Copyright �1993-2001 Chuck Shotton
 * All Rights Reserved.
 *
 * This source code is made available under the terms of the MacHTTP Source License.
 * This license grants you the right to use the source code to create new versions
 * of and derivative works from the original MacHTTP source code. Under the terms of
 * this license, any modifications made to the source code must be made available in
 * source code form to the general public and the MacHTTP.Org organization. You may not
 * redistribute source code or binary versions of the MacHTTP application that make use of
 * the MacHTTP name, logo, or icons without the expressed written consent of MacHTTP.Org
 * or Chuck Shotton.
 *
 * MacHTTP is a trademark of Chuck Shotton. Permission is granted
 * to MacHTTP.Org and its assignees use the MacHTTP name, logo, and icons.
 * Any use not authorized by MacHTTP.Org or Chuck Shotton is prohibited.
 *
 * Additional information can be found at http://www.machttp.org/
 *
 ******************************************************
 * Modifications:
 *
 * 03/01/01 - cshotton - initial verison
 * 10/28/01 - rpatters1 - implemented DNS_EXCLUDE logic
 * 11/17/01 - rpatters1 - modernized and de-linted
 * 11/19/01 - rpatters1 - added config.h
 ******************************************************/
#include "config.h"
#include <cstdio>
#include <cstring>

#include <MacWindows.h>
#include <Files.h>
#include <Threads.h>

#include "MacTCPCommonTypes.h"
#include "TCPPB.h"
#include "TCPHi.h"
#include "http.h"
#include "ResolvePath.h"

#include "HTTP_IPCaching.h"
#include "globals.h"

static CacheRecHandle cache=NULL;
static short next_cache_slot;

/*********************************************/

void HTTP_EmptyCache()
{
short i;
	next_cache_slot = 0;
	if (!cache) return;
	for (i=0;i<IP_CACHE_SIZE;i++) {
		((CacheRecPtr) *cache)[i].addr = 0xFFFFFFFF;
		((CacheRecPtr) *cache)[i].name[0] = '\0';
	}
}

/*********************************************/

void HTTP_InitCaching()
{
	cache = (CacheRecHandle) NewHandle (sizeof (CacheRecord) * IP_CACHE_SIZE);
	if (cache) {
		HTTP_EmptyCache();
	}
}

/*********************************************/

void HTTP_AddrToStr (long remoteHost, char *host_name)
{
	sprintf (host_name, "%hu.%hu.%hu.%hu", ((unsigned char *) &remoteHost)[0], 
		((unsigned char *) &remoteHost)[1], ((unsigned char *) &remoteHost)[2], 
		((unsigned char *) &remoteHost)[3]);
}

/*********************************************/

void HTTP_IPAddrToName(long remoteHost, char *host_name)
{
short i;

	/* check cache. If found, we are done. */
	
	if (cache) {
		for (i=0; i<IP_CACHE_SIZE; i++) {
			if (remoteHost == ((CacheRecPtr) *cache)[i].addr) {
				strcpy (host_name, ((CacheRecPtr) *cache)[i].name);
				return;
			}
		}
	}

	/* not found in cache, so go get it from DNS or from IP address, dep. on config */
	
	if (no_dns || HTTP_CheckDNSExclude(remoteHost))
		HTTP_AddrToStr (remoteHost, host_name);
	else {
		IPAddrToName(remoteHost, host_name);
		if (*host_name == '\0')
			HTTP_AddrToStr (remoteHost, host_name);
	}
	
	/* if we have a cache, add this one to it. */
	
	if (cache) {
			((CacheRecPtr) *cache)[next_cache_slot].addr = remoteHost;
			strcpy (((CacheRecPtr) *cache)[next_cache_slot].name, host_name);
			next_cache_slot = (next_cache_slot+1) % IP_CACHE_SIZE;
		}
	} 

