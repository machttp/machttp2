/*XDM_UI.c*/
/******************************************************
 *
 * Lawyer stuff:
 *
 * MacHTTP 2.x, source code
 * Copyright �1993-2001 Chuck Shotton
 * All Rights Reserved.
 *
 * This source code is made available under the terms of the MacHTTP Source License.
 * This license grants you the right to use the source code to create new versions
 * of and derivative works from the original MacHTTP source code. Under the terms of
 * this license, any modifications made to the source code must be made available in
 * source code form to the general public and the MacHTTP.Org organization. You may not
 * redistribute source code or binary versions of the MacHTTP application that make use of
 * the MacHTTP name, logo, or icons without the expressed written consent of MacHTTP.Org
 * or Chuck Shotton.
 *
 * MacHTTP is a trademark of Chuck Shotton. Permission is granted
 * to MacHTTP.Org and its assignees use the MacHTTP name, logo, and icons.
 * Any use not authorized by MacHTTP.Org or Chuck Shotton is prohibited.
 *
 * Additional information can be found at http://www.machttp.org/
 *
 ******************************************************
 * Modifications:
 *
 * 03/01/01 - cshotton - initial verison
 * 11/17/01 - rpatters1 - modernized and de-linted
 ******************************************************/

#include "config.h"
#include <cstdio>
#include <cstring>

#include <MacTypes.h>
#include <MacMemory.h>
#include <Dialogs.h>
#include <Lists.h>
#include <Menus.h>
#include <Fonts.h>
#include <Gestalt.h>
#include <Resources.h>
#include <Events.h>
#include <ToolUtils.h>
#include <MacErrors.h>
#include <Sound.h>

#include "PW_UI.h"
#include "Prefs.h"
#include "Template.h"

#define UI_DLOG_ID 229
#define NEWITEM 1
#define DELETEITEM 2
#define LISTITEM 3
#define USERNAMEITEM 4
#define PASSWORDITEM 5
#define REALMITEM 10

#define REALMMENUID 199

DialogPtr pw_dlog;
static ListHandle theList;
static short cellCount;
static short ui_lastcommand;
static Boolean has_colorQD = FALSE;
static Boolean has_depth = FALSE;
static unsigned long ui_mask = 0;
static unsigned long ui_addr = 0;
static unsigned short ui_buttonState[4]={0,0,0,0};
static unsigned char ui_buttonVal[3][4]={{255,255,255,255},{0,0,0,0},{1,2,3,4}};
static Cell lastClick = {0,0};
static MenuHandle realmMenuHandle = NULL;
static Str255 currentRealm;

/***************************************/

static RGBColor UI_white = {0xFFFF, 0xFFFF, 0xFFFF};
static RGBColor UI_ltgray = {0xEEEE, 0xEEEE, 0xEEEE};
static RGBColor UI_gray = {0xAAAA, 0xAAAA, 0xAAAA};

/***************************************/

//extern MenuItem (short item, short num);
void UI_ClickMaskButton (short id);

/***************************************/

Boolean UI_HasColorQD()
{
	return has_colorQD;
}

/***************************************/

short UI_ScreenDepth()
{
#if INTERACTIVE
GDHandle gdh;
	if (has_colorQD) {
		gdh = GetMainDevice ();
		return (*((*gdh)->gdPMap))->pixelSize;
	}
	else
		return 1;
#endif
}

/***************************************/

void UI_3dRect(Rect *bounds, Boolean innie, short width, Boolean filled, Boolean frame)
{
#if INTERACTIVE
RGBColor fc;

	if (!has_colorQD || !has_depth) {
		if (frame) {
			bounds->right +=2;
			bounds->bottom +=2;
			FrameRoundRect (bounds, 12, 12);
		}
		return;
	}
	
	SetPort (pw_dlog);
	GetForeColor(&fc);
	if (filled) {
		RGBForeColor (&UI_ltgray);
		PaintRect (bounds);
	}
	PenSize(width,width);
	
	/*left and top*/
	if (innie)
		RGBForeColor(&UI_gray);
	else
		RGBForeColor(&UI_white);
	MoveTo(bounds->left, bounds->bottom);
	LineTo(bounds->left, bounds->top);
	LineTo(bounds->right, bounds->top);
	
	/*right and bottom*/
	if (innie)
		RGBForeColor(&UI_white);
	else
		RGBForeColor(&UI_gray);
	
	MoveTo(bounds->right, bounds->top+1);
	LineTo(bounds->right, bounds->bottom);
	LineTo(bounds->left+1, bounds->bottom);
	
	PenSize(1,1);
	RGBForeColor(&fc);
#endif
}

/***************************************/

pascal void ListDrawProc(WindowPtr theDialog, short theItem)
{

#if INTERACTIVE
	Rect 	iRect;
	Handle theHandle;
	short 	itype;

	SetPort(pw_dlog);
	// Grab item information
	GetDialogItem(theDialog,theItem,&itype,&theHandle,&iRect);

	// Draw a frame around the user item
	LUpdate ((*theList)->port->visRgn, theList);
	if (has_depth) {
		iRect.left -=2;
		iRect.top -=2;
		UI_3dRect (&iRect, TRUE, 2, FALSE, FALSE);
	}
	else {
		PenSize (1,1);
		FrameRect(&iRect);
	}
#endif
}

/***************************************/

void UI_BuildRealmMenu (StringPtr s)
{
#if INTERACTIVE
	if (!realmMenuHandle) {
		realmMenuHandle = NewMenu (REALMMENUID, "\pRealms");
	}	

	if (realmMenuHandle)
		AppendMenu (realmMenuHandle, s);
#endif
}

/***************************************/

void UI_SetRealm (StringPtr s)
{
#if INTERACTIVE
	Rect	iRect;
	short	type;
	Handle	iHndle;

	GetDialogItem (pw_dlog, REALMITEM, &type, &iHndle, &iRect);
	if (s[0]) {
		strncpy ((char *) currentRealm, (char *) s, s[0]+1);
		SetDialogItemText (iHndle, currentRealm);
	}
	else {
		currentRealm [0] ='\0';
		SetDialogItemText (iHndle, "\pNo Realms Defined!");
	}
#endif
}

/***************************************/

void UI_RealmPopUp ()
{
#if INTERACTIVE
	Rect	iRect;
	short	type;
	Handle	iHndle;
	long 	mresult;
	Point 	pt;
	
	GetDialogItem (pw_dlog, REALMITEM, &type, &iHndle, &iRect);
	iRect.left -= 2;
	iRect.top -=2;
	UI_3dRect (&iRect, TRUE, 2, FALSE, TRUE);
	
	if (realmMenuHandle) {
		InsertMenu (realmMenuHandle, hierMenu);
		
		pt.h = iRect.left+2;
		pt.v = iRect.top+2;
		LocalToGlobal (&pt);
		mresult = PopUpMenuSelect (realmMenuHandle, pt.v, pt.h, 1);
		DeleteMenu (REALMMENUID);
	}
	else {
		SysBeep(3);
		mresult = 0;
	}
	
	UI_3dRect (&iRect, FALSE, 2, FALSE, TRUE);
	
	if (HiWord(mresult)) {
		HTTP_GetRealm (LoWord (mresult), currentRealm); /*get the realmName from the list of realms*/
		UI_SetRealm (currentRealm);	/*stuff it in the dialog button*/
	}
	
#endif
}

/***************************************/

short UIRunDLOG (DialogPtr theDialog, EventRecord *theEvent, short *itemHit)
{
#if INTERACTIVE
	Rect	iRect;
	short	type;
	Handle	iHndle;
	GrafPtr	savePort;
	Point	p;
	char	theChar;
	short menuID, itemNumber;
	long menuResult;
	
	// case on the event
	switch (theEvent->what) {
	case keyDown:
			// if key was pressed, handle return key
			theChar = (theEvent->message) & charCodeMask;
			if (theEvent->modifiers & cmdKey) {
				menuResult=MenuKey(theChar);
				menuID = HiWord(menuResult);
				itemNumber = LoWord(menuResult);
				MenuItem(menuID,itemNumber);
				HiliteMenu(0);
				return TRUE;
			}/*if*/
			else return FALSE;
			break;
	case mouseDown:
			// Get where mouse click occured in global coordinates.
			p = theEvent->where;

			//   Save the current port.
			//   Then make sure port is set to the dialog.
			GetPort (&savePort);
			SetPort (theDialog);

			// Convert the coordinates to local to the dialog window
			GlobalToLocal(&p);

			/*check to see if the user clicked the pop-up menu*/
			
			GetDialogItem (theDialog, REALMITEM, &type, &iHndle, &iRect);
			if (PtInRect (p, &iRect)) {
				UI_RealmPopUp ();
				return TRUE;
			}
			else {
				// Since I am only concerned with mouse clicks in the user item,
				// get information for that item.
				GetDialogItem(theDialog,LISTITEM,&type,&iHndle,&iRect);
	
				// If the mouse click was not in LISTITEM, then let ModalDialog handle
				// it.
				if (!PtInRect(p,&iRect)) {
						SetPort(savePort);
						return FALSE;
				}
			}
			
			// Mouse Click was in list item,
			// Set the itemHit to be the LISTITEM,
			// and call LClick on itemhandle (the list).
			*itemHit = LISTITEM;
			LClick(p,theEvent->modifiers,(ListHandle)theList);
			lastClick = LLastClick ((ListHandle) theList);
			
			// Reset Port, and let ModalDialog know that we handled the event.
			SetPort(savePort);
			return TRUE;
	default :
			return FALSE;
	}
#endif
}

/***************************************/

void UI_Init()
{
#if INTERACTIVE
ControlHandle	iHndl;
Rect 	iRect,
		rView,
		rBounds;
Point 	pCellSz;
short	iType;
OSErr err;
long feature;
	err = Gestalt(gestaltQuickdrawVersion, &feature);
	if (err) {
		has_colorQD = FALSE;
	}
	else {
		has_colorQD = feature > 1;
	}
	has_depth = UI_ScreenDepth() > 2;
	
	theList = NULL;
	cellCount = 0;
	ui_lastcommand = 0;
	pw_dlog = GetNewDialog (UI_DLOG_ID, NULL, kFirstWindowOfClass);
	
	/** Make the list **/
	// Grab item information
	GetDialogItem(pw_dlog,LISTITEM, &iType, (Handle *) &iHndl, &iRect);

	// Set up view for the list.  Notice that there is some
	// margin left on all sides for the frame, and the verical scroll bar
	rView = iRect;
	rView.right -= 16;
	rView.left +=2;
	rView.bottom -=1;
	rView.top += 1;

	// list array is 1 colume with 25 rows
	SetRect(&rBounds,0,0,1,0);

	// force auto calculations when displaying the cells.
	pCellSz.h = 0;
	pCellSz.v = 0;

	// create list and draw it.
	theList = LNew (&rView, &rBounds, pCellSz, 0, pw_dlog, TRUE, TRUE, FALSE, TRUE);

	if (!theList) {
			DebugStr("\pUnable to allocate list");
			return;
	}

	LSetDrawingMode (TRUE, theList);
	
	SetDialogItem(pw_dlog,LISTITEM,iType,(Handle) NewUserItemProc(ListDrawProc),&iRect);
	
	UI_SetRealm ("\p");

#endif
}

/***************************************/

short UI_LastCommand()
{
#if INTERACTIVE
short last;
	last = ui_lastcommand;
	ui_lastcommand = 0;
	return last;
#endif
}

/***************************************/

void UI_GetUserName (StringPtr name)
{
#if INTERACTIVE
Rect	iRect;
short	type;
Handle	iHndle;
char realm[256];
	GetDialogItem(pw_dlog,USERNAMEITEM,&type,&iHndle,&iRect);
	GetDialogItemText (iHndle, (StringPtr) name);
	PtoCstr ((StringPtr) name);
	GetDialogItem(pw_dlog,REALMITEM,&type,&iHndle,&iRect);
	GetDialogItemText (iHndle, (StringPtr) realm);
	PtoCstr ((StringPtr) realm);
	strcat ((char *) name, "�");
	strcat ((char *) name, realm);
	CtoPstr ((char *) name);
#endif
}

/***************************************/

void UI_GetPassword (StringPtr pass)
{
#if INTERACTIVE
Rect	iRect;
short	type;
Handle	iHndle;
	GetDialogItem(pw_dlog,PASSWORDITEM,&type,&iHndle,&iRect);
	GetDialogItemText (iHndle, (StringPtr) pass);
#endif
}

/***************************************/

void UI_SetUserName (char *username)
/*parse the username string from the list into name and realm.*/
{
#if INTERACTIVE
Rect	iRect;
short	type;
Handle	iHndle;
char name[256], realm[256];
	name[0] = realm[0]='\0';
	sscanf (username, "%255[^�]�%255[^�]", name, realm);
	CtoPstr (name);
	GetDialogItem(pw_dlog,USERNAMEITEM,&type,&iHndle,&iRect);
	SetDialogItemText (iHndle, (StringPtr) name);
	if (name[0]) 
		UI_SetRealm (CtoPstr (realm));
#endif
}

/***************************************/

void UI_SetPassword (StringPtr password)
{
#if INTERACTIVE
Rect	iRect;
short	type;
Handle	iHndle;
	GetDialogItem(pw_dlog,PASSWORDITEM,&type,&iHndle,&iRect);
	SetDialogItemText (iHndle, password);
#endif
}

/***************************************/

void UI_GetCurrentSelection ()
{
#if INTERACTIVE
Point theCell;
char dataPtr[256];
Str255 pass;
short dataLen;
	theCell.h=theCell.v=0;
	if (LGetSelect (TRUE, &theCell, theList)) {
		dataLen = sizeof (dataPtr);
		LGetCell (dataPtr, &dataLen, theCell, theList);	
		dataPtr[dataLen] = '\0';
		
		/*Fill in the appropriate info for username and password from prefs file*/
		UI_SetUserName (dataPtr);
		Prefs_GetPassword (CtoPstr(dataPtr), pass);
		UI_SetPassword (pass);
	}
#endif
}

/***************************************/

void PW_NewButton()
{
#if INTERACTIVE
Str255 name;
Str255 password;
OSErr err;
	
	UI_GetUserName (name);
	UI_GetPassword (password);
	
	if (name[0]) {
	
		err = Prefs_WriteNewPassword (name, password, TRUE);
		
	}
	else UI_Error ("\pYou must enter a username in the User Name field.");
#endif
}

/***************************************/

void PW_DeleteButton()
{
#if INTERACTIVE
Str255 name;
OSErr err;
	
	UI_GetUserName (name);
	err = Prefs_DeletePassword (name, TRUE);
	if (!err) {
		UI_DeleteCurrentCell();
		UI_SetUserName ("�");
		UI_SetPassword ("\p");
	}
	UI_GetCurrentSelection();
	
#endif
}

/***************************************/

void PW_Run(EventRecord *theEvent)
{
#if INTERACTIVE
short item;
DialogPtr whichDlog;
short itemHit;
short handled;

	handled = UIRunDLOG(pw_dlog, theEvent, &item);
	if (item==LISTITEM) {
		UI_GetCurrentSelection();
	}
	
	if (!handled) {
		if (theEvent->what == updateEvt)
			has_depth = UI_ScreenDepth() > 2;
			
		if (DialogSelect (theEvent, &whichDlog, &itemHit)) {
			if (whichDlog == pw_dlog) {
				switch (itemHit) {
					case NEWITEM:
						PW_NewButton ();
						break;
					case DELETEITEM:
						PW_DeleteButton ();
						break;
					case LISTITEM:
						break;
					case 10:
					case 11:
					case 12:
					case 13:
						//UI_ClickMaskButton(itemHit-MASKITEM);
						break;
				}/*switch*/
				
				ui_lastcommand = itemHit;
			}
		}
		if (theEvent->what == updateEvt) {
			UI_Redraw();
		}
	}
#endif
}

/***************************************/

void UI_EmptyList()
{
#if INTERACTIVE
Rect	iRect;
short	type;
Handle	iHndle;
	cellCount = 0;
	LDelRow (0, 0, theList);
	
	GetDialogItem(pw_dlog,PASSWORDITEM,&type,&iHndle,&iRect);
	SetDialogItemText (iHndle, (StringPtr) "");
	GetDialogItem(pw_dlog,USERNAMEITEM,&type,&iHndle,&iRect);
	SetDialogItemText (iHndle, (StringPtr) "");
#endif
}

/***************************************/

void UI_AddToList(char *s)
{
#if INTERACTIVE
Point theCell;
short iInsRow;
		iInsRow = LAddRow (1, cellCount, theList);
		SetPt(&theCell,0, cellCount);
		LSetCell(s,strlen(s),theCell,theList);
		cellCount++;
#endif
}

/***************************************/

void /*OSErr*/ UI_DeleteCurrentCell ()
{
#if INTERACTIVE
	LDelRow (1, lastClick.v, theList);
	cellCount--;
	if (lastClick.v>=cellCount) 
		lastClick.v = lastClick.v>0 ? --lastClick.v : 0;
	LSetSelect (TRUE, lastClick, theList);
	/*blank out the entry fields*/
#endif
}

/***************************************/

void UI_DeleteFromList(StringPtr name)
{
#if INTERACTIVE
Cell theCell;
	PtoCstr (name);
	SetPt (&theCell, 0, 0);
	if (LSearch ((Ptr) name, (short) strlen ((char *) name), (ListSearchUPP) NULL, &theCell, theList)) {
		LSetSelect (TRUE, theCell, theList);
		UI_DeleteCurrentCell ();
	}
#endif
}

/***************************************/

void UI_Redraw()
{
#if INTERACTIVE
	Rect r;
	Handle	iHndl;
	short	iType;
	short 	i;

	if (!pw_dlog) return;
	
	has_depth = UI_ScreenDepth() > 2;
	
	SetPort (pw_dlog);
	
	r=pw_dlog->portRect;
	r.right -= 2;
	r.bottom -=2;
	UI_3dRect (&r, FALSE, 2, FALSE, FALSE);

	GetDialogItem (pw_dlog, USERNAMEITEM, &iType, &iHndl, &r );
	r.left -= 2;
	r.top -=2;
	UI_3dRect (&r, TRUE, 2, FALSE, FALSE);

	GetDialogItem (pw_dlog, PASSWORDITEM, &iType, &iHndl, &r );
	r.left -= 2;
	r.top -=2;
	UI_3dRect (&r, TRUE, 2, FALSE, FALSE);
		
	for (i=NEWITEM; i<=DELETEITEM; i++) {
		GetDialogItem (pw_dlog, i, &iType, &iHndl, &r );
		r.left -= 2;
		r.top -=2;
		UI_3dRect (&r, FALSE, 2, FALSE, TRUE);
	}
	GetDialogItem (pw_dlog, REALMITEM, &iType, &iHndl, &r );
	r.left -= 2;
	r.top -=2;
	UI_3dRect (&r, FALSE, 2, FALSE, TRUE);
#endif
}

/***************************************/

void UI_Error (StringPtr s)
{
#if INTERACTIVE
	Error ((char*)s);
#endif
}

/*****************************************/

void UI_FileError (char *s, OSErr err)
{
#if INTERACTIVE
char temp[256];
	strcpy(temp, s);
	switch (err) {
		case bdNamErr:
			strcat (temp, " Bad file name.");
			break;
		case dirFulErr:
			strcat (temp, " Directory is full.");
			break;
		case extFSErr:
			strcat (temp, " External file system error.");
			break;
		case ioErr:
			strcat (temp, " I/O Error.");
			break;
		case nsvErr:
			strcat (temp, " No such volume.");
			break;
		case vLckdErr:
			strcat (temp, " Volume is locked.");
			break;
		case wPrErr:
			strcat (temp, " Diskette is write-protected.");
			break;
		case tmfoErr:
			strcat (temp, " Too many files open.");
			break;
		case fnfErr:
			strcat (temp, " File not found.");
			break;
		case opWrErr:
			strcat (temp, " File is already open in another application.");
			break;
		case dskFulErr:
			strcat (temp, " Disk is full.");
			break;
		case fLckdErr:
			strcat (temp, " File is locked.");
			break;
		case wrPermErr:
			strcat (temp, " No permission to write to file.");
			break;
		default:
			strcat (temp, " Unknown error.");
			break;
	}
	CtoPstr (temp);
	UI_Error ((StringPtr) temp);
#endif
}
