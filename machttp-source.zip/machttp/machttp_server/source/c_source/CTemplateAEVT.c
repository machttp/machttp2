/*** CTemplateAEVT.c ***/
/******************************************************
 *
 * Lawyer stuff:
 *
 * MacHTTP 2.x, source code
 * Copyright �1993-2001 Chuck Shotton
 * All Rights Reserved.
 *
 * This source code is made available under the terms of the MacHTTP Source License.
 * This license grants you the right to use the source code to create new versions
 * of and derivative works from the original MacHTTP source code. Under the terms of
 * this license, any modifications made to the source code must be made available in
 * source code form to the general public and the MacHTTP.Org organization. You may not
 * redistribute source code or binary versions of the MacHTTP application that make use of
 * the MacHTTP name, logo, or icons without the expressed written consent of MacHTTP.Org
 * or Chuck Shotton.
 *
 * MacHTTP is a trademark of Chuck Shotton. Permission is granted
 * to MacHTTP.Org and its assignees use the MacHTTP name, logo, and icons.
 * Any use not authorized by MacHTTP.Org or Chuck Shotton is prohibited.
 *
 * Additional information can be found at http://www.machttp.org/
 *
 ******************************************************
 * Modifications:
 *
 * 03/01/01 - cshotton - initial verison
 * 11/17/01 - rpatters1 - modernized & de-linted
 * 11/19/01 - rpatters1 - made MPW-compatibile
 ******************************************************/
#include "config.h"
#include <cstdio>
#include <cstring>

#include <AppleEvents.h>
#include <AEObjects.h>
#include <AEPackObject.h>
#include <AERegistry.h>
#include <Threads.h>
#include <MacTypes.h>
#include <MacWindows.h>
#include <Files.h>
#include <Controls.h>

#include "MacTCPCommonTypes.h"
#include "TCPPB.h"
#include "TCPHi.h"
#include "http.h"
#include "TTY_Messages.h"
#include "Template.h"
#include "Logic.h"
#include "CTemplateAEVT.h"
#include "HTTP_Scripts.h"
#include "HTTP_Properties.h"
#include "Error_Messages.h"
#include "Prefs.h"

#include "globals.h"

/*******************************************************/

OSErr GotRequiredParams( AppleEvent *theAppleEvent )
{
DescType typeCode;
Size actualSize;
OSErr err;

	err = AEGetAttributePtr(theAppleEvent, keyMissedKeywordAttr,
					typeWildCard, &typeCode, nil, 0, &actualSize) ;
	if (err == errAEDescNotFound)
		return noErr;
	else if (err == noErr)
		return errAEEventNotHandled;
	else
		return err;
} /*GotRequiredParams*/



/*******************************************************/

/*There are no parameters for an open application event.  So all we need do is open
	an untitled window.  If a reply is sought, the default reply will do.
	Note that this message will normally come only from the Finder */
	
pascal OSErr HandleOAPP( AppleEvent *theAppleEvent, AppleEvent *PARM_UNUSED(reply), long PARM_UNUSED(handlerRefcon))
{
OSErr err;
//	TTY_WriteMessage("Open Event");
	/* We don't expect any params at all, but check in case the client requires any */
	err = GotRequiredParams( theAppleEvent ) ;
	if (err != noErr)
		return err;
	else {
		/* Perform open doc ation here*/
		return noErr;
	}
}

/*******************************************************/

void FailErr(OSErr err, char *a)
{
char s[512];
	if (err) {
		sprintf(s, "Error %d: %s (%s)", err, a, Error_Message (err));
		TTY_WriteMessage(s, TRUE);
	}
}

/*******************************************************/

pascal short MyWaitReplyIdleProc(EventRecord *PARM_UNUSED(event), RgnHandle PARM_UNUSED(mouseRgn), long PARM_UNUSED(sleeptime))
{
//	TTY_WriteMessage("La...");
	return FALSE;
}

/*******************************************************/

/* HandleQUIT():
	No parameters again.  Call the terminate function (NOTE the change from TESample.  We
	must not call ExitToShell before returning from this handler to the AEM or ePPC, as
	it is currently implemented, will croak.)  Terminate sets a global boolean causing
	the main event loop to exit once we return to it (unless the user cancells the quit
	when asked to save windows, in which case Terminate returns false and leaves the
	global boolean alone */

pascal OSErr HandleQUIT( AppleEvent *theAppleEvent, AppleEvent *reply, long PARM_UNUSED(handlerRefcon))
{
char *errStr;


//	TTY_WriteMessage("Quit Event");
/* We don't expect any params at all, but check in case the client requires any */
	FailErr( GotRequiredParams( theAppleEvent ), "parms") ;

	/* Terminate will put up dialogs if there are unsaved windows open */
/*	FailErr( AEInteractWithUser( 500, nil, MyWaitReplyIdleProc ) ) ;
	Error("\pQuitting");
*/

	MFileQuit();

	if (reply->dataHandle != nil) { /* a reply is sought */
		
		errStr = "MacHTTP is quitting!";

		return AEPutParamPtr( reply, 'errs', 'TEXT', errStr, strlen(errStr) );
	}
	else {
		return noErr;
	}
}


/*******************************************************/

/* HandleODOC:
	given a list of aliases in message, get the list, and then pass each constituent
	FSSpec to OpenFile.  If a reply is sought and for some reason OpenFile returns
	a nil WindowPtr indicating failure (probably because the maximum number of windows
	is already open) then give the client a string to post for his/her user.
*/
pascal OSErr HandleODOC( AppleEvent *theAppleEvent, AppleEvent *PARM_UNUSED(reply), long PARM_UNUSED(handlerRefcon))
{
	FSSpec myFSS;
	AEDescList docList;
	long index, itemsInList;
	Size actualSize;
	AEKeyword keywd;
	DescType typeCode;
char t[80];

/* we are expecting a list of aliases: first get the list into theDesc and check
	  that it is the only param the sender considers essential */
//	TTY_WriteMessage("Open Doc Event");

	FailErr( AEGetParamDesc( theAppleEvent, keyDirectObject, typeAEList, &docList ), "desc" ) ;
	FailErr( GotRequiredParams( theAppleEvent ), "parms" ) ;

	/* now get each alias from the list (as an FSSSpec) and open the associated file. */

	FailErr( AECountItems( &docList, &itemsInList ), "count" ) ;

	for (index = 1; index<=itemsInList; index++) {
		FailErr( AEGetNthPtr( &docList, index, typeFSS, &keywd, &typeCode,	/*coercion does alias->fsspec */
				(Ptr) &myFSS, sizeof( myFSS ), &actualSize ), "NthPtr") ;
		
		/** Do Open file stuff ignoreWPtr = OpenFile( &myFSS ) ;**/
		strncpy(t, (char *)&(myFSS.name[1]), myFSS.name[0]);
		t[myFSS.name[0]] = '\0';
		TTY_WriteMessage("The OpenDoc AppleEvent doesn't mean anything to MacHTTP!", TRUE);
	}


	FailErr( AEDisposeDesc( &docList ), "dispose" ) ;
	return noErr ;
} /*HandleODOC */


/*******************************************************/

/* HandlePDOC:
	Given a list of aliases in message, get the list, resolve each constituent alias
	to a cannonicalFileSpec, which is then passed to PrintFile (prints without
	opening any windows).
*/
pascal OSErr HandlePDOC( AppleEvent *theAppleEvent, AppleEvent *PARM_UNUSED(reply), long PARM_UNUSED(handlerRefcon))
{	
	FSSpec myFSS;
	AEDescList docList;
	long index, itemsInList;
	Size actSize;
	AEKeyword keywd;
	DescType typeCode;
		
//	TTY_WriteMessage("Print Doc Event");
	/* we are expecting a list of aliases: first get the list into docList */

	FailErr( AEGetParamDesc( theAppleEvent, keyDirectObject, typeAEList, &docList ), "desc" ) ;

	/* now check that all required params have been used: return error if there are any
	  that we don't understand */

	FailErr( GotRequiredParams( theAppleEvent ), "parms") ;

	/* now get each alias (as FSSpec) from the list and open it. */

	FailErr( AECountItems( &docList, &itemsInList ), "count" ) ;

	for (index = 1; index<=itemsInList; index++) {

		FailErr( AEGetNthPtr( &docList, index, typeFSS, &keywd, &typeCode,
				(Ptr) &myFSS, sizeof( myFSS ), &actSize ), "Nth" ) ;

		/*** Print stuff here PrintFile( &myFSS ) ;**/
	}
	FailErr( AEDisposeDesc( &docList ), "Dispose" ) ;
	TTY_WriteMessage("The PrintDoc AppleEvent doesn't mean anything to MacHTTP!", TRUE);
	
	return noErr;
}

/***********************************************/

pascal OSErr HandleMENU( AppleEvent *theAppleEvent, AppleEvent *PARM_UNUSED(reply), long PARM_UNUSED(handlerRefcon))
{	
	Size actSize;
	DescType typeCode;
	short id,item;
	char s[80];
	
//  TTY_WriteMessage("Menu AE Event", TRUE);

	/* now check that all required params have been used: return error if there are any
	  that we don't understand */

//	FailErr( GotRequiredParams( theAppleEvent ), "parms" ) ;

	FailErr( AEGetParamPtr( theAppleEvent, keyDirectObject, typeChar, &typeCode,
			(Ptr) s, sizeof( s ), &actSize ), "menu args" ) ;

	id = 0; item = 0;
	s[actSize] = '\0';
	sscanf(s,"%hd,%hd", &id, &item);

	
//	FailErr( AEInteractWithUser( 600, nil, MyWaitReplyIdleProc ), "" ) ;

	MenuItem(id,item);
	
	return noErr;
}


/***********************************************/

pascal OSErr HandleFLOG( AppleEvent *theAppleEvent, AppleEvent *PARM_UNUSED(reply), long PARM_UNUSED(handlerRefcon))
{	
	Size actSize;
	DescType typeCode;
	Boolean flag;
		
//	TTY_WriteMessage("flog AE Event", TRUE);
	FailErr( AEGetParamPtr( theAppleEvent, keyDirectObject, typeBoolean, &typeCode,
			(Ptr) &flag, sizeof( flag ), &actSize ), "flog args" ) ;

	MSuspendLogging (flag);
	
	return noErr;
}


/***********************************************/

pascal OSErr HandleFVRB( AppleEvent *theAppleEvent, AppleEvent *PARM_UNUSED(reply), long PARM_UNUSED(handlerRefcon))
{	
	Size actSize;
	DescType typeCode;
	Boolean flag;
//	TTY_WriteMessage("fvrb AE Event", TRUE);
	FailErr( AEGetParamPtr( theAppleEvent, keyDirectObject, typeBoolean, &typeCode,
			(Ptr) &flag, sizeof( flag ), &actSize ), "fvrb args" ) ;

	MVerboseMessages (flag);
	
	return noErr;
}


/***********************************************/

pascal OSErr HandleFCON( AppleEvent *theAppleEvent, AppleEvent *PARM_UNUSED(reply), long PARM_UNUSED(handlerRefcon))
{	
	Size actSize;
	DescType typeCode;
	Boolean flag;
		
//	TTY_WriteMessage("fcon AE Event", TRUE);
	FailErr( AEGetParamPtr( theAppleEvent, keyDirectObject, typeBoolean, &typeCode,
			(Ptr) &flag, sizeof( flag ), &actSize ), "fcon args" ) ;

	MRefuseConnections (flag);
	
	return noErr;
}


/***********************************************/

pascal OSErr HandleFWIN( AppleEvent *theAppleEvent, AppleEvent *PARM_UNUSED(reply), long PARM_UNUSED(handlerRefcon))
{	
	Size actSize;
	DescType typeCode;
	Boolean flag;
		
//	TTY_WriteMessage("fwin AE Event", TRUE);
	FailErr( AEGetParamPtr( theAppleEvent, keyDirectObject, typeBoolean, &typeCode,
			(Ptr) &flag, sizeof( flag ), &actSize ), "fwin args" ) ;

	MHideWindow (flag);
	
	return noErr;
}


/***********************************************/

pascal OSErr HandleSTAT( AppleEvent *PARM_UNUSED(theAppleEvent), AppleEvent *reply, long PARM_UNUSED(handlerRefcon))
{	
static char s[512];
	
	s[0] = '\0';
	LogMakeStatusReport (s);

	if (reply->descriptorType != typeNull) 
	FailErr( AEPutParamPtr(reply, keyDirectObject, typeChar,
		s, strlen (s) ), "STAT Reply");

	
	return noErr;
}


/***********************************************/
/* Add User */

pascal OSErr HandleAUsr( AppleEvent *theAppleEvent, AppleEvent *PARM_UNUSED(reply), long PARM_UNUSED(handlerRefcon))
{	
	Size actSize;
	DescType typeCode;
	char user[256], pass[256], realm[256], out[512];

	/* Get the direct parameter for this event (user name) */
	FailErr( AEGetParamPtr( theAppleEvent, keyDirectObject, typeChar, &typeCode,
			(Ptr) user, sizeof( user ), &actSize ), "AUsr user arg" ) ;

	user[actSize] = '\0';
			
	/* Get the "password" parameter for this event */
	FailErr( AEGetParamPtr( theAppleEvent, kAUsrPasswordKeyword, typeChar, &typeCode,
			(Ptr) pass, sizeof( pass ), &actSize ), "AUsr password arg" ) ;
			
	pass[actSize] = '\0';
	

	/* Get the "realm" parameter for this event */
	FailErr( AEGetParamPtr( theAppleEvent, kAUsrRealmKeyword, typeChar, &typeCode,
			(Ptr) realm, sizeof( realm ), &actSize ), "AUsr realm arg" ) ;
			
	realm[actSize] = '\0';
	
	sprintf (out, "%s�%s", user, realm);
	CtoPstr (out);
	CtoPstr (pass);
	return Prefs_WriteNewPassword ((StringPtr)out, (StringPtr)pass, FALSE);
}

/***********************************************/
/* Delete User */

pascal OSErr HandleDUsr( AppleEvent *theAppleEvent, AppleEvent *PARM_UNUSED(reply), long PARM_UNUSED(handlerRefcon))
{	
	Size actSize;
	DescType typeCode;
	char user[256], realm[256], out[512];

	/* Get the direct parameter for this event (user name) */
	FailErr( AEGetParamPtr( theAppleEvent, keyDirectObject, typeChar, &typeCode,
			(Ptr) user, sizeof( user ), &actSize ), "DUsr user arg" ) ;

	user[actSize] = '\0';
			
	/* Get the "realm" parameter for this event */
	FailErr( AEGetParamPtr( theAppleEvent, kDUsrRealmKeyword, typeChar, &typeCode,
			(Ptr) realm, sizeof( realm ), &actSize ), "DUsr realm arg" ) ;
			
	realm[actSize] = '\0';
	
	sprintf (out, "%s�%s", user, realm);
	CtoPstr (out);
	
	return Prefs_DeletePassword ((StringPtr)out, FALSE);
}

/***********************************************/
/* Validate User */

pascal OSErr HandleVusr( AppleEvent *theAppleEvent, AppleEvent *reply, long PARM_UNUSED(handlerRefcon))
{	
	Size actSize;
	DescType typeCode;
	char user[USER_NAME_SIZE+2], pass[PASSWORD_SIZE+2], realm[REALM_NAME_SIZE+2];
	OSErr err;
	Boolean ok;
	
	/* Get the direct parameter for this event (user name) */
	actSize = 0;
	FailErr( AEGetParamPtr( theAppleEvent, keyDirectObject, typeChar, &typeCode,
			(Ptr) user, sizeof( user ), &actSize ), "VUsr arg" ) ;

	user[actSize>USER_NAME_SIZE?USER_NAME_SIZE:actSize] = '\0';
			
	/* Get the "password" parameter for this event */
	actSize = 0;
	FailErr( AEGetParamPtr( theAppleEvent, kAUsrPasswordKeyword, typeChar, &typeCode,
			(Ptr) pass, sizeof( pass ), &actSize ), "VUsr password" ) ;
			
	pass[actSize>PASSWORD_SIZE?PASSWORD_SIZE:actSize] = '\0';
	

	/* Get the "realm" parameter for this event */
	actSize = 0;
	FailErr( AEGetParamPtr( theAppleEvent, kAUsrRealmKeyword, typeChar, &typeCode,
			(Ptr) realm, sizeof( realm ), &actSize ), "VUsr realm" ) ;
			
	realm[actSize>REALM_NAME_SIZE?REALM_NAME_SIZE:actSize] = '\0';
	
	ok = HTTP_LookupPassword (user, pass, realm);

	if (reply->descriptorType != typeNull) 
		err = AEPutParamPtr(reply, keyDirectObject, typeBoolean,
			&ok, sizeof (ok) );

	return err;
}

/***********************************************/
/* WSAPI_ReadHTTPData */

extern TCPStreamPtr streams; //this is a mostly private variable. Necessary here so we can iterate over and find the parent connection.

pascal OSErr HandleWRHD( AppleEvent *theAppleEvent, AppleEvent *reply, long PARM_UNUSED(handlerRefcon))
{	
Size actSize;
DescType typeCode;
unsigned long retID;
OSErr err;
char *temp;	
long dataLen;
TCPStreamPtr stream;

	temp = NULL;
	actSize=0;
	
	//get the connection id
	FailErr( err=AEGetParamPtr( theAppleEvent, kKeyConnectionID, typeLongInteger, &typeCode,
		(Ptr) &retID, sizeof (retID), &actSize ), "ReadHTTPData connection ID" ) ;
	
	//get the dataLen value
	if (!err) 
		FailErr( err=AEGetParamPtr( theAppleEvent, kKeyWSAPILength, typeLongInteger, &typeCode,
			(Ptr) &dataLen, sizeof (dataLen), &actSize ), "ReadHTTPData dataLen" ) ;

	if (!err) {
		stream = streams;
		while (stream) {
			if ((stream->id & CONNECTION_MASK) == (retID & CONNECTION_MASK)) {
				//make a buffer
				if (dataLen > 32678)
					dataLen = 32768;
				temp = NewPtr (dataLen);
				if (temp) {
					//read a chunk of data
					err = HTTP_ReadFromObjectBody (stream, temp, &dataLen);
					
					//construct the reply
					if (err)
						DisposePtr (temp);
					else {
						if (reply->descriptorType != typeNull) 
							err = AEPutParamPtr(reply, keyDirectObject, typeChar, temp, dataLen);
						DisposePtr (temp);
						return err;
					}
				}
				// if we're here, we failed
				return errAEEventNotHandled;
			}
			else
				stream = stream->next;
		}
		// if we're here, we failed
		return errAEEventNotHandled;
	}
	
	return err;
}

/***********************************************/
/* WSAPI_GetIndexedParameter */
/*  returns values for parameters matching W*API (indexed) parameters from WSAPI.h in the W*API SDK
	currently only implements content-length
*/

pascal OSErr HandleGETI( AppleEvent *theAppleEvent, AppleEvent *reply, long PARM_UNUSED(handlerRefcon))
{	
Size actSize;
DescType typeCode;
unsigned long retID;
OSErr err;
char *temp = NULL, parameter [8], index [256];	
TCPStreamPtr stream;
OSType whichParam = '    ';

	temp = NULL;
	actSize=0;
	
	//get the connection id
	FailErr( err=AEGetParamPtr( theAppleEvent, kKeyConnectionID, typeLongInteger, &typeCode,
		(Ptr) &retID, sizeof (retID), &actSize ), "GetIndexed connection ID" ) ;
	
	//get the parameter (direct param)
	if (!err) 
		FailErr( err=AEGetParamPtr( theAppleEvent, keyDirectObject, typeChar, &typeCode,
			(Ptr) parameter, sizeof (parameter)-1, &actSize ), "GetIndexed parameter" ) ;
	if (!err) {
		parameter [actSize] = '\0';
		whichParam = *((OSType *) parameter);
	}

	//get the index (optional)
	if (!err) 
		err=AEGetParamPtr( theAppleEvent, kKeyWSAPIIndex, typeChar, &typeCode,
			(Ptr) index, sizeof (index)-1, &actSize );
	if (err) {
		actSize = 0;
		err = noErr;
	}
	
	index [actSize] = '\0';

	if (!err) {
		stream = streams;
		while (stream) {
			if ((stream->id & CONNECTION_MASK) == (retID & CONNECTION_MASK))
				break;
			else
				stream = stream->next;
		}
		
		switch (whichParam) {
			case 'CLen':	//piContentLength
				sprintf (index, "%ld", stream->content_length);
				temp = index;
				break;
				
			default:
				temp = "\0";
				break;
		}
		
		if (temp) {	
			if (reply->descriptorType != typeNull) {
				err = AEPutParamPtr(reply, keyDirectObject, typeChar, temp, strlen (temp));
			}
		}
	}
	LogStartTimeout (stream, MAX_TIMEOUT); /*reset the time-out*/
	return err;
}

/***********************************************/

pascal OSErr HandleReply( AppleEvent *theAppleEvent, AppleEvent *PARM_UNUSED(reply), long PARM_UNUSED(handlerRefcon))
{	
Size actSize;
DescType typeCode;
static char s[1024];
unsigned short retID;
OSErr err;
Size len;
char *temp;
	FailErr (err=AEGetAttributePtr (theAppleEvent, keyReturnIDAttr, typeShortInteger, &typeCode, &retID, sizeof (retID), &actSize),"GetAttrPtr retID");
	if (!err) {
		if (debugLevel) {
			sprintf (s, "AppleEvent return ID %hu received", retID);
			TTY_WriteMessage(s, TRUE);
		}
		actSize=0;
		FailErr( err=AEGetParamPtr( theAppleEvent, keyDirectObject, typeChar, &typeCode,
			(Ptr) s, sizeof (s), &actSize ), "Getting ACGI reply string from HandleReply" ) ;
		if (!err) {
			temp = (char *) NewPtr (actSize+256); //over-allocate the buffer size in case the reply is small, there's an error, and we need to write messages into the buffer	
			if (temp) {
				if (sizeof (s) < actSize) {
					FailErr( err=AEGetParamPtr( theAppleEvent, keyDirectObject, typeChar, &typeCode,
						(Ptr) temp, actSize, &actSize ), "Getting ACGI reply string from HandleReply" ) ;
				}
				else {
					memcpy (temp, s, actSize);
				}
				temp [actSize]='\0';
				len = actSize;
				
				if (err) {
					sprintf (temp, "Error getting AppleEvent Reply string from ACGI app (%s)", 
							Error_Message (err));
					TTY_WriteMessage (temp, TRUE);
					len = strlen (temp);
				}
				
				err = LogAssignAppResults (retID, temp, len, err);
			}
			else {
				TTY_WriteMessage("Error allocating memory for ACGI execution results", TRUE);
				LogMemoryError();
				err = -1;
			}
		}
		else {
			temp = (char *) NewPtr(256);
			if (temp) {
				sprintf (temp, "Error getting reply from ACGI application. (%s)", Error_Message (err));
				len  = strlen (temp);
				err = LogAssignAppResults (retID, temp, len, err);
			}
		}
	}
	return err;
}


/***********************************************/

pascal void GetRawDataFromDescriptor(const AEDesc *theDesc, Ptr destPtr, Size destMaxSize, Size *actSize)
  {
	  Size copySize;
		if (theDesc->dataHandle) 
			{
				HLock((Handle)theDesc->dataHandle);
				*actSize = GetHandleSize((Handle)theDesc->dataHandle);
				
				copySize = *actSize<destMaxSize?*actSize:destMaxSize;
				
				BlockMove(*theDesc->dataHandle, destPtr, copySize);
				
				HUnlock((Handle)theDesc->dataHandle);
			}
		else
			*actSize = 0;
	} /*GetRawDataFromDescriptor*/

/***********************************************/

pascal OSErr GetIntegerFromDescriptor(const AEDesc *sourceDesc, short *result)
  {
	  OSErr   myErr;
		OSErr   ignoreErr;
		Size    intSize;
		AEDesc  resultDesc;
		
		*result = 0;
		myErr  = AECoerceDesc(sourceDesc,typeShortInteger,&resultDesc);
		
		if (myErr==noErr) 
			{
				GetRawDataFromDescriptor(&resultDesc, (Ptr)result, 2, &intSize);
				if (intSize>2) 
					myErr = errAECoercionFail;
			}
		
		if (resultDesc.dataHandle) 
			ignoreErr = AEDisposeDesc(&resultDesc);
			
		return(myErr);
	}
	
/***********************************************/

pascal OSErr GetBooleanFromDescriptor(const AEDesc *sourceDesc, Boolean *result)
  {
	  OSErr  myErr;
		OSErr  ignoreErr;
		Size   boolSize;
		AEDesc resultDesc;
		
		*result = false;
		myErr = AECoerceDesc(sourceDesc,typeBoolean,&resultDesc);
		
		if (myErr==noErr) 
			{
				GetRawDataFromDescriptor(&resultDesc, (Ptr)result, sizeof(Boolean), &boolSize);
				if (boolSize>sizeof(Boolean)) 
					myErr = errAECoercionFail;
			}
		
		if (resultDesc.dataHandle) 
			ignoreErr = AEDisposeDesc(&resultDesc);
			
		return(myErr);
	}

/***********************************************/

pascal OSErr GetApplicationProperty(const AEDesc *theObjToken, AEDesc *dataDesc)
{
	OSErr         theErr;
	applPropToken theApplPropToken;
	AEDesc        newDesc;
	Size          tokenSize;
	short 		i;
	Boolean		b;
	Size 		len;
	char 		s[258];
	
	theErr = AECoerceDesc(theObjToken, typeMyApplProp, &newDesc);
	if (theErr==noErr) {
		GetRawDataFromDescriptor(&newDesc, (Ptr)&theApplPropToken, sizeof(theApplPropToken), &tokenSize);
		theErr = AEDisposeDesc(&newDesc);
	}
	else
		return(theErr);

	theErr = kAEGenericErr;
	
	switch (theApplPropToken.tokenApplProperty) {
		case pDumpBufSize:
			i = Get_DumpBufSize ();
			theErr  = AECreateDesc(typeSMInt,&i,sizeof (i), dataDesc);
			break;
		
		case pPigDelay:
			i = Get_PigDelay ();
			theErr  = AECreateDesc(typeSMInt,&i,sizeof (i), dataDesc);
			break;
			
		case pMaxUsers:
			i = Get_MaxStreams ();
			theErr  = AECreateDesc(typeSMInt,&i,sizeof (i), dataDesc);
			break;
			
		case pNoDNS:
			b = Get_NoDNS ();
			theErr  = AECreateDesc(typeBoolean,&b,sizeof (b), dataDesc);
			break;
			
		case pTimeOut:
			i = Get_Timeout();
			theErr  = AECreateDesc(typeSMInt,&i,sizeof (i), dataDesc);
			break;
			
		case pMaxListens:
			i = Get_MaxListens ();
			theErr  = AECreateDesc(typeSMInt,&i,sizeof (i), dataDesc);
			break;
			
		case pLogging:
			b = !Get_SuspendLogFlag ();
			theErr  = AECreateDesc(typeBoolean, &b, sizeof (b), dataDesc);
			break;
			
		case pVerboseMessages:
			b = Get_VerboseFlag ();
			theErr  = AECreateDesc(typeBoolean,&b,sizeof (b), dataDesc);
			break;
			
		case pRefuseConnections:
			b = Get_RefuseConFlag ();
			theErr  = AECreateDesc(typeBoolean,&b,sizeof (b), dataDesc);
			break;
			
		case pDefaultMIMEType:
			len = sizeof (s);
			Get_DefaultMIMEType (s, &len);
			theErr  = AECreateDesc(typeChar,s,len, dataDesc);
			break;
			
		case pPort:
			i = Get_IPPort ();
			theErr  = AECreateDesc(typeSMInt,&i,sizeof (i), dataDesc);
			break;
			
/********************* not sure if it makes sense to support these as properties for security reasons
		case pIndexFile:
			len = sizeof (s);
			Get_DefaultMIMEType (s, &len);
			theErr  = AECreateDesc(typeChar,s,len, dataDesc);
			break;
			
		case pErrorFile:
			len = sizeof (s);
			Get_DefaultMIMEType (s, &len);
			theErr  = AECreateDesc(typeChar,s,len, dataDesc);
			break;
			
		case pLogFile:
			len = sizeof (s);
			Get_DefaultMIMEType (s, &len);
			theErr  = AECreateDesc(typeChar,s,len, dataDesc);
			break;
			
		case pNoAccessFile:
			len = sizeof (s);
			Get_DefaultMIMEType (s, &len);
			theErr  = AECreateDesc(typeChar,s,len, dataDesc);
			break;
**********************/
	}
	
	return(theErr);
} /* GetApplicationProperty */

/***********************************************/

pascal OSErr PropertyFromApplAccessor(DescType wantClass, const AEDesc *container,
										DescType PARM_UNUSED(containerClass), DescType form, 
										const AEDesc *selectionData, AEDesc *value,
										long PARM_UNUSED(theRefCon))
  {
	
		OSErr         myErr;
		OSErr         ignoreErr;
		appToken      theApplToken;
		DescType      theProperty;
		AEDesc        applDesc;
		AEDesc        propDesc;
		Size          actualSize;
		applPropToken myApplProp;
			
		value->dataHandle     = nil;
		applDesc.dataHandle   = nil;
		propDesc.dataHandle   = nil;
		
		if ((wantClass != cProperty) ||
			  (form != formPropertyID))
			{
				return(errAEWrongDataType);
			}
		
		/* get the application token - it's the container */
		
		myErr = AECoerceDesc(container, typeMyApplProp, &applDesc);
		GetRawDataFromDescriptor(&applDesc, (Ptr)&theApplToken, sizeof(theApplToken),  &actualSize);
				
		/* get the property - it's in the selection data */
		
		myErr = AECoerceDesc(selectionData, typeType, &propDesc);
		GetRawDataFromDescriptor(&propDesc, (Ptr)&theProperty, sizeof(theProperty), &actualSize);
		/*
			Combine the two into single token
		*/
		myApplProp.tokenApplToken    = theApplToken;
		myApplProp.tokenApplProperty = theProperty;
		
		/*shove the token into the value and return it.*/
		myErr = AECreateDesc(typeMyApplProp, (Ptr)&myApplProp, sizeof(myApplProp), value);
			
		if (applDesc.dataHandle)
			ignoreErr = AEDisposeDesc(&applDesc);
			
		if (propDesc.dataHandle)
			ignoreErr = AEDisposeDesc(&propDesc);
			
		return(myErr);
}	/* PropertyFromApplAccessor */


/***********************************************/

pascal OSErr HandleGetData(AEDesc *theObj, DescType PARM_UNUSED(whatType), AEDesc *dataDesc)
{

	OSErr           myErr;
	AEDesc          objTokenDesc;

	myErr = errAEWrongDataType;
	
	/*
		Coerce theObj into a token which we can use - 
			 set the property for that token
	*/

	
	myErr = AEResolve(theObj ,kAEIDoMinimum, &objTokenDesc);
  
	if (myErr == noErr)	{
		if (objTokenDesc.descriptorType == typeMyApplProp)
			myErr = GetApplicationProperty(&objTokenDesc, dataDesc);
	}
	
	if (!myErr) myErr = AEDisposeDesc(&objTokenDesc);
	
	return(myErr);
}	/* HandleGetData */

/***********************************************/

pascal OSErr DoGetData(const AppleEvent *theAppleEvent, AppleEvent *reply, long PARM_UNUSED(handlerRefCon))
{ 
	OSErr    myErr;
	OSErr    tempErr;
	AEDesc   myDirObj;
	AEDesc   myDataDesc;
	Size     actualSize;
	DescType returnedType;
	DescType reqType;
	
	myDataDesc.dataHandle = nil;
	myDirObj.dataHandle   = nil;
	
	/*
		extract the direct object, which is the object whose data is to be returned
	*/
	
	myErr  = AEGetParamDesc(theAppleEvent, keyDirectObject, typeWildCard, &myDirObj);
		
	/*
		now the get the type of data wanted - optional
	*/
	
	tempErr = AEGetParamPtr(theAppleEvent, keyAERequestedType, typeType, &returnedType, 
							(Ptr)&reqType, sizeof(reqType), &actualSize);
	
	if (tempErr!=noErr) 
		reqType = typeChar;
		
//	if (myErr == noErr) 
//		myErr = GotRequiredParams(theAppleEvent);
	
	/* get the data */
	if (myErr == noErr) 
		myErr = HandleGetData(&myDirObj, reqType, &myDataDesc);
		
	/* if they wanted a reply, attach it now */
	if (myErr==noErr) 
		if (reply->descriptorType != typeNull) 
			myErr = AEPutParamDesc(reply, keyDirectObject, &myDataDesc);
				
    if (myDataDesc.dataHandle)
		  tempErr = AEDisposeDesc(&myDataDesc);

    if (myDirObj.dataHandle)
		  tempErr = AEDisposeDesc(&myDirObj);
			
	return(myErr);
}	/* DoGetData */

/***********************************************/

pascal OSErr SetApplicationProperty(AEDesc *theObjToken, AEDesc *dataDesc)
{
	OSErr         theErr;
	applPropToken theApplPropToken;
	AEDesc        newDesc;
	Size          tokenSize;
	short 		i;
	Boolean		b;
	
	theErr = AECoerceDesc(theObjToken, typeMyApplProp, &newDesc);
	if (theErr==noErr) {
		GetRawDataFromDescriptor(&newDesc, (Ptr)&theApplPropToken, sizeof(theApplPropToken), &tokenSize);
		theErr = AEDisposeDesc(&newDesc);
	}
	else
		return(theErr);

	switch (theApplPropToken.tokenApplProperty) {
		case pDumpBufSize:
			theErr = GetIntegerFromDescriptor(dataDesc, &i);
			theErr = Set_DumpBufSize (i);
			break;
			
		case pPigDelay:
			theErr = GetIntegerFromDescriptor(dataDesc, &i);
			theErr = Set_PigDelay (i);
			break;
			
		case pMaxUsers:
			theErr = GetIntegerFromDescriptor(dataDesc, &i);
			theErr = Set_MaxStreams (i);
			break;
			
		case pNoDNS:
			theErr = GetBooleanFromDescriptor(dataDesc, &b);
			theErr = Set_NoDNS (b);
			break;
			
		case pTimeOut:
			theErr = GetIntegerFromDescriptor(dataDesc, &i);
			theErr = Set_Timeout (i);
			break;
			
		case pMaxListens:
			theErr = GetIntegerFromDescriptor(dataDesc, &i);
			theErr = Set_MaxListens (i);
			break;
			
		case pLogging:
			theErr = GetBooleanFromDescriptor(dataDesc, &b);
			Set_SuspendLogFlag (!b);
			break;
			
		case pVerboseMessages:
			theErr = GetBooleanFromDescriptor(dataDesc, &b);
			Set_VerboseFlag (b);
			break;
			
		case pRefuseConnections:
			theErr = GetBooleanFromDescriptor(dataDesc, &b);
			Set_RefuseConFlag (b);
			break;
			
	}
	
	return(theErr);
} /* SetApplicationProperty */

/***********************************************/

pascal OSErr HandleSetData(AEDesc *theObj, AEDesc *dataDesc)
{
  OSErr           myErr;
	AEDesc          objTokenDesc;
	
	objTokenDesc.dataHandle = nil;
		
	myErr = AEResolve(theObj ,kAEIDoMinimum, &objTokenDesc);
			
	if (myErr == noErr)	{
		if (objTokenDesc.descriptorType == typeMyApplProp)
			myErr = SetApplicationProperty(&objTokenDesc, dataDesc);
	}
	return(myErr);

}	/* HandleSetData */

/***********************************************/

pascal OSErr DoSetData(const AppleEvent *theAppleEvent, AppleEvent *PARM_UNUSED(reply), long PARM_UNUSED(handlerRefCon))
{	
	OSErr  myErr;
	OSErr  ignoreErr;
	AEDesc myDirObj;
	AEDesc myDataDesc;
	
	myDataDesc.dataHandle = nil;
	myDirObj.dataHandle   = nil;
			
	/* pick up the direct object, which is the object whose data is to be set */
	
	myErr = AEGetParamDesc(theAppleEvent,
												 keyDirectObject,
												 typeWildCard,
												 &myDirObj);
		
	/* now the data to set it to - typeWildCard means get as is*/
	if (myErr == noErr) 
		myErr = AEGetParamDesc( theAppleEvent, keyAEData, typeWildCard, &myDataDesc);
			
	/* set the data */
	if (myErr == noErr) 
		myErr = HandleSetData(&myDirObj, &myDataDesc);
		
	if (myDataDesc.dataHandle)
		ignoreErr = AEDisposeDesc(&myDataDesc);
		
	if (myDirObj.dataHandle)
		ignoreErr = AEDisposeDesc(&myDirObj);

	return(myErr);
}	/* DoSetData */

/***********************************************/

pascal OSErr HandleEverythingElse( AppleEvent *theAppleEvent, AppleEvent *PARM_UNUSED(reply), long PARM_UNUSED(handlerRefcon))
{	
Size actSize;
DescType typeCode;
static char s[512], temp [1024];
AEEventClass evt;
AEEventID id;
	if (debugLevel) {
		temp[0]='\0';
		TTY_WriteMessage ("Unknown AppleEvent received. It will be discarded.", TRUE);
		FailErr (AEGetAttributePtr (theAppleEvent, keyEventClassAttr, typeType, &typeCode, &evt, sizeof (evt), &actSize),"GetAttrPtr event");
		FailErr (AEGetAttributePtr (theAppleEvent, keyEventIDAttr, typeType, &typeCode, &id, sizeof (id), &actSize),"GetAttrPtr id");

		sprintf (s, "AppleEvent Class = %4.4s, ID = %4.4s", (char *) &evt, (char *) &id);
		TTY_WriteMessage(s, TRUE);
	}
	return errAEEventNotHandled;
}


/***********************************************/

OSErr SendMENUToSelf (short menuID, short menuItem)
{
ProcessSerialNumber sn;
AEDesc theAddress;
AppleEvent ourEvent,ourReply;
char args[32];

//  TTY_WriteMessage ("SendMENUToSelf", TRUE);
	sprintf (args,"%hd,%hd",menuID, menuItem);
	sn.highLongOfPSN = 0;
	sn.lowLongOfPSN = kCurrentProcess;
	FailErr(AECreateDesc(typeProcessSerialNumber, (Ptr)&sn, sizeof(ProcessSerialNumber), &theAddress),"CreateDesc PSN");
    FailErr(AECreateAppleEvent(kMyEventClass, kMyAEMenu, &theAddress, kAutoGenerateReturnID, kAnyTransactionID, &ourEvent),"Create MENU Event");
	FailErr( AEPutParamPtr(&ourEvent, keyDirectObject, typeChar, args, strlen (args)), "args parameter");
    FailErr(AESend(&ourEvent, &ourReply, kAECanInteract + kAENoReply + kAECanSwitchLayer, kAENormalPriority,
		kAEDefaultTimeout,/*(IdleProcPtr)*/nil , nil), "Sending menu Event");

	FailErr( AEDisposeDesc( &theAddress ), "dispose address" ) ;
	FailErr( AEDisposeDesc( &ourEvent ), "dispose event" ) ;
	//FailErr( AEDisposeDesc( &ourReply ), "dispose reply" ) ;
	return noErr;
}


/***********************************************/

OSErr SendFlagToSelf (long eventCode, Boolean value)
{
ProcessSerialNumber sn;
AEDesc theAddress;
AppleEvent ourEvent,ourReply;

	sn.highLongOfPSN = 0;
	sn.lowLongOfPSN = kCurrentProcess;
	FailErr(AECreateDesc(typeProcessSerialNumber, (Ptr)&sn, sizeof(ProcessSerialNumber), &theAddress),"flag CreateDesc PSN");
    FailErr(AECreateAppleEvent(kMyEventClass, eventCode, &theAddress, kAutoGenerateReturnID, kAnyTransactionID, &ourEvent),"flag Create MENU Event");
	FailErr( AEPutParamPtr(&ourEvent, keyDirectObject, typeBoolean, &value, sizeof (value)), "flag args parameter");
    FailErr(AESend(&ourEvent, &ourReply, kAECanInteract + kAEWaitReply + kAECanSwitchLayer, kAENormalPriority,
		kAEDefaultTimeout,/*(IdleProcPtr)*/nil , nil), "Sending flag Event");

	FailErr( AEDisposeDesc( &theAddress ), "flag dispose address" ) ;
	FailErr( AEDisposeDesc( &ourEvent ), "flag dispose event" ) ;
	FailErr( AEDisposeDesc( &ourReply ), "flag dispose reply" ) ;
	return noErr;
}


/***********************************************/

OSErr SendQuitToSelf ()
{
ProcessSerialNumber sn;
AEDesc theAddress;
AppleEvent ourEvent,ourReply;

	sn.highLongOfPSN = 0;
	sn.lowLongOfPSN = kCurrentProcess;
	FailErr(AECreateDesc(typeProcessSerialNumber, (Ptr)&sn, sizeof(ProcessSerialNumber), &theAddress),"quit CreateDesc PSN");
    FailErr(AECreateAppleEvent(kCoreEventClass, kAEQuitApplication, &theAddress, kAutoGenerateReturnID, kAnyTransactionID, &ourEvent),"flag Create MENU Event");
    FailErr(AESend(&ourEvent, &ourReply, kAECanInteract + kAEWaitReply + kAECanSwitchLayer, kAENormalPriority,
		kAEDefaultTimeout,/*(IdleProcPtr)*/nil , nil), "Sending flag Event");

	FailErr( AEDisposeDesc( &theAddress ), "flag dispose address" ) ;
	FailErr( AEDisposeDesc( &ourEvent ), "flag dispose event" ) ;
	FailErr( AEDisposeDesc( &ourReply ), "flag dispose reply" ) ;
	return noErr;
}


/***********************************************/
OSErr InitAppleEvents()
{
OSErr aevtErr;
	aevtErr = noErr ;

	aevtErr = AEObjectInit();
	if ( aevtErr == noErr ) 
		aevtErr = AEInstallEventHandler( kCoreEventClass, kAEQuitApplication,
				NewAEEventHandlerProc( HandleQUIT ), 0, false ) ;
	if ( aevtErr == noErr ) 
		aevtErr = AEInstallEventHandler( kCoreEventClass, kAEOpenApplication,
				NewAEEventHandlerProc( HandleOAPP ), 0, false ) ;
	if ( aevtErr == noErr ) 
		aevtErr = AEInstallEventHandler( kCoreEventClass, kAEOpenDocuments,
				NewAEEventHandlerProc( HandleODOC ), 0, false ) ;
	if ( aevtErr == noErr ) 
		aevtErr = AEInstallEventHandler( kCoreEventClass, kAEPrintDocuments,
				NewAEEventHandlerProc( HandlePDOC ), 0, false ) ;
	if ( aevtErr == noErr ) 
		aevtErr = AEInstallEventHandler( kMyEventClass, kMyAEMenu,
				NewAEEventHandlerProc( HandleMENU ), 0, false ) ;
	if ( aevtErr == noErr ) 
		aevtErr = AEInstallEventHandler( kMyEventClass, kMyAESuspendLogging,
				NewAEEventHandlerProc( HandleFLOG ), 0, false ) ;
	if ( aevtErr == noErr ) 
		aevtErr = AEInstallEventHandler( kMyEventClass, kMyAEVerbose,
				NewAEEventHandlerProc( HandleFVRB ), 0, false ) ;
	if ( aevtErr == noErr ) 
		aevtErr = AEInstallEventHandler( kMyEventClass, kMyAERefuseConnections,
				NewAEEventHandlerProc( HandleFCON ), 0, false ) ;
	if ( aevtErr == noErr ) 
		aevtErr = AEInstallEventHandler( kMyEventClass, kMyAEHideWindow,
				NewAEEventHandlerProc( HandleFWIN ), 0, false ) ;
	if ( aevtErr == noErr )
		aevtErr = AEInstallEventHandler( kMyEventClass, kMyAEStatus,
				NewAEEventHandlerProc( HandleSTAT ), 0, false ) ;
	if ( aevtErr == noErr )
		aevtErr = AEInstallEventHandler( kMyEventClass, kMyAEAddUser,
				NewAEEventHandlerProc( HandleAUsr ), 0, false ) ;
	if ( aevtErr == noErr )
		aevtErr = AEInstallEventHandler( kMyEventClass, kMyAEDeleteUser,
				NewAEEventHandlerProc( HandleDUsr ), 0, false ) ;
	if ( aevtErr == noErr )
		aevtErr = AEInstallEventHandler( kMyEventClass, kMyAEValidateUser,
				NewAEEventHandlerProc( HandleVusr ), 0, false ) ;
	if ( aevtErr == noErr )
		aevtErr = AEInstallEventHandler( kCoreEventClass, kAEAnswer,
				NewAEEventHandlerProc( HandleReply ), 0, false ) ;
	if ( aevtErr == noErr )
		aevtErr = AEInstallEventHandler( kAECoreSuite, kAEGetData, 
				NewAEEventHandlerProc(DoGetData), 0, false);
	if ( aevtErr == noErr )
		aevtErr = AEInstallEventHandler( kWSAPIEventClass, kAEWSAPIReadHTTPData, 
				NewAEEventHandlerProc(HandleWRHD), 0, false);
	if ( aevtErr == noErr )
		aevtErr = AEInstallEventHandler( kWSAPIEventClass, kAEWSAPIGetIndexedParameter, 
				NewAEEventHandlerProc(HandleGETI), 0, false);
			

	aevtErr = AEInstallEventHandler( kAECoreSuite, kAESetData,
				NewAEEventHandlerProc(DoSetData),0, false);
				
	aevtErr = AEInstallObjectAccessor(cProperty, typeWildCard, NewOSLAccessorProc(PropertyFromApplAccessor),0,false);
	
	if ( aevtErr == noErr )  {
		aevtErr = AEInstallEventHandler( typeWildCard, typeWildCard,
				NewAEEventHandlerProc( HandleEverythingElse ), 0, false ) ;
		//TTY_WriteMessage("Apple Events initialized.", TRUE);
	}
	
	return aevtErr;
}
