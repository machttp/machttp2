/*HTTP_Scripts.c*/
/******************************************************
 *
 * Lawyer stuff:
 *
 * MacHTTP 2.x, source code
 * Copyright �1993-2001 Chuck Shotton
 * All Rights Reserved.
 *
 * This source code is made available under the terms of the MacHTTP Source License.
 * This license grants you the right to use the source code to create new versions
 * of and derivative works from the original MacHTTP source code. Under the terms of
 * this license, any modifications made to the source code must be made available in
 * source code form to the general public and the MacHTTP.Org organization. You may not
 * redistribute source code or binary versions of the MacHTTP application that make use of
 * the MacHTTP name, logo, or icons without the expressed written consent of MacHTTP.Org
 * or Chuck Shotton.
 *
 * MacHTTP is a trademark of Chuck Shotton. Permission is granted
 * to MacHTTP.Org and its assignees use the MacHTTP name, logo, and icons.
 * Any use not authorized by MacHTTP.Org or Chuck Shotton is prohibited.
 *
 * Additional information can be found at http://www.machttp.org/
 *
 ******************************************************
 * Modifications:
 *
 * 03/01/01 - cshotton - initial verison
 * 11/17/01 - rpatters1 - modernized and de-linted
 ******************************************************/

#include "config.h"

#include <MacTypes.h>
#include <MacMemory.h>
#include <Controls.h>
#include <Components.h>
#include <AppleEvents.h>
#include <AppleScript.h>
#include <processes.h>
#include <files.h>
#include <Aliases.h>
#include <Threads.h>

#include <cstdio>
#include <cstdlib>
#include <cstring>

#include "MacTCPCommonTypes.h"
#include "TCPPB.h"
#include "TCPHi.h"
#include "http.h"
#include "CTemplateAEVT.h"
#include "HTTP_Scripts.h"
#include "TTY_Messages.h"
#include "ResolvePath.h"
#include "Error_Messages.h"
#include "HTTP_IPCaching.h"
#include "Logic.h"
#include "globals.h"

static ComponentInstance gScriptingComponent = NULL;

/*************************************************/

void ShutDownAppleScript()
{
	CloseComponent(gScriptingComponent);
	
	gScriptingComponent = nil;
}

/*************************************************/

OSErr InitAppleScript()
{
	OSErr		     myErr;
	ComponentDescription descr;
	ComponentDescription capabilities;
	Component	     myComponent;
	EventRecord	     myEvent;
	short		     retryCount;
			
	if (gHasComponents<=0) {
		TTY_WriteMessage ("Component Manager is not present. Required for AppleScript.", TRUE);
		gScriptingComponent = NULL;
		return -1;
	}
	
	gScriptingComponent = OpenDefaultComponent(kOSAComponentType, 
                         'scpt');
	if (!gScriptingComponent) {
		TTY_WriteMessage("Unable to open AppleScript component.", TRUE);
		return(-1);
	}
	else
		atexit(ShutDownAppleScript);
	return noErr;
	
	retryCount = 0;
	
	do {
		/* Don't lose the high level events - expect a null back */
		
		myErr = 
			WaitNextEvent(
				mDownMask+mUpMask+keyDownMask+keyUpMask+autoKeyMask, 
				&myEvent,
				6, /* was 4 seconds */
				nil);
	
		descr.componentType	    = kOSAComponentType;
		descr.componentSubType	    = kAppleScriptSubtype;
		descr.componentManufacturer = (OSType) 0;
		descr.componentFlags	    = kOSASupportsCompiling + 
												kOSASupportsGetSource + 
												kOSASupportsAESending;
		descr.componentFlagsMask    = descr.componentFlags;
		
		myComponent = FindNextComponent(nil, &descr);
		
		retryCount++;
	} while (myComponent==nil && retryCount<15); /* Try for one minute */
	
	if (myComponent==nil)
		return -1;
	else {
		myErr = GetComponentInfo(myComponent, &capabilities, nil, nil, nil);
		gScriptingComponent = OpenComponent(myComponent);
		if (!gScriptingComponent)
			return(-1);
		else
			atexit(ShutDownAppleScript);
	}
		
	return myErr;
}

/*************************************************/

void HTTP_TranslateResult (char *result, char *output)
{
char cr, lf;
short crSeen;

	cr = (char) 13;
	lf = (char) 10;

	crSeen = FALSE;
	while (*result) {
		if (*result == cr) {
			if (crSeen) {
				*output++=cr;
				*output++=lf;
			}
			crSeen = TRUE;
			result++;
		}
		else if (*result=='\\') {
			result++;
			if (crSeen) {
				*output++=cr;
				*output++=lf;
				crSeen = FALSE;
			}
			*output++=*result++;
		}
		else {
			if (crSeen) {
				*output++=cr;
				if (*result != lf) 
					*output++=lf;
				crSeen = FALSE;
			}
			else if (*result == lf)
				*output++ = cr;
				
			*output++ = *result++;
		}
	}
	if (crSeen) {
		*output++=cr;
		*output++=lf;
	}

	*output = '\0';
}

/*************************************************/

void HTTP_DoScript(char *scriptText)
{
    long i;
	AEDesc	source;
	AEDesc	result;
	OSErr myErr;
	if (!gScriptingComponent)
		if (InitAppleScript()) {
			TTY_WriteMessage("Couldn't initialize AppleScript",TRUE);
			scriptText[0]='\0';
			return;
		}
		
	AECreateDesc(typeChar, scriptText, strlen(scriptText), &source);
	
	if (!(myErr=OSADoScript(
			gScriptingComponent, 
			&source, 
			kOSANullScript, 
			typeChar, 
			kOSAModeCanInteract,
			&result)))
	{
		AEDisposeDesc(&source);
		
		if (!AECoerceDesc(&result, typeChar, &source)) {
			HLock(source.dataHandle);
			
			i=GetHandleSize(source.dataHandle);
			(*(source.dataHandle))[i-1]='\0';
			HTTP_TranslateResult (&((*(source.dataHandle))[1]), scriptText);
			AEDisposeDesc(&source);
			
		}
		else
			scriptText[0]='\0';
			
		AEDisposeDesc(&result);
	} else {
		AEDisposeDesc(&source);
		scriptText[0]='\0';
		
	}
}

/**************************************************************/

OSErr HTTP_LaunchApp(char *path, ProcessSerialNumberPtr sn)
{
    FSSpec launchApp;
	OSErr myErr;
    LaunchParamBlockRec launchThis;
	char myPath[258];
	Boolean wasAlias, wasFolder;
	FSSpec spec;
	
	/* get the application to launch */
	
//	safecpy (myPath, path, sizeof (myPath)-1);
//	if (myErr = HTTP_ResolvePath(myPath, 256, TRUE, &wasAlias)) {

	myErr = ResolvePathAlias (path, myPath, sizeof (myPath)-1, &spec, &wasFolder, &wasAlias);
	if (myErr) {
		if (debugLevel) TTY_WriteMessage ("Error resolving application's alias", TRUE);
		return myErr;
	}

    CtoPstr (myPath);
    myErr = FSMakeFSSpec(0, 0, (StringPtr) myPath, &launchApp);
    
	/* stuff it in the launch parameter block */
    launchThis.launchAppSpec = &launchApp;
    
    launchThis.launchAppParameters = nil;
    
    /* launch the thing */
    launchThis.launchBlockID = extendedBlock;
    launchThis.launchEPBLength = extendedBlockLen;
    launchThis.launchFileFlags = (short) 0;
    launchThis.launchControlFlags = launchContinue + launchNoFileFlags + launchDontSwitch;

    myErr = LaunchApplication(&launchThis);
    if (myErr) {
    	if (debugLevel) {
    		sprintf (myPath, "Launch Error %s\n", Error_Message (myErr));
    		TTY_WriteMessage (myPath, TRUE);
    	}
    	return myErr;
    }
    else {
    	*sn = launchThis.launchProcessSN;
    	return 0;
    }
}

/***********************************************/

OSErr HTTP_DoApp (char *appName, char *args, char *result, Size *len)
{
ProcessSerialNumber sn;
AEDesc theAddress;
AppleEvent ourEvent,ourReply;
DescType typeCode;
Size actSize;
OSErr err;
char *temp;
	err = HTTP_LaunchApp(appName, &sn);
	if (err) {
		TTY_WriteMessage("Error launching app", TRUE);
		strcpy (result, "<title>Oops!</title><h1>Error! Unable to execute the requested application.</h1>");
		*len = strlen (result);
		return err;
	}
	else {
		FailErr(AECreateDesc(typeProcessSerialNumber, (Ptr)&sn, sizeof(ProcessSerialNumber), &theAddress),"CreateDesc PSN");
    	FailErr(AECreateAppleEvent(kMyEventClass, kMyAESearch, &theAddress, kAutoGenerateReturnID, kAnyTransactionID, &ourEvent),"Create Event");
		FailErr( AEPutParamPtr(&ourEvent, keyDirectObject, typeChar, args, strlen (args)), "args parameter");
        FailErr(AESend(&ourEvent, &ourReply, kAECanInteract + kAEWaitReply + kAECanSwitchLayer, kAENormalPriority,
               kAEDefaultTimeout,/*(IdleProcPtr)*/nil , nil), "Sending srch Event");

		temp = (char *) NewPtr(HTTP_RESULT_SIZE);
		if (temp) {
			FailErr( AEGetParamPtr( &ourReply, keyDirectObject, typeChar, &typeCode,
				(Ptr) temp, *len, &actSize ), "Getting reply string" ) ;
			temp[actSize>*len?*len:actSize] = '\0';
			HTTP_TranslateResult (temp, result);
			*len = strlen (result);
			DisposePtr (temp);
			err = noErr;
		}
		else {
			TTY_WriteMessage("Error allocating memory for app execution results", TRUE);
			LogMemoryError();
			err = -1;
		}
		FailErr( AEDisposeDesc( &theAddress ), "dispose address" ) ;
		FailErr( AEDisposeDesc( &ourEvent ), "dispose event" ) ;
		FailErr( AEDisposeDesc( &ourReply ), "dispose reply" ) ;
		return err;
	}
}

/***********************************************/

static void ActionToString (TCPStreamPtr stream, char *s, char *def);
static void ActionToString (TCPStreamPtr stream, char *s, char *def)
{
	switch (stream->actionTaken) {
		case A_ERROR:
			strcpy (s, "ERROR");
			break;
			
		case A_NOACCESS:
			strcpy (s, "NOACCESS");
			break;
			
		case A_INDEX:
			strcpy (s, "INDEX");
			break;
			
		case A_PREPROCESSOR:
			strcpy (s, "PREPROCESSOR");
			break;
			
		case A_POSTPROCESSOR:
			strcpy (s, "POSTPROCESSOR");
			break;
			
		default:
			strcpy (s, def);
			break;
	}
	
}

/***********************************************/

OSErr HTTP_DoCGI (TCPStreamPtr stream, HTTPMethod method, char *appName, char *pathArgs, char *searchArgs, char *postArgs,
					char *address, char *user, char *password, char *fromUser, char *serverName, char *serverPort,
					char *scriptName, char *contentType, char *referer, char *result, Size *len)
{
ProcessSerialNumber sn;
AEDesc theAddress;
AppleEvent ourEvent,ourReply;
DescType typeCode;
Size actSize;
OSErr err;
char *temp;
Handle temph;
char s[64];

	err = HTTP_LaunchApp(appName, &sn);
	if (err) {
		TTY_WriteMessage("Error launching CGI app", TRUE);
		strcpy (result, "<title>Oops!</title><h1>Error! Unable to execute the requested CGI application.</h1>");
		*len = strlen (result);
		return err;
	}
	else {
		FailErr(AECreateDesc(typeProcessSerialNumber, (Ptr)&sn, sizeof(ProcessSerialNumber), &theAddress),"CreateDesc PSN");
    	FailErr(AECreateAppleEvent(kMyEventClass, kMyAESearchDoc, &theAddress, kAutoGenerateReturnID, kAnyTransactionID, &ourEvent),"Create Event");
		FailErr( AEPutParamPtr(&ourEvent, keyDirectObject, typeChar, pathArgs, strlen (pathArgs)), "pathArgs parameter");
		FailErr( AEPutParamPtr(&ourEvent, kForKeyword, typeChar, searchArgs, strlen (searchArgs)), "searchArgs parameter");
		FailErr( AEPutParamPtr(&ourEvent, kUserKeyword, typeChar, user, strlen (user)), "user parameter");
		FailErr( AEPutParamPtr(&ourEvent, kPasswordKeyword, typeChar, password, strlen (password)), "password parameter");
		FailErr( AEPutParamPtr(&ourEvent, kFromUser, typeChar, fromUser, strlen (fromUser)), "fromUser parameter");
		FailErr( AEPutParamPtr(&ourEvent, kAddressKeyword, typeChar, address, strlen (address)), "address parameter");
		FailErr( AEPutParamPtr(&ourEvent, kServerName, typeChar, serverName, strlen (serverName)), "serverName parameter");
		FailErr( AEPutParamPtr(&ourEvent, kServerPort, typeChar, serverPort, strlen (serverPort)), "serverPort parameter");
		FailErr( AEPutParamPtr(&ourEvent, kScriptName, typeChar, scriptName, strlen (scriptName)), "scriptName parameter");
		FailErr( AEPutParamPtr(&ourEvent, kContentType, typeChar, contentType, strlen (contentType)), "contentType parameter");
		FailErr( AEPutParamPtr(&ourEvent, kRefererKeyword, typeChar, referer, strlen (referer)), "referer parameter");
		FailErr( AEPutParamPtr(&ourEvent, kUserAgentKeyword, typeChar, stream->user_agent, strlen (stream->user_agent)), "user agent parameter");
		FailErr( AEPutParamPtr(&ourEvent, 'DIRE', typeFSS, stream->virtual_dir, sizeof (FSSpec)), "virtual directory parameter");
		
		//action
		if (stream->action) {
			ActionToString (stream, s, (stream->action)->tag);
			FailErr( AEPutParamPtr(&ourEvent, kActionKeyword, typeChar, s, strlen (s)), "action parameter");
			FailErr( AEPutParamPtr(&ourEvent, kActionPathKeyword, typeChar, (stream->action)->path, strlen ((stream->action)->path)), "action path parameter");
		} else {
			ActionToString (stream, s, "CGI");
			FailErr( AEPutParamPtr(&ourEvent, kActionKeyword, typeChar, s, strlen (s)), "action parameter");
			FailErr( AEPutParamPtr(&ourEvent, kActionPathKeyword, typeChar, scriptName, strlen (scriptName)), "action path parameter"); //may need to be url_realname
		}
		
 		if (method==METHOD_POST)
			FailErr( AEPutParamPtr(&ourEvent, kPostKeyword, typeChar, 
					postArgs, stream->post_arg_byte_count /*strlen (postArgs)*/), "postArgs parameter");
		else
			FailErr( AEPutParamPtr(&ourEvent, kPostKeyword, typeChar, 
					"", 0), "postArgs parameter (0)");
		FailErr( AEPutParamPtr(&ourEvent, kMethodKeyword, typeChar, 
				methodTokens[method], strlen (methodTokens[method])), 
				"method parameter");

		//client IP
		HTTP_AddrToStr (stream->remoteHost, s);
		FailErr( AEPutParamPtr(&ourEvent, kClientIPAddress, typeChar, 
				s, strlen (s)), "client IP parameter");

		//full request
		FailErr( AEPutParamPtr(&ourEvent, kFullRequestKeyword, typeChar, 
				stream->request, stream->request_byte_count /*strlen (stream->request)*/), "request parameter");

		//connection ID
		FailErr( AEPutParamPtr(&ourEvent, kConnectionIDKeyword, typeLongInteger, 
				(Ptr) &(stream->id), (Size) sizeof (stream->id)), "connection ID parameter");
		
		//send the event
        FailErr(err=AESend(&ourEvent, &ourReply, kAECanInteract + kAEWaitReply + kAECanSwitchLayer, kAENormalPriority,
               kAEDefaultTimeout,/*(IdleProcPtr)*/nil , nil), "Sending CGI sdoc Event");

/*added*/
		FailErr(err=AEGetParamPtr( &ourReply, keyDirectObject, typeChar, &typeCode,
			(Ptr) result, *len, &actSize ), "Getting CGIreply string" ) ;
		if (actSize>*len) {
			result[*len] = '\0';
		}
		else {
			result[actSize] = '\0';
			*len = actSize;
		}

		if (0) {
/***/
//		if (!err) {
			temph = NULL;
			temp = NULL;
			temph = TempNewHandle (HTTP_RESULT_SIZE, &err);
			if (err == noErr) {
				HLock (temph);
				temp = *temph;
			}
			else { /*see if there's app memory*/
				temp = (char *) NewPtr (HTTP_RESULT_SIZE);
			}
				
			if (temp) {
				FailErr( AEGetParamPtr( &ourReply, keyDirectObject, typeChar, &typeCode,
					(Ptr) temp, *len, &actSize ), "Getting CGIreply string" ) ;
				temp[actSize>*len?*len:actSize] = '\0';
				HTTP_TranslateResult (temp, result);
				*len = strlen (result);
				
				if (temph) {
					HUnlock (temph);
					DisposeHandle (temph);
				}
				else {
					DisposePtr (temp);
				}
				err = noErr;
			}
			else {
				TTY_WriteMessage("Error allocating memory for CGI execution results", TRUE);
				LogMemoryError();
				err = -1;
			}
		}
		
		FailErr( AEDisposeDesc( &theAddress ), "dispose address" ) ;
		FailErr( AEDisposeDesc( &ourEvent ), "dispose event" ) ;
		FailErr( AEDisposeDesc( &ourReply ), "dispose reply" ) ;
		return err;
	}
}

/***********************************************/

OSErr HTTP_DoACGI (TCPStreamPtr stream, HTTPMethod method, char *appName, char *pathArgs, char *searchArgs, char *postArgs,
					char *address, char *user, char *password, char *fromUser, char *serverName, char *serverPort,
					char *scriptName, char *contentType)
{
ProcessSerialNumber sn;
AEDesc theAddress;
AppleEvent ourEvent,ourReply;
OSErr err;
unsigned short tid = 0;

char s[64];
	err = HTTP_LaunchApp(appName, &sn);
	if (err) {
		return err;
	}
	else {
		tid = stream->id & 0x0000FFFF;
		FailErr(AECreateDesc(typeProcessSerialNumber, (Ptr)&sn, sizeof(ProcessSerialNumber), &theAddress),"CreateDesc PSN");
    	FailErr(AECreateAppleEvent(kMyEventClass, kMyAESearchDoc, &theAddress, tid, 
    			kAnyTransactionID, &ourEvent),"Create Event");
		FailErr( AEPutParamPtr(&ourEvent, keyDirectObject, typeChar, pathArgs, strlen (pathArgs)), "pathArgs parameter");
		FailErr( AEPutParamPtr(&ourEvent, kForKeyword, typeChar, searchArgs, strlen (searchArgs)), "searchArgs parameter");
		FailErr( AEPutParamPtr(&ourEvent, kUserKeyword, typeChar, user, strlen (user)), "user parameter");
		FailErr( AEPutParamPtr(&ourEvent, kPasswordKeyword, typeChar, password, strlen (password)), "password parameter");
		FailErr( AEPutParamPtr(&ourEvent, kFromUser, typeChar, fromUser, strlen (fromUser)), "fromUser parameter");
		FailErr( AEPutParamPtr(&ourEvent, kAddressKeyword, typeChar, address, strlen (address)), "address parameter");
		FailErr( AEPutParamPtr(&ourEvent, kServerName, typeChar, serverName, strlen (serverName)), "serverName parameter");
		FailErr( AEPutParamPtr(&ourEvent, kServerPort, typeChar, serverPort, strlen (serverPort)), "serverPort parameter");
		FailErr( AEPutParamPtr(&ourEvent, kScriptName, typeChar, scriptName, strlen (scriptName)), "scriptName parameter");
		FailErr( AEPutParamPtr(&ourEvent, kContentType, typeChar, contentType, strlen (contentType)), "contentType parameter");
		FailErr( AEPutParamPtr(&ourEvent, kRefererKeyword, typeChar, stream->url_referer, strlen (stream->url_referer)), "referer parameter");
		FailErr( AEPutParamPtr(&ourEvent, kUserAgentKeyword, typeChar, stream->user_agent, strlen (stream->user_agent)), "user agent parameter");
		FailErr( AEPutParamPtr(&ourEvent, 'DIRE', typeFSS, stream->virtual_dir, sizeof (FSSpec)), "virtual directory parameter");

		//action
		if (stream->action) {
			ActionToString (stream, s, (stream->action)->tag);
			FailErr( AEPutParamPtr(&ourEvent, kActionKeyword, typeChar, s, strlen (s)), "action parameter");
			FailErr( AEPutParamPtr(&ourEvent, kActionPathKeyword, typeChar, (stream->action)->path, strlen ((stream->action)->path)), "action path parameter");
		} else {
			ActionToString (stream, s, "CGI");
			FailErr( AEPutParamPtr(&ourEvent, kActionKeyword, typeChar, s, strlen (s)), "action parameter");
			FailErr( AEPutParamPtr(&ourEvent, kActionPathKeyword, typeChar, scriptName, strlen (scriptName)), "action path parameter"); //may need to be url_realname
		}
		
		
 		if (method==METHOD_POST)
			FailErr( AEPutParamPtr(&ourEvent, kPostKeyword, typeChar, 
					postArgs, stream->post_arg_byte_count /*strlen (postArgs)*/), "postArgs parameter");
		else
			FailErr( AEPutParamPtr(&ourEvent, kPostKeyword, typeChar, 
					"", 0), "postArgs parameter (0)");
		FailErr( AEPutParamPtr(&ourEvent, kMethodKeyword, typeChar, 
				methodTokens[method], strlen (methodTokens[method])), 
				"method parameter");

		//client IP
		HTTP_AddrToStr (stream->remoteHost, s);
		FailErr( AEPutParamPtr(&ourEvent, kClientIPAddress, typeChar, 
				s, strlen (s)), "client IP parameter");

		//full request
		FailErr( AEPutParamPtr(&ourEvent, kFullRequestKeyword, typeChar, 
				stream->request, stream->request_byte_count /*strlen (stream->request)*/), "request parameter");

		//connection ID
		FailErr( AEPutParamPtr(&ourEvent, kConnectionIDKeyword, typeLongInteger, 
				(Ptr) &(stream->id), (Size) sizeof (stream->id)), "connection ID parameter");
		
        FailErr(err=AESend(&ourEvent, &ourReply, kAECanInteract + kAEQueueReply + kAECanSwitchLayer, kAENormalPriority,
               (long) MAX_TIMEOUT,/*(IdleProcPtr)*/nil , nil), "Sending ACGI sdoc Event");
		
		FailErr( AEDisposeDesc( &theAddress ), "dispose address" ) ;
		FailErr( AEDisposeDesc( &ourEvent ), "dispose event" ) ;

		if (debugLevel) {
			sprintf (s, "AESend for process %hu", (unsigned short) (stream->id & 0x0000FFFF));
			TTY_WriteMessage(s, TRUE);
		}

		return err;
	}
}

