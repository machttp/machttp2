/*HTTP_Notification.c*/
/******************************************************
 *
 * Lawyer stuff:
 *
 * MacHTTP 2.x, source code
 * Copyright �1993-2001 Chuck Shotton
 * All Rights Reserved.
 *
 * This source code is made available under the terms of the MacHTTP Source License.
 * This license grants you the right to use the source code to create new versions
 * of and derivative works from the original MacHTTP source code. Under the terms of
 * this license, any modifications made to the source code must be made available in
 * source code form to the general public and the MacHTTP.Org organization. You may not
 * redistribute source code or binary versions of the MacHTTP application that make use of
 * the MacHTTP name, logo, or icons without the expressed written consent of MacHTTP.Org
 * or Chuck Shotton.
 *
 * MacHTTP is a trademark of Chuck Shotton. Permission is granted
 * to MacHTTP.Org and its assignees use the MacHTTP name, logo, and icons.
 * Any use not authorized by MacHTTP.Org or Chuck Shotton is prohibited.
 *
 * Additional information can be found at http://www.machttp.org/
 *
 ******************************************************
 * Modifications:
 *
 * 03/01/01 - cshotton - initial verison
 * 11/17/01 - rpatters1 - modernized and de-linted
 ******************************************************/
#include "config.h"
#include <Notification.h>

#include "HTTP_Notification.h"

static Handle sicn;
static NMRec nm;
static StringPtr nms = "\pMacHTTP needs your attention!";
short remove_notify = 0;

extern short inForeground; /*template.c*/

/**********************************************/

pascal void HTTP_NotifyProc (NMRecPtr PARM_UNUSED(nm))
{
	remove_notify = 1;
}

/**********************************************/

void HTTP_InitNotify()
{
	//sicn = GetResource ('SICN', 128);
	nm.qType = nmType;
	nm.nmMark = 0;//1;
	nm.nmIcon = NULL;//sicn;
	nm.nmSound = (Handle) -1;
	nm.nmResp = nil;//(UniversalProcPtr) 0;//NewNMProc (HTTP_NotifyProc);
	nm.nmRefCon = 0;
	nm.nmStr=nms;
}

/**********************************************/

void HTTP_Notify()
{
OSErr err;
	remove_notify = 0;
	if (!inForeground)
		err = NMInstall (&nm);
}

/**********************************************/

void HTTP_RemoveNotify()
{
OSErr err;
	remove_notify = 0;
	err = NMRemove (&nm);
}