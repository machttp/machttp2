/*HTTP_ParseRequest.c*/

#include "config.h"

#include <MacTypes.h>
#include <MacWindows.h>
#include <Threads.h>
#include <Files.h>
#include <Controls.h>

#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>

#include "MacTCPCommonTypes.h"
#include "TCPPB.h"
#include "TCPHi.h"
#include "http.h"
#include "ResolvePath.h"
#include "TTY_Messages.h"
#include "Template.h"
#include "HTTP_ParseRequest.h"

/********************************************/

void HTTP_ParseRequest (TCPStreamPtr stream)
{
}

