/******************************************************
 *
 * Lawyer stuff:
 *
 * MacHTTP 2.x, source code
 * Copyright �1993-2001 Chuck Shotton
 * All Rights Reserved.
 *
 * This source code is made available under the terms of the MacHTTP Source License.
 * This license grants you the right to use the source code to create new versions
 * of and derivative works from the original MacHTTP source code. Under the terms of
 * this license, any modifications made to the source code must be made available in
 * source code form to the general public and the MacHTTP.Org organization. You may not
 * redistribute source code or binary versions of the MacHTTP application that make use of
 * the MacHTTP name, logo, or icons without the expressed written consent of MacHTTP.Org
 * or Chuck Shotton.
 *
 * MacHTTP is a trademark of Chuck Shotton. Permission is granted
 * to MacHTTP.Org and its assignees use the MacHTTP name, logo, and icons.
 * Any use not authorized by MacHTTP.Org or Chuck Shotton is prohibited.
 *
 * Additional information can be found at http://www.machttp.org/
 *
 ******************************************************
 * Modifications:
 *
 * 03/01/01 - cshotton - initial verison
 * 11/18/01 - rpatters1 - modernized and de-linted
 ******************************************************/
#include "config.h"
#include <cstring>

#include <Traps.h>
#include <Aliases.h>
#include <Gestalt.h>
#include <MacMemory.h>

#include "PStrings.h"
#include "ResolvePath.h"

//dead code below here
#if 0
static OSErr PathGenerateC(FSSpec *Spec, char *PathName, long PathNamePyLen);


OSErr HTTP_ResolvePath(char *PathName, long PathNamePyLen, short makeFullPath, Boolean *WasAlias)
{
	static Boolean			Inited = FALSE;
	static Boolean			AliasMgrPresent = FALSE;
	OSErr					OSError;
	long					Response;
	Boolean					IsFolder;
	
	if (Inited == FALSE) {
		
		Inited = TRUE;
		
//		if (TrapAvailable(_Gestalt)) {
			
			if (Gestalt(gestaltAliasMgrAttr, &Response) == noErr) {
				
				if ((Response & (1 << gestaltAliasMgrPresent)) != 0)
					AliasMgrPresent = TRUE;
			}
//		}
	}
	
	OSError = noErr;
	
	if (AliasMgrPresent) {
		
	//	Because of the OS' dependence on Pascal strings, we can't
	//	path names containing more than 255 characters (the limit
	//	for Pascal strings).
		
		if (strlen(PathName) <= 255) {
			FSSpec					PSpec;
			
			CtoPstr(PathName);
			OSError = FSMakeFSSpec(0, 0, (StringPtr) PathName, &PSpec);
			PtoCstr((StringPtr) PathName);
			
			if (OSError == noErr) {
				
				ResolveAliasFile(&PSpec, TRUE, &IsFolder, WasAlias);
				if (*WasAlias || makeFullPath)
					OSError = PathGenerateC(&PSpec, PathName, PathNamePyLen);
			}
			
		} else {
			
		//	Path name is too long to be resolved; due to the Mac OS'
		//	dependence on pascal strings, paths containing more than
		//	255 characters can't be fed to the OS in order to begin
		//	the alias resolution and path name generation process, so
		//	we have to give-up.
			
			OSError = PathTooLongForPascalErr;
		}
	}
	
	return (OSError);
}



static OSErr PathGenerateC(FSSpec *Spec, char *PathName, long PathNamePyLen)
{
	OSErr					OSError;
	
	OSError = PathBufferTooSmallErr;
	
	if (PathNamePyLen > 0) {
		char					*Dest;
		CInfoPBRec				CInfo;
		
	//	Get a pointer to the end of the PathName buffer, and 
	//	put a zero there to terminate the string;
		
		Dest = PathName + PathNamePyLen;
		*--Dest = 0;
		
	//	Copy the file name to the end of the path name buffer.
		
		if (Dest - *Spec->name >= PathName) {
			short					Count;
			char					*Src;
			
			Count = *Spec->name;
			Src = (char *) Spec->name + 1 + Count;
			
			while (--Count >= 0)
				*--Dest = *--Src;
		}
		
	//	Setup our parameter block.
		
		CInfo.dirInfo.ioNamePtr = Spec->name;
		CInfo.dirInfo.ioVRefNum = Spec->vRefNum;
		CInfo.dirInfo.ioFDirIndex = -1;
		CInfo.dirInfo.ioDrDirID = Spec->parID;
		
		while (PBGetCatInfo(&CInfo, FALSE) == noErr) {
			
		//	If there's room in the path name buffer, prepend
		//	the latest directory name, replete with colon.
			
			if (Dest - (*Spec->name + 1) >= PathName) {
				short					Count;
				char					*Src;
				
				*--Dest = ':';
				
				Count = *Spec->name;
				Src = (char *) Spec->name + 1 + Count;
				
				while (--Count >= 0)
					*--Dest = *--Src;
				
			} else {
				
				CInfo.dirInfo.ioResult = PathBufferTooSmallErr;
				break;
			}
			
			CInfo.dirInfo.ioDrDirID = CInfo.dirInfo.ioDrParID;
		}
		
	//	Copy the result code from the loop above into the OSError
	//	variable so we can return that value when we complete.
		
		OSError = CInfo.dirInfo.ioResult;
		
	//	If we were successful in getting the names of all our
	//	parent directories, do the clean-up necessary to get a 
	//	proper path name. We know we were successful if we
	//	made it all the way up the directory tree to pseudo
	//	directory 1 (which conceptually is the parent of root (2),
	//	although it doesn't actually exist).
		
		if (CInfo.dirInfo.ioDrDirID == 1) {
			
			OSError = noErr;
			
		//	Move the accumulated path name from the end of the path name
		//	buffer to the beginning.
			
			BlockMove(Dest, PathName, PathNamePyLen - (Dest - PathName));
		}
		
	//	If anything went wrong above, return an empty string.
		
		if (OSError != noErr)
			*PathName = 0;
	}
	
	return (OSError);
}

#endif 
//end of dead code

//----------------------------------------------------------

static void PathNameFromDirID(long dirID, short vRefNum, StringPtr fullPathName);

static 	char 	tempPath [1024], tpath [1024];
static	char	spName [1024];

OSErr ResolvePathAlias (char* inpath, char* result, unsigned short resultSize, FSSpec *spec, Boolean *isFolder, Boolean *isAlias)
{
	OSErr	err = noErr;
	short 	vRefNum = 0;
	char	*name, *path;
	// moved to static globals
	//char 	tempPath [1024], tpath [1024];
	//char	spName [1024];
	short 	depth = 0;
	Boolean	tisFolder = false;
	Boolean tisAlias = false;
	
	if (isFolder)
		*isFolder = 0;
		
	if (isAlias)
		*isAlias = 0;
	
	if (!spec)
		return -1;
		
	//Take care of initial "::", but ignore initial ":"
	safecpy ((char *) tpath, inpath, sizeof (tpath));
	path = (char *) tpath;
	tempPath[0] = '\0';
	
	if (result)
		result[0] = '\0';
		
	while (path[0] == ':')
		path++;
	name = path;
		
	GetVol(0, &vRefNum);
	strtok(path, ":");
	while (name != NULL) { 
		c2pcpy((StringPtr) spName, name);
		pstrcat((StringPtr) tempPath, "\p:");
		pstrcat((StringPtr) tempPath, (StringPtr) spName);
        if ((err = FSMakeFSSpec(vRefNum, 0, (StringPtr) tempPath, spec)) != noErr)
        	return err;
        vRefNum = 0;
		err = ResolveAliasFile(spec, true, &tisFolder, &tisAlias);
		if (isFolder)
			*isFolder = tisFolder;
		if (isAlias)
			*isAlias = tisAlias;
		if (err) {
			return err;
		}
		PathNameFromDirID(spec->parID, spec->vRefNum, (StringPtr) tempPath);
		pstrcat((StringPtr) tempPath, spec->name);
		name = strtok(NULL, ":");
		if (depth++ > 24) {
//			TTY_WriteMessage (GetMsg (STR1Res, mEFileNameTooLong) /*"ERROR! File name in URL is too long!"*/, TRUE, HIGH_PRIORITY);
			break;
		}
	}
	
	if (result) {
		PtoCstr ((StringPtr) tempPath);
		safecpy (result, tempPath, resultSize);
	}
	
	return noErr;
}

/* Utilities from the Apple Q&A Stack showing how to get the full
 pathname of a file.  Note that this is NOT the recommended way
 to specify a file to Toolbox routines.  These routines should be
 used for displaying full pathnames only.
*/
void PathNameFromDirID(long dirID, short vRefNum, StringPtr fullPathName)
{
	CInfoPBRec	block;
	Str255		directoryName;
	OSErr		err;

	fullPathName[0] = '\0';
	block.dirInfo.ioDrParID = dirID;
	block.dirInfo.ioNamePtr = directoryName;
	block.dirInfo.ioVRefNum = vRefNum;
	block.dirInfo.ioFDirIndex = -1;
	do {
			directoryName[0]='\0';
			block.dirInfo.ioDrDirID = block.dirInfo.ioDrParID;
			if (!(err = PBGetCatInfo(&block, FALSE))) {
				pstrcat(directoryName, (StringPtr)"\p:");
				pstrinsert(fullPathName, directoryName);
			}
	} while (block.dirInfo.ioDrDirID != fsRtDirID && !err);
}



