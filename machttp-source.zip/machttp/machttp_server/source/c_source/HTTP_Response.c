/*HTTP_Response.c*/
/******************************************************
 *
 * Lawyer stuff:
 *
 * MacHTTP 2.x, source code
 * Copyright �1993-2001 Chuck Shotton
 * All Rights Reserved.
 *
 * This source code is made available under the terms of the MacHTTP Source License.
 * This license grants you the right to use the source code to create new versions
 * of and derivative works from the original MacHTTP source code. Under the terms of
 * this license, any modifications made to the source code must be made available in
 * source code form to the general public and the MacHTTP.Org organization. You may not
 * redistribute source code or binary versions of the MacHTTP application that make use of
 * the MacHTTP name, logo, or icons without the expressed written consent of MacHTTP.Org
 * or Chuck Shotton.
 *
 * MacHTTP is a trademark of Chuck Shotton. Permission is granted
 * to MacHTTP.Org and its assignees use the MacHTTP name, logo, and icons.
 * Any use not authorized by MacHTTP.Org or Chuck Shotton is prohibited.
 *
 * Additional information can be found at http://www.machttp.org/
 *
 ******************************************************
 * Modifications:
 *
 * 03/01/01 - cshotton - initial verison
 * 10/20/01 - rpatters1 - fixed initialization problem in HTTP_MakeDate()
 * 11/17/01 - rpatters1 - modernized and de-linted
 * 01/14/02 - instantware - changed HTTP_Respond() -> added handling of "Content-Range:" and "multipart/byteranges" responds
 ******************************************************/
#include "config.h"
#include <cstdio>
#include <cstring>

#include <MacTypes.h>
#include <MacMemory.h>
#include <MacWindows.h>
#include <Files.h>
#include <Controls.h>
#include <Dialogs.h>
#include <Fonts.h>
#include <Events.h>
#include <OSUtils.h>
#include <Script.h>
#include <ToolUtils.h>
#include <Threads.h>

#include "MacTCPCommonTypes.h"
#include "TCPPB.h"
#include "TCPHi.h"
#include "TTY_Messages.h"
#include "http.h"
#include "HTTP_Properties.h"
#include "HTTP_Response.h"

/************************************************/

static char rlocal_h_name[256];

/************************************************/

static char *monthNames[12] = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug",
			"Sep", "Oct", "Nov", "Dec"};
static char *dayNames[7] = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};
static char *shortDayNames[7] = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};

unsigned long gmtDelta = 0xF0000000;

void Response_InitDate ()
{
MachineLocation loc;

	/*get the GMT delta*/
	ReadLocation(&loc);
	gmtDelta = loc.u.gmtDelta & 0x00FFFFFF;
	if (BitTst(&gmtDelta, 23))												
		gmtDelta = gmtDelta | 0xFF000000;

}

void HTTP_MakeDate (unsigned long secs, char *s)
{
DateTimeRec dtrp;
//MachineLocation loc;
//long gmtD = 0;

	/*get the GMT delta*/
	if (gmtDelta == 0xF0000000)
		Response_InitDate ();

	SecondsToDate(secs-gmtDelta, &dtrp);
	sprintf (s, "%s, %02hd %s %04hd %02hd:%02hd:%02hd GMT", 
		shortDayNames [dtrp.dayOfWeek-1], dtrp.day, monthNames [dtrp.month-1],
		dtrp.year, dtrp.hour, dtrp.minute, dtrp.second);
//	sprintf (s, "%s, %02hd-%s-%02hd %02hd:%02hd:%02hd GMT", 
//		dayNames [dtrp.dayOfWeek-1], dtrp.day, monthNames [dtrp.month-1],
//		dtrp.year-1900, dtrp.hour, dtrp.minute, dtrp.second);
}

/************************************************/

char *HTTP_GetVirtualHostname (TCPStreamPtr stream) {
	if (strlen (stream->hdr_host_name))
		return stream->hdr_host_name;
	else
		return rlocal_h_name;
}

/************************************************/

void HTTP_Respond (TCPStreamPtr stream, short err_code, char *msg)
{
	OSErr	err;
	char	s[512], d[256], mime_header[1024];
	char	*resp_msg;

	if (stream->is_http10)
	{
		mime_header[0]='\0';
		
/*Build the HTTP response */

		switch (err_code) {
			case R_OK:
				resp_msg = "OK";
				break;
			case R_PARTIAL_CONTENT:
				resp_msg = "Partial Content";
				break;
			case R_NOT_MODIFIED:
				resp_msg = "Not Modified";
				break;
			case R_TOO_BUSY:
				resp_msg = "Server Too Busy";
				strcpy (stream->mime_type, "text/html");
				stream->content_size = strlen (msg);
				break;
			case R_NOT_FOUND:
				resp_msg = "File Not Found";
				if (strlen (msg)) {
					strcpy (stream->mime_type, "text/html");
					stream->content_size = strlen (msg);
				}
				break;
			case R_RANGE_UNSATISFIABLE:
				resp_msg = "Requested range not satisfiable";
				break;
			default:
				resp_msg = "Unknown";
				break;
		}
		sprintf (mime_header, "%s %hd %s%s", "HTTP/1.0", err_code, resp_msg, HTTP_RESP_CRLF);
		
/* Build MIME Header */
		strcat (mime_header, HTTP_RESP_MIMEVERS);
		strcat (mime_header, HTTP_RESP_CRLF);
		strcat (mime_header, HTTP_RESP_SERVER);
		strcat (mime_header, HTTP_RESP_CRLF);
		
		sprintf (s, "Message-ID: <%0lx.%lu@%s>%s", stream->creation_date, stream->id, rlocal_h_name, HTTP_RESP_CRLF);
		strcat (mime_header, s);
		
/*Until MacHTTP supports keep-alive, force clients to close connections so they don't hog too many streams.*/
		sprintf (s, "Connection: close%s", HTTP_RESP_CRLF);
		strcat (mime_header, s);
		
		if (err_code == R_OK || err_code == R_PARTIAL_CONTENT || err_code == R_NOT_MODIFIED)
		{
			if (stream->creation_date) {
				HTTP_MakeDate (stream->creation_date, d);
				sprintf (s, "Date: %s%s", d, HTTP_RESP_CRLF);
				strcat (mime_header, s);
			}
			
			if (stream->modification_date) {
				HTTP_MakeDate (stream->modification_date, d);
				sprintf (s, "Last-Modified: %s%s", d, HTTP_RESP_CRLF);
				strcat (mime_header, s);
			}
		}
		
		if (stream->fileType == FILE_BINARY)
			strcat(mime_header, "Accept-Ranges: bytes\r\n");
		
		if (!stream->content_range)
		{	// no ranges
			if (stream->content_size > 0)
			{
				if (err_code == R_RANGE_UNSATISFIABLE)
					sprintf(s, "Content-Range: bytes */%ld\r\n", stream->content_size);
				else
					sprintf(s, "Content-Length: %ld\r\n", stream->content_size);
				strcat(mime_header, s);
			}
			
			sprintf (s, "Content-Type: %s\r\n\r\n", stream->mime_type);
			strcat (mime_header, s);
		}
		
		else if (!stream->content_range->next)
		{	// singlepart byterange request
			sprintf(s, "Content-Range: bytes %ld-%ld/%ld\r\nContent-Length: %ld\r\nContent-Type: %s\r\n\r\n",
					stream->content_range->begin, stream->content_range->end, stream->content_size,
					stream->content_range->end - stream->content_range->begin + 1,
					stream->mime_type);
			strcat(mime_header, s);
		}

		else if (stream->content_range && stream->content_range->next)
		{	// multipart byteranges request
			sprintf (s, "Content-Length: %ld\r\nContent-Type: multipart/byteranges; boundary=%s\r\n\r\n", stream->content_length, stream->range_boundary);
			strcat (mime_header, s);
		}
		

		if (debugLevel) {
			TTY_WriteMessage(" ", TRUE);
			TTY_WriteMessage("### Sent MIME Header:", TRUE);
			TTY_WriteMessage(mime_header, TRUE);
		}
		err = SendData(stream->stream, mime_header, (unsigned short) strlen (mime_header),false);

		/*Now, send any HTML text passed in msg*/
		if (strlen (msg)) {
			strcpy (mime_header, HTTP_RESP_CRLF);
			strcat (mime_header, msg);
			err = SendData(stream->stream, mime_header, (unsigned short) strlen (mime_header),false);
		}
	}
}

/************************************************/

void HTTP_ErrorResponse (TCPStreamPtr stream, short err_code, char *msg)
{
OSErr err;
char s[256];
	if (stream->is_http10) {
		sprintf (s, "%s %hd %s%s", HTTP_VERSION, err_code, msg, HTTP_RESP_CRLF);
		if (debugLevel)
			TTY_WriteMessage (s, TRUE);
		err = SendData(stream->stream, s, (unsigned short) strlen (s),false);
	}
	else {
		err = SendData(stream->stream, msg, (unsigned short) strlen (msg),false);
	}
}

/************************************************/

void HTTP_RefusedResponse (TCPStreamPtr stream)
{
OSErr err;
char s[256];
	sprintf (s, "%s 403 Service Unavailable%s", HTTP_VERSION, HTTP_RESP_2CRLF);
	if (debugLevel) 
		TTY_WriteMessage (s, TRUE);
	err = SendData(stream->stream, s, (unsigned short) strlen (s),false);
	err = SendData(stream->stream, "Server is refusing connections now. Sorry.", (unsigned short) 42,false);
}

/************************************************/

void HTTP_AuthorizeResponse (TCPStreamPtr stream)
{
OSErr err;
char s[256];

	sprintf (s, "HTTP/1.0 401 Unauthorized%sServer: MacHTTP%sMIME-Version: 1.0%sWWW-Authenticate: Basic realm=\"%s\"%s",
			HTTP_RESP_CRLF, HTTP_RESP_CRLF, HTTP_RESP_CRLF, stream->whichRealm ? (stream->whichRealm)->realmName : "MacHTTP", HTTP_RESP_2CRLF);
			
	if (debugLevel) {
		TTY_WriteMessage (s, TRUE);
	}
	
	err = SendData(stream->stream, s, (unsigned short) strlen (s),false);
}

/************************************************/

void HTTP_RedirectResponse (TCPStreamPtr stream, char *path)
{
char s [URL_SIZE+HOST_NAME_SIZE+48];
OSErr err;
	sprintf (s, "HTTP/1.0 302 Found\r\nLocation: %s\r\n\r\n", path);	
	err = SendData (stream->stream, s, (unsigned short) strlen (s), false);
	stream->httpResponseCode = 302;
}

/************************************************/

void HTTP_DirRedirectResponse (TCPStreamPtr stream)
{
char url [URL_SIZE+HOST_NAME_SIZE+32];
char *serverName, *path;
unsigned short sLen, pLen;
short i;
	//see if there is a host field in the request. If so, use that value, otherwise defaults
	serverName = HTTP_GetVirtualHostname (stream);
	sLen = strlen (serverName);
	
	//now get the appropriate path
	path = stream->url_realname;
	pLen = strlen (stream->url_realname);
	
	if ((i=Get_IPPort()) != 80) //only return the port number if it's not 80
		sprintf (url, "http://%*.*s:%hu%*.*s/", (int) -sLen, (int) sLen, serverName, i, pLen, pLen, path);
	else
		sprintf (url, "http://%*.*s%*.*s/", (int) -sLen, (int) sLen, serverName, -pLen, pLen, path);

	HTTP_RedirectResponse (stream, url);
}

/************************************************/

void HTTP_ResponseInit()
{
	LogHostName (rlocal_h_name);
}