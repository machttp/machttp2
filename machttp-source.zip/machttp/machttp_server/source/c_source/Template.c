/******************************************************
 *
 * Lawyer stuff:
 *
 * MacHTTP 2.x, source code
 * Copyright �1993-2001 Chuck Shotton
 * All Rights Reserved.
 *
 * This source code is made available under the terms of the MacHTTP Source License.
 * This license grants you the right to use the source code to create new versions
 * of and derivative works from the original MacHTTP source code. Under the terms of
 * this license, any modifications made to the source code must be made available in
 * source code form to the general public and the MacHTTP.Org organization. You may not
 * redistribute source code or binary versions of the MacHTTP application that make use of
 * the MacHTTP name, logo, or icons without the expressed written consent of MacHTTP.Org
 * or Chuck Shotton.
 *
 * MacHTTP is a trademark of Chuck Shotton. Permission is granted
 * to MacHTTP.Org and its assignees use the MacHTTP name, logo, and icons.
 * Any use not authorized by MacHTTP.Org or Chuck Shotton is prohibited.
 *
 * Additional information can be found at http://www.machttp.org/
 *
 ******************************************************
 * Modifications:
 *
 * 03/01/01 - cshotton - initial verison
 * 11/18/01 - rpatters1 - modernized and de-linted
 * 11/24/01 - rpatters1 - display time of last hostfolder connection
 * 01/14/02 - instantware - new mainGiveTime() for better multitasking
 * 02/10/02 - instantware - sleep = 1 in foreground and 5 in background
 ******************************************************/
#include "config.h"
#include <cstdio>
#include <cstring>
#include <ctime>

#include <Gestalt.h>
#include <AppleEvents.h>
#include <MacTypes.h>
#include <MacMemory.h>
#include <MacWindows.h>
#include <Files.h>
#include <Controls.h>
#include <Dialogs.h>
#include <Menus.h>
#include <Fonts.h>
#include <Events.h>
#include <ToolUtils.h>
#include <Threads.h>
#include <Devices.h>
#include <Sound.h>

#include "CTemplateAEVT.h"
#include "MacTCPCommonTypes.h"
#include "TCPPB.h"
#include "http.h"
#include "Logic.h"
#include "TTY_Messages.h"
#include "PW_UI.h"
#include "HTTP_Threads.h"
#include "Prefs.h"
#include "HTTP_Notification.h"
#include "Template.h"

#include "globals.h"

#define THEWINID 128
#define DBGWINID 129

#define ERRALRT 129
#define CREATORID 129

#define KEYMASK 0xff
#define MENUCOUNT 4

#define DeskResID  128
#define FileResID  129
#define EditResID  130
#define OptionResID 131
#define Desk_ID 0
#define File_ID 1
#define File_ID_Display_Hostfolder_Stats 1

#if REMOTE_TCP_REPORT
#define File_ID_TCPReport 2
#define File_ID_Quit 4
#else
#define File_ID_Quit 3
#endif

#define Edit_ID 2
#define Option_ID 3

#define kINeedThisMuchMoreStackSpace 0x00010000

/*** Globals ***/

long gOSVersion;

#if NEEDS_QD_DEFINED
QDGlobals	qd;
#endif

/*** Local to Template.c ***/

static WindowPtr curWin,dbgWin;
static short theWinOpen=0;

static WindowPtr whichWindow;
static short stillGoAway;
static MenuHandle menuList[MENUCOUNT];    
static EventRecord theEvent;

static short runningMulti;

static FILE *f;

static short waitct;

static OSType ftype;

/***************************/

void Error(char *msg)
{
char mesg[255];
#if INTERACTIVE
	strcpy(mesg,msg);
	ParamText((StringPtr) mesg, nil, nil, nil);
	Alert(ERRALRT,0);
#endif
}

/*********************/

void CheckMulti()

#define WNETrapNum  0x60
#define UnImplTrapNum 0x9F
{
short i;
	if (NGetTrapAddress(WNETrapNum, ToolTrap) ==
	    NGetTrapAddress(UnImplTrapNum, ToolTrap)) {
		runningMulti = FALSE;
	}
	else {
		runningMulti = TRUE;
		for (i=0;i<3;i++)
			EventAvail(everyEvent, &theEvent);
	}
	inForeground = TRUE;
}

/***************************/

void Shutdown()
{
short i;
	for (i=0;i<3;i++)
		EventAvail(everyEvent, &theEvent);
	Prefs_Shutdown ();
	LogShutdown();
	if (theWinOpen)
		DisposeWindow(theWin);
}

/***********************************************************************************/
/********************** Mac User Interface stuff below this line *******************/
/***********************************************************************************/

/********* Initialization **********/
void Die()
{
	ExitToShell();
}


/***************************/
void WindowSetup()
{
Rect r;
char s[256];
Point pt;
#if INTERACTIVE

	sprintf (s, "MacHTTP %s Status", C_VERSION_STR);
	CtoPstr (s);
	
	theWin = GetNewWindow(128,NULL,(WindowPtr) -1);
		
	if (!theWin)
	  SysBeep(10);
	else {
		SetWTitle (theWin, (StringPtr) s);
		theWinOpen = 1;
		SetPort(theWin);
		r = theWinDefaultRect = theWin->portRect;
		SetPt (&pt, 0, 0);
		LocalToGlobal (&pt);
		OffsetRect (&theWinDefaultRect, pt.h, pt.v);
		
		//InsetRect(&r,5,5);
		r.top += STAT_AREA_HEIGHT;
		TTY_InitMessages(theWin,r,kFontIDMonaco,9,TRUE);
		TTY_WriteMessage(COPYRIGHT1, TRUE);
		TTY_WriteMessage(COPYRIGHT2, TRUE);
		TTY_WriteMessage(" ",TRUE);
	}
#else
	theWinOpen = 0;
#endif
}

/***************************/
void MenuSetup()
{
short i;
#if INTERACTIVE
		menuList[Desk_ID] = GetMenu(DeskResID); 
		AppendResMenu(menuList[Desk_ID], 'DRVR');
		menuList[File_ID] = GetMenu(FileResID);
		menuList[Edit_ID] = GetMenu(EditResID);
		menuList[Option_ID] = GetMenu(OptionResID);
		for (i=0;i<MENUCOUNT;i++)
			InsertMenu(menuList[i], 0);
		DrawMenuBar();
#endif
}

/***************************/

short CheckOS()
{
OSErr err;
char s[256];
long auxVersion;
	err = Gestalt(gestaltSystemVersion,&gOSVersion);
	if (err) {
		gOSVersion = 0;
		sprintf(s,"Error calling Gestalt %d",err);
		TTY_WriteMessage (s, TRUE);
		TTY_WriteMessage(" ", TRUE);
		return err;
	}
	running_AUX = FALSE;
	err = Gestalt(gestaltAUXVersion,&auxVersion);
	if (err) {
		if (err != gestaltUnknownErr) {
			sprintf(s,"Error calling Gestalt (A/UX) %d",err);
			TTY_WriteMessage (s, TRUE);
			TTY_WriteMessage(" ", TRUE);
			return err;
		}
	}
	else {
		if (auxVersion) running_AUX = TRUE;
	}
	err = Gestalt('cpnt',&gHasComponents);
	if (err) {
		gHasComponents = FALSE;
		if (err != gestaltUndefSelectorErr) {
			sprintf(s,"Error calling Gestalt (components) %d",err);
			TTY_WriteMessage (s, TRUE);
		}
		else {
			TTY_WriteMessage ("Warning: The Component Manager isn't installed. Scripting will be unavailable.", TRUE);
		}
	}
	return noErr;
}

/***************************/

void Initialize()
{
	SetApplLimit(GetApplLimit() - kINeedThisMuchMoreStackSpace);
	MaxApplZone();
	MoreMasters();
	MoreMasters();
	MoreMasters();
	MoreMasters();
	MoreMasters();
	MoreMasters();
	MoreMasters();
	MoreMasters();
	FlushEvents(everyEvent,0);
#if NEEDS_QD
	InitGraf(&qd.thePort);
#else
	InitGraf(&thePort);
#endif
#if INTERACTIVE
	InitFonts();
	InitWindows();
	InitMenus();
	TEInit();
	InitDialogs(/*(ProcPtr) Die*/nil);
	InitCursor();
#endif
    UI_Init();		/*set up the password dialog*/

	WindowSetup();
	MenuSetup();
	CheckMulti();

	if (CheckOS())
		done=1;
	else
		done=0;
		
	if (gOSVersion>=0x700) /*System 7 or better*/
		InitAppleEvents();
		
	if (LogInit()) { /*something was wrong...*/
		done = TRUE;
	}
	
	Prefs_Init();	/*load prefs from settings file*/
	if ( HTTP_GetHostFolderListHead() ) {
		EnableItem (menuList[File_ID], File_ID_Display_Hostfolder_Stats);
	}
}


/****** Event stuff follows *******/

void MDeskAbout()
{
short i;
	
#if INTERACTIVE
	ParamText ((StringPtr) VERSION_STR, nil, nil, nil);
	i=Alert(128,0);
	PurgeMem (maxMem);
#endif
}


/**********************************************/

void MFileQuit()
{
	done=1;
}

/**********************************************/

void MDisplayHostfolderStats()
{
HostFolderPtr hf;

	for (hf = HTTP_GetHostFolderListHead(); hf; hf = hf->next) {
		char s[512];
		char timeStr[100];
		char hostStr[80];
		short i;
		// pad hostname with spaces out to xx characters for a prettier display
		strncpy ( hostStr, hf->hostname, sizeof(hostStr)-2 );
		hostStr[sizeof(hostStr)-2] = '\0';	// piece o' the rock
		strcat ( hostStr, ":" );
		for ( i=strlen(hostStr); i<30; i++ )
			strcat ( hostStr, " " );
		sprintf ( s, "%s Connections: %ld", hostStr, hf->connections );
		// if we have connections, get the time
		if ( hf->connections > 0 ) {
			struct tm *date;
			date = localtime ( (time_t *) &hf->most_recent );
			strftime (timeStr, sizeof(timeStr), " Last Connection: %m/%d/%y\t%H:%M:%S ", date);
			// pad out to yy characters for a prettier display
			for ( i=strlen(s); i<50; i++ )
				strcat ( s, " " );
			strncat ( s, timeStr, sizeof(s)-1 );
			s[sizeof(s)-1] = '\0';	// piece o' the rock
		}
		TTY_WriteMessage (s, TRUE);
	}
}

/**********************************************/

void MHideWindow (Boolean hide)
{
	hideInBack = hide;
#if INTERACTIVE
	CheckItem (menuList[Option_ID], 3, hide);
#endif
}

/**********************************************/

void MVerboseMessages (Boolean markChar)
{
#if INTERACTIVE
	CheckItem (menuList[Option_ID], 1, markChar);
#endif
	LogDebug(markChar);
}

/**********************************************/

void MSuspendLogging (Boolean markChar)
{
	if ((short) HTTP_LoggingEnabled()) {
#if INTERACTIVE
		CheckItem (menuList[Option_ID], 2, markChar);
#endif
		if (markChar)
			HTTP_StopLogging();
		else
			HTTP_InitLogging();
	}
	else {
//		SysBeep(3);
//		TTY_WriteMessage(" ", TRUE);
//		TTY_WriteMessage("ERROR: Logging is not enabled. You must edit config file to turn logging on.", TRUE);
	}
}

/**********************************************/

void MRefuseConnections(Boolean refuse)
{
	LogRefuseConnections (refuse);
#if INTERACTIVE
	CheckItem (menuList[Option_ID], 4, refuse);
#endif
}

/**********************************************/

/*** Menu Dispatcher ***/

void MenuItem(short menuID, short itemNumber)
{
  Str255 daName;
  GrafPtr theCurrentPort;
  short markChar;

#if INTERACTIVE
  switch (menuID-1) {

    case Desk_ID:
    	switch (itemNumber) {
		case 1:
			MDeskAbout();
			break;
			
		case 2:
			break;
			
		default:
        	EnableItem(menuList[Edit_ID],0);
			GetMenuItemText(menuList[Desk_ID],itemNumber,daName);
			GetPort(&theCurrentPort);
			OpenDeskAcc(daName);
			SetPort(theCurrentPort);
			break;
		}
		break;

	case File_ID:
		switch (itemNumber) {
			case File_ID_Display_Hostfolder_Stats:
				MDisplayHostfolderStats();
				break;
				
#if REMOTE_TCP_REPORT
			case File_ID_TCPReport:
				LogTCPIPReport (NULL);
				break;
#endif

			case File_ID_Quit: 
	        	MFileQuit();
				break;
      }
      break;
      
    case Edit_ID:
    	if (itemNumber==3 || itemNumber==4)
    		TTY_Copy();
//      SystemEdit(itemNumber-1);
		if (itemNumber == 8) {
			if (pw_dlog) {
        		ShowWindow (pw_dlog);
        		SelectWindow (pw_dlog);
        	}
		}
      break;
      
	case Option_ID:
		switch (itemNumber) {
        	case 1:  /*Debugging*/
				GetItemMark (menuList[Option_ID], 1, &markChar);
				MVerboseMessages (!markChar);
				break;
			
			case 2: 
				GetItemMark (menuList[Option_ID], 2, &markChar);
				MSuspendLogging (!markChar);
		  		break;
	  		
			case 3: /*hide*/
				GetItemMark (menuList[Option_ID], itemNumber, &markChar);
				MHideWindow (!markChar);
		  		break;
	  		
	  		case 4: /*refuse*/
				GetItemMark (menuList[Option_ID], itemNumber, &markChar);
				MRefuseConnections(!markChar);
		  		break;
	  		
			default:
	  		break;
      	}
		break;
    
    default: 
      break;
  }/*case*/
  
#endif
}/**MenuItem**/

/*******************************************/
/***** Menu key front end *****/

void DoMenu(long menuResult)
{
short menuID, itemNumber;
short markChar;

	menuID = HiWord(menuResult);
	itemNumber = LoWord(menuResult);

	switch (menuID-1) {
		case Desk_ID:
		case Edit_ID:
			if (SendMENUToSelf (menuID, itemNumber)) {
				MenuItem(menuID,itemNumber);
			}
			break;
	
		case File_ID:
			switch (itemNumber) {
				case File_ID_Quit: 
					if (SendQuitToSelf()) {
						MenuItem(menuID,itemNumber);
					}
				  break;
				default:
					if (SendMENUToSelf (menuID, itemNumber)) {
						MenuItem(menuID,itemNumber);
					}
					break;
			}
			break;
	      
		case Option_ID:
			GetItemMark (menuList[Option_ID], itemNumber, &markChar);
			switch (itemNumber) {
	        	case 1:  /*verbose messages*/
			     	if (SendFlagToSelf (kMyAEVerbose, !markChar))
			     		MenuItem (menuID, itemNumber);
	        		break;
				case 2: /*disable logging*/
			     	if (SendFlagToSelf (kMyAESuspendLogging, !markChar)) 
			     		MenuItem (menuID, itemNumber);
	        		break;
				case 3: /*hide window*/
			     	if (SendFlagToSelf (kMyAEHideWindow, !markChar))
			     		MenuItem (menuID, itemNumber);
	        		break;
		  		case 4: /*refuse connections*/
			     	if (SendFlagToSelf (kMyAERefuseConnections, !markChar))
			     		MenuItem (menuID, itemNumber);
	        		break;
		  		
				default:
					break;
	     	}
			break;
	    
		default: 
	      	break;
  }/*case*/
  
  HiliteMenu(0);
}/*DoMenu*/


/**** Mouse event handler ****/
void DoMouseDown()
{
long vh;
Rect r, sbounds;
short windowCode, w, h;
#if INTERACTIVE
  windowCode = FindWindow(theEvent.where,&whichWindow);

  switch (windowCode) {
    case inMenuBar:
      DoMenu(MenuSelect(theEvent.where));
      break;

    case inSysWindow:
      SystemClick(&theEvent,whichWindow);
      break;
    
    case inDesk:
      break;
      
    case inContent:
      	SelectWindow(whichWindow);
		TTY_HandleScroll(&theEvent);
      	break;
      
    case inDrag:
#if NEEDS_QD
		DragWindow(whichWindow, theEvent.where, &(qd.screenBits.bounds));
#else
		DragWindow(whichWindow, theEvent.where, &(screenBits.bounds));
#endif	
      	break;
      
    case inGrow:
    	if (whichWindow == theWin) {
#if NEEDS_QD
    		sbounds = qd.screenBits.bounds;
#else
    		sbounds = screenBits.bounds;
#endif	
    		SetRect (&r, 503, STAT_AREA_HEIGHT+63, sbounds.right-sbounds.left, 
    					(sbounds.bottom-sbounds.top)-80);
    		vh = GrowWindow(theWin,theEvent.where, &r);
			SizeWindow(theWin, w=LoWord (vh), h=HiWord (vh), (Boolean) TRUE);
			TTY_Resize ();
			DrawOnlyGrowIcon (theWin);
			InvalRect(&theWin->portRect);
    	}
      	break;
      
    case inGoAway:
		if (TrackGoAway(whichWindow, theEvent.where)) {
    		if (whichWindow==theWin) 
				done = TRUE;
			else if (whichWindow == pw_dlog)
				HideWindow (pw_dlog);
		}
      	break;

    default: 
      break;
   }
#endif
}/*DoMouseDown*/


/***** Key event handler *****/
void DoKeyDown()
{
  short menuID, itemNumber;
  long menuResult;
  char globCh;

#if INTERACTIVE
  globCh = theEvent.message & KEYMASK;
  if (theEvent.modifiers & cmdKey) {
    menuResult=MenuKey(globCh);
    menuID = HiWord(menuResult);
    itemNumber = LoWord(menuResult);
    MenuItem(menuID,itemNumber);
    HiliteMenu(0);
  }/*if*/
#endif
}


/***********************************************/

void DrawOnlyGrowIcon(WindowPtr win)
{
Rect r;
RgnHandle saveClipRgn;

#if INTERACTIVE
	r = win->portRect;
	r.left = r.right-15;
	r.top = r.bottom-15;
	SetPort (win);
	saveClipRgn = NewRgn();			/* get an empty region */
	GetClip( saveClipRgn );			/* save current */
	ClipRect(&r);
	DrawGrowIcon (win);
	SetClip( saveClipRgn );			/* restore previous value */
	DisposeRgn( saveClipRgn );		/* not needed any more */
#endif
}

/***********************************************/

/**** Update event handler ****/
void DoUpdate()
{
  GrafPtr curPort;
  WindowPtr curWin;
  
#if INTERACTIVE
  curWin = (WindowPtr) theEvent.message;
    
  GetPort(&curPort);
  SetPort(curWin);
  BeginUpdate(curWin);
/**/
	if (curWin==theWin) {
		//EraseRect (&(theWin->portRect));
		TTY_RedrawMessages();
		LogRedraw();
		DrawOnlyGrowIcon(theWin);
	}
  EndUpdate(curWin);
  SetPort(curPort);
#endif
}


/**********************************/
void DoMulti(EventRecord *myEvent)
{
#define MouseMovedEvt 0xFA
Byte HiByte;
long bit0;
long MouseMove;

		bit0 = 31;
		MouseMove =  myEvent->message;
		HiByte = (Byte)((char *)(&MouseMove)[0]);
		if (HiByte == MouseMovedEvt) 
			;

		if (myEvent->message & 1) {
				inForeground = TRUE;
#if INTERACTIVE
				if (hideInBack) ShowWindow (theWin);
				InitCursor();
#endif
				if (remove_notify)
					HTTP_RemoveNotify();
		}
		else {
				inForeground = FALSE;
#if INTERACTIVE
				if (hideInBack) HideWindow (theWin);
#endif
		}
#if INTERACTIVE
		TTY_Activate ((short) inForeground);
		DrawOnlyGrowIcon(theWin);
#endif
}

/****** Event LOOP guts ******/
#define MultiFinderEvt 15

short CkEvents()
{
	long sleep;
	short doit;
	OSErr err;
	char s[80];

	LogIdle();

	TTY_Idle();

	if (inForeground)
		sleep = foregroundTicks;
	else
		sleep = backgroundTicks;

	if (runningMulti) {
		doit = WaitNextEvent(everyEvent, &theEvent, sleep, NULL);
	}
	else {
		SystemTask(); /*Let desk accs have some time*/
		doit = GetNextEvent(everyEvent, &theEvent); /*check for pending events*/
	}

	if (IsDialogEvent (&theEvent)) {
		PW_Run(&theEvent);
		return (theEvent.what);
	}
	else if (doit) {
	/*sprintf(s,"Event %d",theEvent.what);*/
	/*TTY_WriteMessage(s);*/
		switch (theEvent.what) {

			case kHighLevelEvent:
				err = AEProcessAppleEvent( &theEvent ) ;
				if (err!=noErr && err!=errAEEventNotHandled) {
					sprintf(s, "Error handling HighLevelEvent %d", err);
					TTY_WriteMessage(s, TRUE);
				}
				break;

			case mouseDown:
			  	DoMouseDown();
			  	break;
			
			case mouseUp:
			  	break;
			  
			case autoKey:
			case keyDown:
			  	DoKeyDown();
			  	break;
			 
			case keyUp:
			  	break;
			  
			case activateEvt:
				curWin = (WindowPtr) theEvent.message;
				TTY_Activate (TRUE);
				if (curWin==theWin)
					DrawOnlyGrowIcon(theWin);
				InitCursor();
			  	break;
			     
			case updateEvt:
			  	DoUpdate();
			  	break;
			  
			case diskEvt:
			  break;
			  
			case networkEvt:
			  break;
			  
			case driverEvt:
			  break;
			  
			case MultiFinderEvt: 
				DoMulti(&theEvent);
				break;

			case nullEvent:
			  	break;
			  
			default:
			  /*puts("Unhandled Event!!!");*/
			  break;
		    
	      }/*switch the...*/
		return (theEvent.what);
	}/*if getnext...*/
	else return (nullEvent);
}



Boolean mainGiveTime (short sleepTime);
Boolean mainGiveTime (short sleepTime)
{
	OSErr		err;
	EventRecord theEvent;
	char		s[80];
	
	if (sleepTime == 0) {
		if (inForeground)
			sleepTime = foregroundTicks;
		else
			sleepTime = backgroundTicks;
	}

	if (WaitNextEvent(everyEvent, &theEvent, sleepTime, nil))
	{
		switch (theEvent.what)
		{
			case kHighLevelEvent:
				err = AEProcessAppleEvent(&theEvent);
				if (err != noErr && err != errAEEventNotHandled)
				{
					sprintf(s, "Error handling HighLevelEvent %d", err);
					TTY_WriteMessage(s, TRUE);
				}
				break;

			case mouseDown:
				DoMouseDown();
				break;
			
			case mouseUp:
				break;
			
			case autoKey:
			case keyDown:
				DoKeyDown();
				break;
			
			case keyUp:
				break;
			
			case activateEvt:
				curWin = (WindowPtr) theEvent.message;
				TTY_Activate (TRUE);
				if (curWin==theWin)
					DrawOnlyGrowIcon(theWin);
				InitCursor();
				break;
			
			case updateEvt:
				DoUpdate();
				break;
			
			case diskEvt:
				break;
				
			case networkEvt:
				break;
				
			case driverEvt:
				break;
				
			case MultiFinderEvt: 
				DoMulti(&theEvent);
				break;

			case nullEvent:
				break;
			
			default:
				break;
		}
	}
	return true;
}


void main()
{
	Initialize();
	Unload_Seg(); /** Beta expiration check **/
	while (!done)
		CkEvents();
	Shutdown();
	ExitToShell();
}