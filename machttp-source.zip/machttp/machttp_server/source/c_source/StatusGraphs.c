/*StatusGraphs.c*/
/******************************************************
 *
 * Lawyer stuff:
 *
 * MacHTTP 2.x, source code
 * Copyright �1993-2001 Chuck Shotton
 * All Rights Reserved.
 *
 * This source code is made available under the terms of the MacHTTP Source License.
 * This license grants you the right to use the source code to create new versions
 * of and derivative works from the original MacHTTP source code. Under the terms of
 * this license, any modifications made to the source code must be made available in
 * source code form to the general public and the MacHTTP.Org organization. You may not
 * redistribute source code or binary versions of the MacHTTP application that make use of
 * the MacHTTP name, logo, or icons without the expressed written consent of MacHTTP.Org
 * or Chuck Shotton.
 *
 * MacHTTP is a trademark of Chuck Shotton. Permission is granted
 * to MacHTTP.Org and its assignees use the MacHTTP name, logo, and icons.
 * Any use not authorized by MacHTTP.Org or Chuck Shotton is prohibited.
 *
 * Additional information can be found at http://www.machttp.org/
 *
 ******************************************************
 * Modifications:
 *
 * 3/1/01 - cshotton - initial verison
 ******************************************************/

#include "config.h"

#include <MacTypes.h>
#include <MacMemory.h>
#include <MacWindows.h>

#include "StatusGraphs.h"

/******************************************************/

void InitLevelBar (LevelGraphPtr lev, WindowPtr theWin, Rect *r, long max, long scale)
{
#if INTERACTIVE
	lev->levelWin = theWin;
	lev->scale = scale;
	lev->levelBoundsR = lev->levelCurR = lev->levelHighR = *r;
	lev->levelStep = (lev->levelBoundsR.right-lev->levelBoundsR.left) / (max/scale);
	lev->levelMax = max/scale;
	if (lev->levelMax < 1) lev->levelMax = 1;
	lev->levelCur = lev->levelHigh = 0;
#endif
}

/******************************************************/

void DrawLevelBar (LevelGraphPtr lev)
{
#if INTERACTIVE
Rect r, b;
	if (lev == NULL)
		return;
	
	if (lev->levelWin == NULL)
		return;
		
	SetPort (lev->levelWin);
	r = b = lev->levelBoundsR;
	InsetRect (&b, -1, -1);
	lev->levelCurR.right = lev->levelHighR.left = lev->levelCur * lev->levelStep + lev->levelBoundsR.left;
	lev->levelHighR.right = r.left = lev->levelHigh * lev->levelStep + lev->levelBoundsR.left;
#if NEEDS_QD
	FillRect (&(lev->levelCurR), &(qd.black));
	FillRect (&(lev->levelHighR), &(qd.gray));
#else
	FillRect (&(lev->levelCurR), black);
	FillRect (&(lev->levelHighR), gray);
#endif
	//EraseRect (&r);
	FrameRect (&b);
#endif
}

/******************************************************/

void UpdateLevelBar (LevelGraphPtr lev, long cur)
{
#if INTERACTIVE
	cur = cur / lev->scale;
	if (cur<0) cur=0;
	if (cur>lev->levelMax) cur = lev->levelMax;
	lev->levelCur = cur;
	if (cur>lev->levelHigh)
		lev->levelHigh = cur;
#endif
}