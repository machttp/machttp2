#ifndef _TCPLOW_
#define _TCPLOW_
#define TCP_TIMEOUT 40 			/*ULP Timeout in seconds*/

typedef char CStr255[256];		/* like Str255, except for C-format strings. */

/* network initialization ------------------------------------------------------*/

OSErr InitNetwork();		/* opens the network driver */

OSErr ShutdownNetwork ();	//shutdown the network connections

/* connection stream creation/removal -------------------------------------------*/

OSErr CreateStream(				/* creates a stream needed to establish a connection*/
	unsigned long *stream,			/* stream identifier (returned)					*/
	unsigned long recvLen,			/* stream buffer length to be allocated			*/
	TCPNotifyProc notifPtr,
	long userData);
	
OSErr ReleaseStream(			/* disposes of an unused stream and its buffers		*/
	unsigned long stream);			/* stream identifier to dispose					*/


/* connection opening/closing calls ---------------------------------------------*/

OSErr OpenConnection(			/* attempts to establish a connection w/remote host */
	unsigned long stream,			/* stream id to be used for connection			*/
	long remoteHost,				/* network number of remote host				*/
	short remotePort,				/* network port of remote port					*/
	Byte timeout);					/* timeout value for connection					*/
	
OSErr WaitForConnection(		/* listens for a remote connection from a rem. port */
	unsigned long stream,			/* stream id to be used for connection			*/
	Byte timeout,					/* timeout value for open						*/
	short localPort,				/* local port to listen on						*/
	long *remoteHost,				/* remote host connected to (returned)			*/
	short *remotePort);				/* remote port connected to (returned)			*/

OSErr AsyncWaitForConnection(	/* same as above, except executed asynchronously	*/
	unsigned long stream,			/* stream id to be used for connection			*/
	Byte timeout,					/* timeout value for open						*/
	short localPort,				/* local port to listen on						*/
	long remoteHost,				/* remote host to listen for					*/
	short remotePort,				/* remote port to listen for					*/
	TCPiopb **returnBlock);			/* parameter block for call (returned)			*/

OSErr AsyncGetConnectionData(	/* retrieves connection data for above call			*/
	TCPiopb *returnBlock,			/* parameter block for asyncwait call			*/
	long *remoteHost,				/* remote host connected to (returned)			*/
	short *remotePort);				/* remote port connected to (returned)			*/

OSErr CloseStreamConnection(		/* closes an established connection					*/
	unsigned long stream);			/* stream id of stream used for connection		*/
	
OSErr AbortConnection(			/* aborts a connection non-gracefully				*/
	unsigned long stream);			/* stream id of stream used for connection		*/


/* data sending calls ----------------------------------------------------------*/

OSErr SendData(					/* sends data along an open connection				*/
	unsigned long stream,			/* stream used for connection					*/
	Ptr data,						/* pointer to data to send						*/
	unsigned short length,			/* length of data to send						*/
	Boolean retry);					/* if true, call continues until send successful*/
	
OSErr SendDataPush(				/* sends urgent data */
	unsigned long stream,
	Ptr data,
	unsigned short length,
	Boolean retry);
	
OSErr SendMultiData(			/* sends multiple strings of data on a connection	*/
	unsigned long stream,			/* stream used for connection					*/
	Str255 data[],					/* array of send strings						*/	
	short numData,					/* number of strings to send					*/
	Boolean retry);					/* if true, call continues until send successful*/

void SendDataAsync(				/* sends data asynchronously						*/
	unsigned long stream,			/* stream used for connection					*/
	Ptr data,						/* pointer to data to send						*/
	unsigned short length,			/* length of data to send						*/
	TCPiopb **returnBlock);			/* pointer to parameter block (returned)		*/
	
OSErr SendAsyncDone(			/* called when SendDataAsync call completes			*/
	TCPiopb *returnBlock);			/* parameter block to complete connection		*/


/* data receiving calls --------------------------------------------------------*/

OSErr RecvData(					/* waits for data to be received on a connection	*/
	unsigned long stream,			/* stream used for connection					*/ 
	Ptr data,						/* pointer to memory used to hold incoming data	*/
	unsigned short *length,			/* length to data received (returned)			*/
	Boolean retry,					/* if true, call continues until successful		*/
	byte timeout);
	
void RecvDataAsync(				/* receives data asynchronously						*/
	unsigned long stream,			/* stream used for connection					*/
	Ptr data,						/* pointer to memory used to hold incoming data	*/
	unsigned short length,			/* length of data requested						*/
	TCPiopb **returnBlock,			/* parameter block to complete connection		*/
	byte timeout);
	
OSErr GetDataLength(			/* called when RecvDataAsync completes				*/
	TCPiopb *returnBlock,			/* parameter block used for receive				*/
	unsigned short *length);		/* length of data received (returned)			*/

/* status calls --------------------------------------------------------*/

OSErr StreamStatus(					/* returns status of a connection	*/
	unsigned long stream,			/* stream used for connection					*/ 
	byte *status,					/* status of stream	*/
	unsigned short *pending);			/* amount of unread data */
	
/* DNS calls -------------------------------------------------------------*/

OSErr IPAddrToName (unsigned long addr, char *name);
OSErr IPNameToAddr (char *name, unsigned long *addr);
OSErr GetMyIPAddr (unsigned long *addr, unsigned long *mask);
OSErr GetMyIPAddrStr (char *addrStr);
OSErr GetMyIPName (char *name);




#endif