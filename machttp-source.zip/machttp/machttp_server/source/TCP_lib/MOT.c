//MOT.c

/******************************************************
 *
 * Lawyer stuff:
 *
 * MacHTTP 2.x, source code
 * Copyright �1993-2001 Chuck Shotton
 * All Rights Reserved.
 *
 * This source code is made available under the terms of the MacHTTP Source License.
 * This license grants you the right to use the source code to create new versions
 * of and derivative works from the original MacHTTP source code. Under the terms of
 * this license, any modifications made to the source code must be made available in
 * source code form to the general public and the MacHTTP.Org organization. You may not
 * redistribute source code or binary versions of the MacHTTP application that make use of
 * the MacHTTP name, logo, or icons without the expressed written consent of MacHTTP.Org
 * or Chuck Shotton.
 *
 * MacHTTP is a trademark of Chuck Shotton. Permission is granted
 * to MacHTTP.Org and its assignees use the MacHTTP name, logo, and icons.
 * Any use not authorized by MacHTTP.Org or Chuck Shotton is prohibited.
 *
 * Additional information can be found at http://www.machttp.org/
 *
 ******************************************************
 * Modifications:
 *
 * 01/11/02 - cshotton - initial verison
 ******************************************************/

#include "config.h"
#include <memory.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <Threads.h>
#include <Files.h>
#include <Gestalt.h>
#include "MOT.h"

static InetSvcRef gSvc = NULL;						//reference to the domain name resolver, etc.
static unsigned short MOTinitialized = false;		//has OT been initialized yet?

static OSErr MOTWaitForEvent (MOTStreamPtr stream, MOTState state, MOTState otherState, unsigned long secs);
static pascal void MOTServicesYieldingNotifier(void* contextPtr, OTEventCode code, OTResult result, void* cookie);
static pascal void MOTYieldingNotifier(void* contextPtr, OTEventCode code, OTResult result, void* cookie);
static OSErr MOTHandleLookErr (MOTStreamPtr ms);
static OSStatus MOTDoNegotiateIPReuseAddrOption(EndpointRef ep, Boolean enableReuseIPMode);

/*********************************************/

Boolean MOTHaveOT (void)
{
	static Boolean gotIt = false;
	static Boolean haveOT;
	MOTErr err = M_noErr;
	long result;
	
	if (!gotIt) {
		err = Gestalt(gestaltOpenTpt, &result);
		haveOT = err == M_noErr && 
			(result & gestaltOpenTptPresentMask) != 0 &&
			(result & gestaltOpenTptTCPPresentMask) != 0;
		gotIt = TRUE;
	}
return false; //uncomment to force MacTCP interfaces, comment to exercise new OT implementation
	return haveOT;
}


/*********************************************/

MOTErr MOTInit () {
	OSErr err = noErr;
	MOTErr merr = M_noErr;
	
	if (MOTinitialized)
		return noErr;
		
	err = InitOpenTransport ();
	if (err == noErr) {
		MOTinitialized = true;
		merr = MOTOpenDNSServices ();
		return M_noErr;
	}
	else
		return M_notInitialized;
}

/*********************************************/

MOTErr MOTShutdown () {
	MOTErr merr = M_noErr;
	
	if (MOTinitialized) {
		merr = MOTCloseDNSServices ();
		CloseOpenTransport ();
	}
	return M_noErr;
}

/*********************************************/

MOTErr MOTReset () {
	return M_noErr;
}

/*********************************************/


MOTErr MOTCreate (MOTStreamPtr *newStream) {
	MOTStreamPtr temp = NULL;
	
	if (newStream == NULL)
		return M_nullStreamPtr;
		
	if (!MOTinitialized)
		return M_notInitialized;
			
	temp = (MOTStreamPtr) NewPtr (sizeof (MOTStream));
	
	if (temp == NULL) {
		return M_memoryErr;
	}
	else {
		memset(temp, 0, sizeof(MOTStream));
		*newStream = temp;
	}
	
	return M_noErr;
}

/*********************************************/

MOTErr MOTOpen (MOTStreamPtr stream, unsigned long addr, unsigned short port, unsigned short timeoutSecs) {
	OSStatus err;
	MOTErr merr;
	char thost [270], tport [12];
	
	if (stream == NULL)
		return M_nullStreamPtr;
		
	if (!MOTinitialized)
		return M_notInitialized;
			
	if (stream->state != M_INACTIVE)
		return M_badStreamState;
		
	stream->ep = OTOpenEndpoint (OTCreateConfiguration(kTCPName), 0, NULL, &err);
	if (err == kOTLookErr)
		err = MOTHandleLookErr (stream);
	
	if (err == noErr) {
#if USING_CARBON_API
		err = OTInstallNotifier (stream->ep, NewOTNotifyUPP(MOTYieldingNotifier), stream);
#else
		err = OTInstallNotifier (stream->ep, MOTYieldingNotifier, stream);
#endif
		err = OTBind (stream->ep, NULL, NULL);
		if (err == kOTLookErr)
			err = MOTHandleLookErr (stream);

		if (err == noErr) {
			MOTAddrToString (addr, thost);
			sprintf (tport, ":%hu", port);
			strcat (thost, tport);
			
			stream->sndCall.addr.buf 	= (UInt8 *) &(stream->dnsAddr);
			stream->sndCall.addr.len 	= OTInitDNSAddress(&(stream->dnsAddr), (char *) thost);
			stream->sndCall.opt.buf 	= NULL;		// no connection options
			stream->sndCall.opt.len 	= 0;
			stream->sndCall.udata.buf 	= NULL;		// no connection data
			stream->sndCall.udata.len 	= 0;
			stream->sndCall.sequence 	= 0;		// ignored by OTConnect
			
			stream->state = M_OPENING;
			
			err = OTSetAsynchronous (stream->ep);	//open can take a while, so do it async and leave it async forever
			err = OTConnect(stream->ep, &(stream->sndCall), NULL);
			
			if (err != kOTNoDataErr) //anything but this is bad
				return M_openFailed;

			//wait here until the connection opens or the timeout happens
			merr = MOTWaitForEvent (stream, M_OPEN, M_DATA, timeoutSecs);
			
			return merr;
		}
		else
			return M_bindFailed;
	}
	else
		return M_openEndpointFailed;
	
	return M_noErr;
}

/*********************************************/


MOTErr MOTClose (MOTStreamPtr stream, unsigned short timeoutSecs) {
	OTResult err;
	MOTErr merr = M_noErr;
	
	if (stream == NULL)
		return M_nullStreamPtr;
		
	if (!MOTinitialized)
		return M_notInitialized;
		
	if (stream->state != M_CLOSED && stream->ep != kOTInvalidEndpointRef && !stream->needReset) {
//		stream->state = M_CLOSING;
		if (timeoutSecs == 0) {
			err = OTSndDisconnect(stream->ep, &(stream->sndCall));
		}
		else {
			err = OTSndOrderlyDisconnect(stream->ep);
		}
		
		merr = MOTWaitForEvent (stream, M_CLOSED, M_CLOSING, timeoutSecs);
		
		if (merr != M_noErr && timeoutSecs > 0) { //being nice failed, slam it shut
			err = OTSndDisconnect(stream->ep, &(stream->sndCall));
			merr = MOTWaitForEvent (stream, M_CLOSED, M_CLOSED, 2);
		}
	}
	
	stream->state = M_INACTIVE;
	
	if (stream->ep != kOTInvalidEndpointRef) {
		err = OTUnbind (stream->ep);
		err = OTCloseProvider (stream->ep);
		stream->ep = kOTInvalidEndpointRef;
	}
			
	return merr;
}

/*********************************************/


MOTErr MOTDelete (MOTStreamPtr *stream) {
	if (stream == NULL)
		return M_nullStreamPtr;
	
	if (!MOTinitialized)
		return M_notInitialized;
			
	if (*stream != NULL) {
		DisposePtr ((Ptr) *stream);
		*stream = NULL;
	}
		
	return M_noErr;
}

/*********************************************/


MOTErr MOTRead (MOTStreamPtr stream, char *buffer, unsigned long maxToRead, unsigned long *actualRead, unsigned short timeoutSecs) {
	OTFlags flags;
	OTResult err = 0;
	
	if (stream == NULL)
		return M_nullStreamPtr;
		
	if (!MOTinitialized)
		return M_notInitialized;
	
	*actualRead = 0;
	
	if (stream->state != M_OPEN && stream->state != M_DATA)
		return M_badStreamState;
		
	if (timeoutSecs > 0) {} //maybe this gets fixed. Maybe not.
		
	err = OTRcv (stream->ep, buffer, maxToRead, &flags);
	
	if (err == kOTLookErr) {
		while (err == kOTLookErr) {
			err = MOTHandleLookErr (stream);
		}
	}
	else if (err > 0) {
		*actualRead = err;
	}
	else
		return M_readFailed;
	
	return M_noErr;
}

/*********************************************/


MOTErr MOTWrite (MOTStreamPtr stream, char *buffer, size_t bufferLen, unsigned long *bytesSent, unsigned short timeoutSecs) {
	OTResult err;
	
	if (bytesSent == NULL)
		return M_nullParameter;
	else
		*bytesSent = 0;

	if (stream == NULL)
		return M_nullStreamPtr;
		
	if (!MOTinitialized)
		return M_notInitialized;
	
	stream->timer = TickCount () + (timeoutSecs * 60);
	
	err = OTSnd (stream->ep, buffer, bufferLen, 0);
	
	while (err == kOTFlowErr) {
		YieldToAnyThread ();
		if (timeoutSecs > 0 && TickCount () > stream->timer) {
			return M_timeout;
		}
		err = OTSnd (stream, buffer, bufferLen, 0);
	}
	
	if (err > 0)
		*bytesSent = err; //actual number of bytes sent is in err
	else
		return M_writeFailed;
		
	return M_noErr;
}

/*********************************************/


MOTErr MOTStatus (MOTStreamPtr stream, MOTState *state, unsigned long *bytesPending) {
	OTResult err = 0;
	OTByteCount pending = 0;
	
	if (stream == NULL)
		return M_nullStreamPtr;
		
	if (!MOTinitialized)
		return M_notInitialized;
	
	*state = stream->state;
	*bytesPending = pending;
	
	if (stream->state != M_CLOSED && stream->ep != kOTInvalidEndpointRef && !stream->needReset) {
		err = OTCountDataBytes (stream->ep, &pending);
		if (err != noErr) 
		{
			if (err == kOTLookErr)
				err = MOTHandleLookErr (stream);
			
			if (err == kOTNoDataErr || err == kOTOutStateErr || err == noErr) {
				pending = 0;
				if (stream->state == M_DATA)
					stream->state = M_OPEN;
			}
			else
				return M_statusFailed;
		}
	}
		
	if (stream->state == M_OPEN && pending > 0)
		stream->state = M_DATA;
	
	*state = stream->state;
	*bytesPending = pending;
	
	return M_noErr;
}

/*********************************************/


MOTErr MOTListen (MOTStreamPtr stream, unsigned short port, unsigned short queueDepth) {
	if (stream == NULL)
		return M_nullStreamPtr;
		
	if (!MOTinitialized)
		return M_notInitialized;
		
	if (port == 0)
		return M_badParameter;
		
	if (queueDepth <  1 || queueDepth > 100)
		return M_badParameter;
	
	//queue up an OT listen
	
	//start a listener thread to queue incoming requests that will be passed off via Accept
	return M_noErr;
}

/*********************************************/


MOTErr MOTAccept (MOTStreamPtr listeningStream, MOTStreamPtr stream) {
	if (stream == NULL || listeningStream == NULL)
		return M_nullStreamPtr;
		
	if (!MOTinitialized)
		return M_notInitialized;
			
	return M_noErr;
}

/*********************************************/


MOTErr MOTNameToAddr (char *name, unsigned long *addr) {
	InetHostInfo hinfo;
	
	OSErr err;
	MOTErr merr;
	
	if (name == NULL || addr == NULL)
		return M_nullParameter;
		
	if (!MOTinitialized) {
		*addr = 0;
		return M_notInitialized;
	}

	if (gSvc == NULL) {
		merr = MOTOpenDNSServices ();
		if (gSvc == NULL)
			return M_dnsSvcFailed;
	}
		
	*addr = 0;
	err = OTInetStringToAddress (gSvc, name, &hinfo);
	if (err == noErr) {
		*addr = hinfo.addrs [0];
	}
	else
		return M_unknownErr;

	return M_noErr;
}

/*********************************************/


MOTErr MOTAddrToName (unsigned long addr, char *name, unsigned short nameLen) {
	char host [512];
	OSStatus err = noErr;
	MOTErr merr = M_noErr;
	
	host [0] = '\0';

	if (name == NULL)
		return M_nullParameter;
		
	name [0] = '\0';
	
	if (nameLen < 1 || nameLen >511)
		return M_badParameter;
		
	if (!MOTinitialized) {
		return M_notInitialized;
	}

	if (gSvc == NULL) {
		merr = MOTOpenDNSServices ();
		if (gSvc == NULL)
			return M_dnsSvcFailed;
	}
		
	err = OTInetAddressToName (gSvc, (InetHost) addr, host);
	
	if (err != noErr) {
		OTInetHostToString ((InetHost) addr, host);// no dns entry, return the IP as a dotted string
	}
	
	strncpy (name, host, nameLen);
	
	return M_noErr;
}

/*********************************************/


MOTErr MOTLocalHostAddr (unsigned long *addr) {
	OSStatus			statusCode = kOTNoError;
	InetInterfaceInfo	inetInfo;

	if (addr == NULL)
		return M_nullParameter;
	
	*addr = 0;
		
	if (!MOTinitialized) {
		return M_notInitialized;
	}
	
	memset(&inetInfo, 0, sizeof(InetInterfaceInfo));
	statusCode = OTInetGetInterfaceInfo (&inetInfo, kDefaultInetInterface);

	*addr = inetInfo.fAddress;
	
	if (statusCode != noErr)
		return M_unknownErr;

	return M_noErr;
}

/*********************************************/


MOTErr MOTLocalHostName (char *name, unsigned short nameLen) {
	MOTErr err;
	unsigned long addr = 0;
	
	if (name == NULL)
		return M_nullParameter;
		
	name [0] = '\0';
		
	err = MOTLocalHostAddr (&addr);
	if (err == M_noErr) {
		err = MOTAddrToName (addr, name, nameLen);
		return err ;
	}
	else
		return err;
}

/*********************************************/

void MOTAddrToString (unsigned long addr, char *dottedIP) {
	char s[24];
	sprintf (s, "%u.%u.%u.%u", ((unsigned char *) &addr) [0], ((unsigned char *) &addr) [1], 
			((unsigned char *) &addr) [2], ((unsigned char *) &addr) [3]);
	strcpy (dottedIP, s);
}

/*********************************************/

MOTErr MOTOpenDNSServices () {
	OSStatus err = noErr;
	gSvc = OTOpenInternetServices (kDefaultInternetServicesPath, (unsigned long) NULL, &err);

    (void) OTSetSynchronous(gSvc);
    (void) OTInstallNotifier(gSvc, MOTServicesYieldingNotifier, nil); //NewOTNotifyUPP
    (void) OTUseSyncIdleEvents(gSvc, true);
    
    if (err)
    	return M_dnsSvcFailed;
    else
    	return M_noErr;
}

/*********************************************/

MOTErr MOTCloseDNSServices () {
	OSStatus err = 0;
	
	if (gSvc != NULL) {
		err = OTCloseProvider (gSvc);
		gSvc = NULL;
	}
	
	return err;
}

/*********************************************/

#pragma optimization_level 0 // switch off the optimizer for the notifiers

static pascal void MOTServicesYieldingNotifier(void* contextPtr, OTEventCode code, 
									   OTResult result, void* cookie)
	// This simple notifier checks for kOTSyncIdleEvent and
	// when it gets one calls the Thread Manager routine
	// YieldToAnyThread.  Open Transport sends kOTSyncIdleEvent
	// whenever it's waiting for something, eg data to arrive
	// inside a sync/blocking OTRcv call.  In such cases, we
	// yield the processor to some other thread that might
	// be doing useful work.
{
	#pragma unused(result)
	#pragma unused(cookie)
	OSStatus err;
	InetSvcRef svc = (InetSvcRef) contextPtr;
	
	switch (code) {
		case kOTSyncIdleEvent:
			err = YieldToAnyThread();
			break;
			
		case T_DATA:
			break;
			
		case kOTProviderWillClose:
		case kOTProviderIsClosed:
			break; //maybe null out gSvc here?

		default:
			break;
	}
}

/*********************************************/

static pascal void MOTYieldingNotifier(void* contextPtr, OTEventCode code, OTResult result, void* cookie)
	// This simple notifier checks for kOTSyncIdleEvent and
	// when it gets one calls the Thread Manager routine
	// YieldToAnyThread.  Open Transport sends kOTSyncIdleEvent
	// whenever it's waiting for something, eg data to arrive
	// inside a sync/blocking OTRcv call.  In such cases, we
	// yield the processor to some other thread that might
	// be doing useful work.
{
	#pragma unused(result)
	#pragma unused(cookie)
	OSStatus err;

	MOTStreamPtr stream = (MOTStreamPtr) contextPtr;

	switch (code) {
		case kOTSyncIdleEvent:
			err = YieldToAnyThread();
			break;
		
		case T_CONNECT:
			err = OTRcvConnect(stream->ep, NULL);
			if (err == kOTNoError)
				stream->state = M_OPEN;
			break;
			
		case T_DATA:
			stream->state = M_DATA;
			break;
			
		case T_DISCONNECT:
			err = OTRcvDisconnect (stream->ep, NULL);
			stream->state = M_CLOSED;
			break;
			
		case T_DISCONNECTCOMPLETE:
			stream->state = M_CLOSED;
			break;
			
		case T_ORDREL:
			err = OTRcvOrderlyDisconnect (stream->ep);
			if (err == noErr) {
				stream->state = M_CLOSING;
//				err = OTSndOrderlyDisconnect (stream->ep);
			}
			break;
			
		case kOTProviderWillClose:
		case kOTProviderIsClosed:
			err = OTCloseProvider (stream->ep);
			stream->needReset = true;
			stream->ep = kOTInvalidEndpointRef;
			break;

		default:
			break;
	}
}

#pragma optimization_level reset // reset the optimizer

/*********************************************/

static OSErr MOTWaitForEvent (MOTStreamPtr stream, MOTState state, MOTState otherState, unsigned long secs) {

	stream->timer = TickCount () + (secs * 60);
	while (stream->state != state && stream->state != otherState) {
		if (secs && (TickCount () > stream->timer))
			return M_timeout;
		YieldToAnyThread ();
	}
	
	return M_noErr;
}

/*********************************************/

static OSErr MOTHandleLookErr (MOTStreamPtr ms) {

	OTResult lookResult;
	OSStatus err;
	
	lookResult = OTLook (ms->ep);
	
	switch (lookResult) {

		case T_DISCONNECT:
			err = OTRcvDisconnect(ms->ep, nil);
			ms->state = M_CLOSED;
			break;
			
		case T_ORDREL:
			// If we get a T_ORDREL event, the remote peer
			// has disconnected the stream in an orderly
			// fashion.  This orderly disconnect indicates that
			// the end of the data.  We respond by clearing
			// the T_ORDREL, and then calling OTSndOrderlyDisconnect
			// to acknowledge the orderly disconnect at
			// the remote peer.
			
			err = OTRcvOrderlyDisconnect(ms->ep);
			if (err == noErr) {
				ms->state = M_CLOSING;
				OTSndOrderlyDisconnect (ms->ep);
			}
			break;
		
		case T_LISTEN:
			ms->state = M_OPENING;
			break;
			
		default:
			// Leave err as kOTLookErr.
			err = kOTLookErr;
			break;
	}
	
	return err;
}

/*********************************************/

static OSStatus MOTDoNegotiateIPReuseAddrOption(EndpointRef ep, Boolean enableReuseIPMode)

{
	UInt8		buf[kOTFourByteOptionSize];	// define buffer for fourByte Option size
	TOption*	opt;						// option ptr to make items easier to access
	TOptMgmt	req;
	TOptMgmt	ret;
	OSStatus	err;
	
	if (!OTIsSynchronous(ep))
	{
		return (-1);
	}
	opt = (TOption*)buf;					// set option ptr to buffer
	req.opt.buf	= buf;
	req.opt.len	= sizeof(buf);
	req.flags	= T_NEGOTIATE;				// negotiate for option

	ret.opt.buf = buf;
	ret.opt.maxlen = kOTFourByteOptionSize;

	opt->level	= INET_IP;					// dealing with an IP Level function
	opt->name	= IP_REUSEADDR;
	opt->len	= kOTFourByteOptionSize;
	opt->status = 0;
	*(UInt32*)opt->value = enableReuseIPMode;		// set the desired option level, true or false

	err = OTOptionManagement(ep, &req, &ret);
	
		// if no error then return the option status value
	if (err == kOTNoError)
	{
		if (opt->status != T_SUCCESS)
			err = opt->status;
		else
			err = kOTNoError;
	}
				
	return err;
}

