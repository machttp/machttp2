//MOT.h

/******************************************************
 *
 * Lawyer stuff:
 *
 * MacHTTP 2.x, source code
 * Copyright �1993-2001 Chuck Shotton
 * All Rights Reserved.
 *
 * This source code is made available under the terms of the MacHTTP Source License.
 * This license grants you the right to use the source code to create new versions
 * of and derivative works from the original MacHTTP source code. Under the terms of
 * this license, any modifications made to the source code must be made available in
 * source code form to the general public and the MacHTTP.Org organization. You may not
 * redistribute source code or binary versions of the MacHTTP application that make use of
 * the MacHTTP name, logo, or icons without the expressed written consent of MacHTTP.Org
 * or Chuck Shotton.
 *
 * MacHTTP is a trademark of Chuck Shotton. Permission is granted
 * to MacHTTP.Org and its assignees use the MacHTTP name, logo, and icons.
 * Any use not authorized by MacHTTP.Org or Chuck Shotton is prohibited.
 *
 * Additional information can be found at http://www.machttp.org/
 *
 ******************************************************
 * Modifications:
 *
 * 01/11/02 - cshotton - initial verison
 ******************************************************/

#ifndef MOT_h
#define MOT_h 1

#include <OpenTransport.h>
#include <OpenTptInternet.h>

typedef enum {	M_noErr				= 0, 
				M_notInitialized	= 1000,		//OT hasn't been opened yet
				M_nullStreamPtr		= 1001,		//a null pointer was passed for a stream argument
				M_nullParameter		= 1002,		//a null pointer was passed for an output parameter
				M_badParameter		= 1003,		//an invalid value was passed in a parameter
				M_badStreamState	= 1004,		//endpoint is in the wrong state for attempted operation
				M_dnsSvcFailed		= 1100,		//the OT DNS services failed to load
				M_openFailed		= 1101,		//OT was unable to open the connection
				M_bindFailed		= 1102,		//OT was unable to bind the socket
				M_openEndpointFailed= 1103,		//OT was unable to open the endpoint
				M_writeFailed		= 1104,		//flow control or another problem prevented the write from succeeding
				M_readFailed		= 1105,		//read failed for some reason
				M_statusFailed		= 1106,		//status check failed
				M_memoryErr			= 1900,		//generally signals out of memory
				M_timeout			= 1901,		//something didn't happen in time
				M_unknownErr		= 1999
		} MOTErr;

typedef enum {M_INACTIVE, M_CLOSED, M_CLOSING, M_OPEN, M_OPENING, M_DATA, M_LISTENING, M_RESET} MOTState;
	/* 	M_INACTIVE 	- this is a newly created stream or one that has been deleted
		M_CLOSED	- stream has been closed on both ends but not deleted
		M_CLOSING	- either the local or remote end has requested a CLOSE, but the other end hasn't responded
		M_OPEN		- connection is active, but idle with no pending data to receive
		M_OPENING	- this listening stream has a connection ready to be accepted
		M_DATA		- the connection is open and unread data is present
		M_LISTENING - this stream is listening for incoming connections
		M_RESET		- the endpoint has been reset (settings change?)
	*/

typedef struct mstream {
	MOTState 		state;			//what state is the stream in?
	unsigned short	listener;		//boolean - is this a listening stream?
	unsigned short	needReset;		//boolean - does the stream need to be reset/reopened because OT config changed?
	unsigned short	queueDepth;		//listens only - how deep is the current queue of pending connections?
	unsigned short	maxQueueDepth;	//how deep can the queue be? also used for OT backlog value
	unsigned long	timer;			//TickCount in the future at which the timeout occurs
	EndpointRef 	ep;
	TCall			sndCall;
	TBind			bindReq;	//for listens only
	DNSAddress 		dnsAddr;
	InetAddress 	remoteAddr;
	struct mstream	*next;			//list of queued connections (listens only)
} MOTStream, *MOTStreamPtr;


Boolean MOTHaveOT (void);			//Gestalt check to see if the proper OpenTransport version exists

MOTErr MOTInit (void);				//call once on start-up to initialized OpenTransport

MOTErr MOTShutdown (void);			//call once on shutdown to close OpenTransport

MOTErr MOTReset (void);				//called when OT experiences a reset (e.g. settings change, etc.)

MOTErr MOTCreate (MOTStreamPtr *newStream);	//create a new stream object

MOTErr MOTOpen (MOTStreamPtr stream, unsigned long addr, unsigned short port, unsigned short timeoutSecs); //open a client connection

MOTErr MOTClose (MOTStreamPtr stream, unsigned short timeoutSecs);	//close an open or listening stream

MOTErr MOTDelete (MOTStreamPtr *stream);							//delete data structures allocated by MOTCreate

MOTErr MOTRead (MOTStreamPtr stream, char *buffer, unsigned long maxToRead, unsigned long *actualRead, unsigned short timeoutSecs);	//read data from an open stream

MOTErr MOTWrite (MOTStreamPtr stream, char *buffer, size_t bufferLen, unsigned long *bytesSent, unsigned short timeoutSecs);	//write data to an open stream

MOTErr MOTStatus (MOTStreamPtr stream, MOTState *state, unsigned long *bytesPending);	//get the status of an open or listening stream

MOTErr MOTListen (MOTStreamPtr stream, unsigned short port, unsigned short queueDepth);		//listen for incoming connections on a specific port

MOTErr MOTAccept (MOTStreamPtr listeningStream, MOTStreamPtr stream);	//accept a new connection from a listening stream

MOTErr MOTOpenDNSServices (void);									//open DNS services

MOTErr MOTCloseDNSServices (void);									//close DNS services

MOTErr MOTNameToAddr (char *name, unsigned long *addr);				//convert a C string name to a numeric address

MOTErr MOTAddrToName (unsigned long addr, char *name, unsigned short nameLen);	//convert numeric address to C string name

MOTErr MOTLocalHostAddr (unsigned long *addr);						//return the numeric address of the local host

MOTErr MOTLocalHostName (char *name, unsigned short nameLen);		//return the name of the local host

void   MOTAddrToString (unsigned long addr, char *dottedIP);		//return the numeric address as a dotted string

#endif