/******************************************************
 *
 * Lawyer stuff:
 *
 * MacHTTP 2.x, source code
 * Copyright �1993-2001 Chuck Shotton
 * All Rights Reserved.
 *
 * This source code is made available under the terms of the MacHTTP Source License.
 * This license grants you the right to use the source code to create new versions
 * of and derivative works from the original MacHTTP source code. Under the terms of
 * this license, any modifications made to the source code must be made available in
 * source code form to the general public and the MacHTTP.Org organization. You may not
 * redistribute source code or binary versions of the MacHTTP application that make use of
 * the MacHTTP name, logo, or icons without the expressed written consent of MacHTTP.Org
 * or Chuck Shotton.
 *
 * MacHTTP is a trademark of Chuck Shotton. Permission is granted
 * to MacHTTP.Org and its assignees use the MacHTTP name, logo, and icons.
 * Any use not authorized by MacHTTP.Org or Chuck Shotton is prohibited.
 *
 * Additional information can be found at http://www.machttp.org/
 *
 ******************************************************
 * Modifications:
 *
 * 03/01/01 - cshotton - initial verison
 * 10/28/01 - rpatters1 - removed hard-coded "unknown" string in IPAddrToName()
 * 11/18/01 - rpatters1 - modernized and de-linted
 ******************************************************/
#include "config.h"
#include <cstring>

#include <MacTypes.h>
#include <MacMemory.h>
#include <Resources.h>
#include <Devices.h>
#include <Gestalt.h>

#include "MacTCPCommonTypes.h"
#include "AddressXlation.h"
#include "GetMyIPAddr.h"
#include "TCPPB.h"
#include "TCPRoutines.h"
#include "TCPHi.h"
#include "MOT.h"

static Boolean	gUseOT = FALSE;		//should OpenTransport be used?

Boolean GiveTime(short sleepTime);


/*********************************************/
/* InitNetwork opens the network driver
*/

OSErr InitNetwork()
{
	OSErr err;
	
	gUseOT = MOTHaveOT ();

	if (gUseOT) {
		 err = MOTInit (); 
		return err;
	}
	else {
		return OpenTCPDriver();
	}
}


/*********************************************/

OSErr ShutdownNetwork () {

	if (gUseOT) {
		return MOTShutdown ();
	}
	else {
		return noErr;
	}
}

/*********************************************/

/* CreateStream() creates an unconnected network stream to be
   used later by OpenConnection.  The length of the receive
   buffer must be specified in the call */
   
OSErr CreateStream(unsigned long *stream,unsigned long recvLen,TCPNotifyProc notifPtr, long userData)
{
	Ptr recvPtr;
	OSErr err;
	
	if (gUseOT) {
		return -1;
	}
	else {
		recvPtr = NewPtr(recvLen);
		err = MemError();
		if (err==noErr)
			err = LowTCPCreateStream(stream,recvPtr,recvLen, notifPtr, userData);
		return err;
	}
}


/*********************************************/

/* OpenConnection() initiates a connection to a remote machine,
   given that machine's network number and connection port.  A timeout
   value for the call must be given, and the stream identifier is returned. */

OSErr OpenConnection(unsigned long stream,long remoteHost,short remotePort,Byte timeout)
{
	ip_addr localHost;
	tcp_port localPort = 0;
	
	if (gUseOT) {
		return -1;
	}
	else {
		return LowTCPOpenConnection(stream,timeout,remoteHost,remotePort,&localHost,
									&localPort);
	}
}


/*********************************************/

/* WaitForConnection() listens for a connection on a particular port from a
	particular host.  It returns when a connection has been established */

OSErr WaitForConnection(unsigned long stream,Byte timeout,short localPort,
						long *remoteHost,short *remotePort)
{
	ip_addr localHost;
	
	if (gUseOT) {
		return -1;
	}
	else {
		return LowTCPWaitForConnection(stream,timeout,(ip_addr *)remoteHost,
					(tcp_port *)remotePort,&localHost,(tcp_port *)&localPort,false,nil);
	}
}


/*********************************************/

/* AsyncWaitForConnection() listens for a connection on a particular port from a
	particular host.  It is executed asynchronously and returns immediately */

OSErr AsyncWaitForConnection(unsigned long stream,Byte timeout,short localPort,
				long remoteHost,short remotePort,TCPiopb **returnBlock)
{
	ip_addr localHost;
	
	if (gUseOT) {
		return -1;
	}
	else {
		return LowTCPWaitForConnection(stream,timeout,(ip_addr *)&remoteHost,
					(tcp_port *)&remotePort,&localHost,(tcp_port *)&localPort,true,returnBlock);
	}
}


/*********************************************/

/* AsyncGetConnectionData() should be called when a call to AsyncWaitForConnection
	completes (when returnBlock->ioResult <= 0).  This call retrieves the information
	about this new connection and disposes the parameter block. */
	
OSErr AsyncGetConnectionData(TCPiopb *returnBlock,long *remoteHost,short *remotePort)
{
	ip_addr localHost;
	tcp_port localPort;
	
	if (gUseOT) {
		return -1;
	}
	else {
		return LowFinishTCPWaitForConn(returnBlock,(ip_addr *)remoteHost,
							(tcp_port *)remotePort,&localHost,&localPort);
	}
}


/*********************************************/

/* CloseStreamConnection() terminates a connection to a remote host, given the
   stream identifier of the connection */
   
OSErr CloseStreamConnection(unsigned long stream)
{
	if (gUseOT) {
		return -1;
	}
	else {
		return LowTCPClose(stream,10);
	}
}


/*********************************************/

/* AbortConnection() aborts a connection to a remote host, given the
   stream identifier of the connection */
   
OSErr AbortConnection(unsigned long stream)
{
	if (gUseOT) {
		return -1;
	}
	else {
		return LowTCPAbort(stream);
	}
}
	

/*********************************************/

/* ReleaseStream() frees the allocated buffer space for a given connection
   stream.  This call should be made after CloseStreamConnection. */
   
OSErr ReleaseStream(unsigned long stream)
{
	OSErr err;
	Ptr recvPtr;
	unsigned long recvLen;
	
	if (gUseOT) {
		return -1;
	}
	else {
		if ((err = LowTCPRelease(stream,&recvPtr,&recvLen)) == noErr)
				DisposePtr(recvPtr);
		
		return err;
	}
}


/*********************************************/

/* SendData() sends data along a connection stream to a remote host. */

OSErr SendData(unsigned long stream,Ptr data,unsigned short length,Boolean retry)
{	
	OSErr err;
	struct wdsEntry myWDS[2];	/* global write data structure */

	if (gUseOT) {
		return -1;
	}
	else {
		myWDS[0].length = length;
		myWDS[0].ptr = data;
		myWDS[1].length = 0;
		myWDS[1].ptr = nil;
		do
			err = LowTCPSendData(stream,TCP_TIMEOUT,FALSE, FALSE,(Ptr) myWDS,false,nil);
		while (retry && err==commandTimeout);
		return err;
	}
}

/*********************************************/

/* SendData() sends data along a connection stream to a remote host. */

OSErr SendDataPush(unsigned long stream,Ptr data,unsigned short length,Boolean retry)
{	
	OSErr err;
	struct wdsEntry myWDS[2];	/* global write data structure */

	if (gUseOT) {
		return -1;
	}
	else {
		myWDS[0].length = length;
		myWDS[0].ptr = data;
		myWDS[1].length = 0;
		myWDS[1].ptr = nil;
		do
			err = LowTCPSendData(stream,TCP_TIMEOUT,TRUE,TRUE,(Ptr) myWDS,false,nil);
		while (retry && err==commandTimeout);
		return err;
	}
}

/*********************************************/

/* SendMultiData() is similar to SendData, but takes an array of strings to send
   to the remote host. */

OSErr SendMultiData(unsigned long stream,Str255 data[],short numData,Boolean retry)
{
	struct wdsEntry *theWDS;
	short i;
	OSErr err;
	
	if (gUseOT) {
		return -1;
	}
	else {
		theWDS = (wdsEntry *)NewPtr((numData+1) * sizeof(wdsEntry));
		if (MemError())
			return MemError();	
		theWDS[numData].length = 0;
		theWDS[numData].ptr = nil;
		for (i=0; i<numData; i++) {
			theWDS[i].ptr = (Ptr) data[i];
			theWDS[i].length = strlen((char *)data[i]);
		}
		do
			err = LowTCPSendData(stream,20,false,false,(Ptr) theWDS,false,nil);
		while (retry && err==commandTimeout);
		DisposePtr((Ptr)theWDS);
		return err;
	}
}


/*********************************************/

/* SendDataAsync() sends data to a remote host asynchronously.  The ioResult
   parameter block variable should be checked, and SendDataDone() called when
   this flag is zero or negative */

void SendDataAsync(unsigned long stream, Ptr data,unsigned short length,TCPiopb **returnBlock)
{	
	struct wdsEntry *theWDS;

	if (gUseOT) {
		return;
	}
	else {
		theWDS = (wdsEntry *)NewPtr( (2*sizeof(wdsEntry)) );
		theWDS[0].length = length;
		theWDS[0].ptr = data;
		theWDS[1].length = 0;
		theWDS[1].ptr = 0;
		LowTCPSendData(stream,20,false,false,(Ptr) theWDS,true,returnBlock);
	}
}


/*********************************************/

/* SendDataDone() should be called in response to the completion of a SendDataAsync
   call.  It returns any error which occurred in the send. */

OSErr SendAsyncDone(TCPiopb *returnBlock)
{
	if (gUseOT) {
		return -1;
	}
	else {
		DisposePtr((Ptr)returnBlock->csParam.send.wdsPtr);
		return LowFinishTCPSend(returnBlock);
	}
}


/*********************************************/

/* RecvData() waits for data to be received on a connection stream.  When data
   arrives, it is copied into the data buffer and the call terminates. */

OSErr RecvData(unsigned long stream,Ptr data,unsigned short *length,Boolean retry, byte timeout)
{
	Boolean	urgent,mark;
	OSErr	err;
	unsigned short recvLength;

	if (gUseOT) {
		return -1;
	}
	else {
		do {
			recvLength = *length;
			err = LowTCPRecvData(stream,timeout,&urgent,&mark,data,&recvLength,false,nil);
		}
		while (retry && err==commandTimeout);
		*length = recvLength;
		if (err == noErr) {
			*(data+*length) = '\0';
		}
		return err;
	}
}


/*********************************************/

/* RecvDataAsync() is identical to RecvData above, but in this case, the call is
   made asynchronously. */

void RecvDataAsync(unsigned long stream,Ptr data,unsigned short length,TCPiopb **returnBlock, byte timeout)
{
	Boolean urgent,mark;
	
	if (gUseOT) {
		return;
	}
	else {
		LowTCPRecvData(stream,timeout,&urgent,&mark,data,&length,true,returnBlock);
	}
}


/*********************************************/

/* GetDataLength() should be called in response to the completion of the
   RecvDataAsync call. */

OSErr GetDataLength(TCPiopb *returnBlock,unsigned short *length)
{
	Boolean urgent,mark;
	
	if (gUseOT) {
		return -1;
	}
	else {
		return LowFinishTCPRecv(returnBlock,&urgent,&mark,length);
	}
}

/*********************************************/

/* StreamStatus returns the status of a given tcp stream*/

OSErr StreamStatus(					/* returns status of a connection	*/
	unsigned long stream,			/* stream used for connection		*/ 
	Byte *status,					/* status of stream	*/
	unsigned short *pending)			/* unread data*/
{
	OSErr err;
	TCPiopb *pBlock;
	
	if (gUseOT) {
		return -1;
	}
	else {
		if ((err = NewBlock(&pBlock)) != noErr)
			return err;
		
		pBlock->csCode = TCPStatus;
		pBlock->ioResult = 1;
		pBlock->tcpStream = stream;
		PBControl((ParmBlkPtr)pBlock,true);
		while (pBlock->ioResult > 0 && GiveTime(20))
			;
		*status = pBlock->csParam.status.connectionState;
		*pending = pBlock->csParam.status.amtUnreadData;
		err = pBlock->ioResult;
		DisposePtr((Ptr)pBlock);
		return err;
	}
}

/***************************/

OSErr IPNameToAddr (char *name, unsigned long *addr)
{
	OSErr err;
	short i;
	static struct {
		CStr255 name;
		unsigned long addr;
	} cache[10];
	static short numCache=0;
	
	if (gUseOT) {
		return -1;
	}
	else {
		for (i=0; i<numCache; i++) {
			if (strcmp(name, cache[i].name) == 0) {
				*addr = cache[i].addr;
				return noErr;
			}
		}
		if ((err = LowIPNameToAddr(name, addr)) != noErr) return err;
		if (numCache < 10) {
			strcpy(cache[numCache].name, name);
			cache[numCache].addr = *addr;
			numCache++;
		}
		return noErr;
	}
}


/*********************************************/

/*	IPAddrToName invokes the domain name system to translate an IP address
	into a domain name. */
	
OSErr IPAddrToName (unsigned long addr, char *name)
{
//strcpy (name, "unknown");
//return 0;
	if (gUseOT) {
		return -1;
	}
	else {
		return LowIPAddrToName(addr, name);
	}
}


/*********************************************/

/*	GetMyIPAddr returns the IP address of this Mac. */

OSErr GetMyIPAddr (unsigned long *addr, unsigned long *mask)
{

	if (gUseOT) {
		return -1;
	}
	else {
		return MyHostid(addr, mask);
	}
//	return LowGetMyIPAddr(addr, mask);
}


/*********************************************/

/*	GetMyIPAddrStr returns the IP address of this Mac as a dotted decimal
	string. */
	
OSErr GetMyIPAddrStr (char *addrStr)
{
	if (gUseOT) {
		return -1;
	}
	else {
		return LowGetMyIPAddrStr(addrStr);
	}
}


/*********************************************/

/*	GetMyIPName returns the domain name of this Mac. */

OSErr GetMyIPName (char *name)
{
	unsigned long addr, mask;
	short len;
	static OSErr err;
	static Boolean gotIt=false;
	static CStr255 theName;
	
	if (gUseOT) {
		return -1;
	}
	else {
		if (!gotIt) {
			if ((err = MyHostid(&addr, &mask)) != noErr) return err;
			err = LowIPAddrToName(addr,theName);
			gotIt = true;
			len = strlen(theName);
			if (theName[len-1] == '.') theName[len-1] = 0;
		}
		if (err != noErr) return err;
		strcpy(name,theName);
		return noErr;
	}
}
	