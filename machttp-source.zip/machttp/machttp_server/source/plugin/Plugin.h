/*Plugin.h*/
/******************************************************
 *
 * Lawyer stuff:
 *
 * MacHTTP 2.x, source code
 * Copyright �1993-2001 Chuck Shotton
 * All Rights Reserved.
 *
 * This source code is made available under the terms of the MacHTTP Source License.
 * This license grants you the right to use the source code to create new versions
 * of and derivative works from the original MacHTTP source code. Under the terms of
 * this license, any modifications made to the source code must be made available in
 * source code form to the general public and the MacHTTP.Org organization. You may not
 * redistribute source code or binary versions of the MacHTTP application that make use of
 * the MacHTTP name, logo, or icons without the expressed written consent of MacHTTP.Org
 * or Chuck Shotton.
 *
 * MacHTTP is a trademark of Chuck Shotton. Permission is granted
 * to MacHTTP.Org and its assignees use the MacHTTP name, logo, and icons.
 * Any use not authorized by MacHTTP.Org or Chuck Shotton is prohibited.
 *
 * Additional information can be found at http://www.machttp.org/
 *
 ******************************************************
 * Modifications:
 *
 * 11/09/01 - cshotton - initial version
 *
 * This file contains a skeletal implementation of link-time extentions to MacHTTP.
 * This framework allows custom filter functions and/or action handlers to be linked into
 * MacHTTP as if they were static plug-ins. This is useful for building custom versions
 * of MacHTTP tailored to implement dedicated server types.
 ******************************************************/

//----------------------------------------------------------------------------------------------
/* This section contains compile flags for enabling various plug-in modules that may or may not
   be present in the source tree. By default, they are all off. If you add a specific plug-in source
   file to the MacHTTP project, you must also set the appropriate compile flag below for it to
   be included in the program.
*/

//Internal Demo			- builds the internal plug-in module demo
#define MOD_INTERNAL_DEMO 0

//X10Tools flag			- interface to SandHill's XTension home automation software - www.shed.com
#define MOD_X10TOOLS 0

//SSI flag				- built-in functionality for processing simple server side include files
#define MOD_SSI 0

//----------------------------------------------------------------------------------------------

typedef enum {Plugin_Standard_Role, Plugin_Index_Role, Plugin_NoAccess_Role, Plugin_Error_Role} PluginRole;

void Plugin_Register ();

void Plugin_Init ();

void Plugin_Filter (TCPStreamPtr stream);

unsigned long Plugin_Action (TCPStreamPtr stream, PluginRole role);

void Plugin_Shutdown ();

void Plugin_Idle ();
