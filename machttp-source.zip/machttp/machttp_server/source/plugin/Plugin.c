/*Plugin.c*/
/******************************************************
 *
 * Lawyer stuff:
 *
 * MacHTTP 2.x, source code
 * Copyright �1993-2001 Chuck Shotton
 * All Rights Reserved.
 *
 * This source code is made available under the terms of the MacHTTP Source License.
 * This license grants you the right to use the source code to create new versions
 * of and derivative works from the original MacHTTP source code. Under the terms of
 * this license, any modifications made to the source code must be made available in
 * source code form to the general public and the MacHTTP.Org organization. You may not
 * redistribute source code or binary versions of the MacHTTP application that make use of
 * the MacHTTP name, logo, or icons without the expressed written consent of MacHTTP.Org
 * or Chuck Shotton.
 *
 * MacHTTP is a trademark of Chuck Shotton. Permission is granted
 * to MacHTTP.Org and its assignees use the MacHTTP name, logo, and icons.
 * Any use not authorized by MacHTTP.Org or Chuck Shotton is prohibited.
 *
 * Additional information can be found at http://www.machttp.org/
 *
 ******************************************************
 * Modifications:
 *
 * 11/09/01 - cshotton - initial version
 * 11/17/01 - rpatters1 - modernized and de-linted
 * 11/19/01 - rpatters1 - made MPW-compatibile
 *
 * Description:
 *
 * This file contains a skeletal implementation of link-time extentions to MacHTTP.
 * This framework allows custom filter functions and/or action handlers to be linked into
 * MacHTTP as if they were static plug-ins. This is useful for building custom versions
 * of MacHTTP tailored to implement dedicated server types.
 ******************************************************/
 
#include "config.h"

#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <cstring>

#include <MacWindows.h>
#include <Files.h>
#include <Threads.h>

#include "MacTCPCommonTypes.h"
#include "TCPPB.h"
#include "TCPHi.h"
#include "constants.h"
#include "global_types.h"
#include "http.h"
#include "HTTP_Response.h"

#include "Plugin.h"

#if MOD_INTERNAL_DEMO
#define MYACTION 	"PI_SAMPLE"
#define MYSUFFIX 	".PITEST"
#define MYMIME		"text/html"
#define MYINFO		"This is info for a sample plugin module. It could be any data the module needs later."
#endif

#if MOD_X10TOOLS
#include "x10tools_i.h"
#endif

#if MOD_SSI
#include "ssi_plugin.h"
#endif


/*********************************************/
/* Plugin_Register
 * This routine is called once on start-up, allowing the plug-in code to register itself via action
 * and suffix mapping definitions.
 */
 
void Plugin_Register () {

	ActionPtr act = NULL;

#if MOD_INTERNAL_DEMO
	
	//Register an action for the plugin module. Args are action name, action path, action kind, user defined flag,
	//and private refcon. The second parameter is generally unused for internal actions and external plugins. The
	//path is only important for actions implemented by external ACGIs that must be launched. Note that the A_ACTION
	//keyword is used to distinguish between internal (compile time) actions and external plug-ins to be implemented
	//later.
	 
	act = HTTP_AddAction (MYACTION, MYACTION, A_ACTION, FALSE, MYINFO);
	
	//Add the suffix mapping for the plugin module.
	//Arguments are the kind of action, the action pointer, arg count, suffix, file type, file creator, MIME type, and
	//user defined flag.
	
	//uncomment the following for predefined suffixes. Generally safer to define them in the config file as needed.
	
	//HTTP_AddSuffix (FILE_ACTION, act, 5, MYSUFFIX, "*", "*", MYMIME, FALSE);
#endif

#if MOD_X10TOOLS
	X10Plugin_Register ();
#endif

#if MOD_SSI
	SSIPlugin_Register ();
#endif

}

/*********************************************/
/* Plugin_Init
 * This routine is called once on start-up, allowing the plug-in code to initialize itself.
 */
 
void Plugin_Init () {

	ActionPtr act = NULL;

#if MOD_INTERNAL_DEMO
#endif

#if MOD_X10TOOLS
	X10Plugin_Init ();
#endif

#if MOD_SSI
	SSIPlugin_Init ();
#endif
}

/*********************************************/
/* Plugin_Filter
 * This routine is called for every incoming HTTP request, after the request has been read and parsed but
 * before it has been processed. This allows you to rewrite, modify, or otherwise manage the interpretation
 * of the request prior to turning it over to MacHTTP for processing.
 */
 
void Plugin_Filter (TCPStreamPtr stream) {

	if (!stream)
		return;
		
#if MOD_INTERNAL_DEMO
	//do nothing in this sample
#endif

#if MOD_X10TOOLS
	X10Plugin_Filter (stream);
#endif

#if MOD_SSI
	SSIPlugin_Filter (stream);
#endif
}

/*********************************************/
/* Plugin_Action
 * Called to process actions handled by this plug-in. This code is responsible for generating the entire HTTP
 * response header and results.
 */
 
unsigned long Plugin_Action (TCPStreamPtr stream, PluginRole role) {

	OSErr err = 0;
	unsigned long bytes = 0;
	char *theAction = "";
	
	if (!stream)
		return bytes;
		
	if (stream->action != NULL) {
		theAction = stream->action->tag;
	}
	
#if MOD_INTERNAL_DEMO
	if (!strcmp (theAction, MYACTION)) {
		char s [512];
		unsigned short i;
		
		HTTP_Respond (stream, R_OK, "");	//send back a 200 OK header
		
		sprintf (s, "<html><head><title>This is a test</title></head><body><h2>Sample plug-in module</h2>\n");
		i = strlen (s);
		bytes += i;
		err = SendData(stream->stream, s, i, false);

		sprintf (s, "<b>Connection ID</b> - %lu<p>\n", stream->id);
		i = strlen (s);
		bytes += i;
		err = SendData(stream->stream, s, i, false);

		sprintf (s, "<b>Role</b> - %lu<p>\n", (unsigned long) role);
		i = strlen (s);
		bytes += i;
		err = SendData(stream->stream, s, i, false);

		sprintf (s, "<b>URL</b> - %s<p>\n", stream->url_realname);
		i = strlen (s);
		bytes += i;
		err = SendData(stream->stream, s, i, false);

		sprintf (s, "<b>Path Args</b> - %s<p>\n", stream->path_args);
		i = strlen (s);
		bytes += i;
		err = SendData(stream->stream, s, i, false);

		sprintf (s, "<b>Search Args</b> - %s<p>\n", stream->search_args);
		i = strlen (s);
		bytes += i;
		err = SendData(stream->stream, s, i, false);

		sprintf (s, "<b>User Agent</b> - %s<p>\n", stream->user_agent);
		i = strlen (s);
		bytes += i;
		err = SendData(stream->stream, s, i, false);

		sprintf (s, "</body></html>");
		i = strlen (s);
		bytes += i;
		err = SendData(stream->stream, s, i, false);
		
		return bytes;
	}
#endif

//Note, all "action" routines MUST check internally to see if the action tag matches before processing the request

#if MOD_X10TOOLS
	bytes += X10Plugin_Action (stream, role);
#endif

#if MOD_SSI
	bytes += SSIPlugin_Action (stream, role);
#endif

	return bytes;
	
	role=role; //dead code to eliminate warnings in MPW
}

/*********************************************/
/* Plugin_Shutdown
 * Called to perform one time clean-up before MacHTTP terminates.
 */
 
void Plugin_Shutdown () {

#if MOD_INTERNAL_DEMO	
	//do nothing in this sample
#endif

#if MOD_X10TOOLS
	X10Plugin_Shutdown ();
#endif

#if MOD_SSI
	SSIPlugin_Shutdown ();
#endif

}

/*********************************************/
/* Plugin_Idle
 * Called periodically to allow the plug-in module to perform housekeeping tasks as necessary. Long duration operations
 * should yield to other threads as required. Invoked from the main MacHTTP thread, so the UI will be blocked until
 * processing here is complete.
 */
 
void Plugin_Idle () {

#if MOD_INTERNAL_DEMO	
	//do nothing in this sample
#endif

#if MOD_X10TOOLS
	X10Plugin_Idle ();
#endif

#if MOD_SSI
	SSIPlugin_Idle ();
#endif
	//YieldToAnyThread();
}
