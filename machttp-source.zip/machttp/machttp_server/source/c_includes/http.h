/*http.h*/
/******************************************************
 *
 * Lawyer stuff:
 *
 * MacHTTP 2.x, source code
 * Copyright �1993-2001 Chuck Shotton
 * All Rights Reserved.
 *
 * This source code is made available under the terms of the MacHTTP Source License.
 * This license grants you the right to use the source code to create new versions
 * of and derivative works from the original MacHTTP source code. Under the terms of
 * this license, any modifications made to the source code must be made available in
 * source code form to the general public and the MacHTTP.Org organization. You may not
 * redistribute source code or binary versions of the MacHTTP application that make use of
 * the MacHTTP name, logo, or icons without the expressed written consent of MacHTTP.Org
 * or Chuck Shotton.
 *
 * MacHTTP is a trademark of Chuck Shotton. Permission is granted
 * to MacHTTP.Org and its assignees use the MacHTTP name, logo, and icons.
 * Any use not authorized by MacHTTP.Org or Chuck Shotton is prohibited.
 *
 * Additional information can be found at http://www.machttp.org/
 *
 ******************************************************
 * Modifications:
 *
 * 03/01/01 - cshotton - initial verison
 * 10/22/01 - rpatters1 - added hdr_host_name to tcp_stream
 * 10/28/01 - rpatters1 - removed HTTP_IPAddrToName() proto
 * 10/28/01 - rpatters1 - added HTTP_CheckDNSExclude() proto
 * 11/18/01 - rpatters1 - modernized and de-linted
 * 01/14/02 - instantware - added struct ByteRange and ByteRangePtr to struct tcp_stream
 ******************************************************/

#ifndef HTTP_INC
#define HTTP_INC 1

/*start constants.h*/
#include "constants.h"
/*end constants.h*/

#include "global_types.h"


typedef struct ByteRange
{
	long begin, end;
	struct ByteRange *prev, *next;
} ByteRange, *ByteRangePtr;


/**** STREAM DEFINITION ****/

typedef struct tcp_stream {
	long stream;				/*MacTCP stream*/
	unsigned long id;				/*unique ID made from totalConnections var*/
	ThreadID thread_id;
	TCPiopb * rblock;			/*return block for IP calls*/
	unsigned short s_event;		/*Event code from last ASR call*/
	TCPStreamState state;		/*state used by Logic state machine*/
	HTTPMethod method;			/*HTTP method to perform on URL*/
	long remoteHost;			/*who's on the other end of the connection*/
	struct tcp_stream *next, *prev; /*linked list pointers*/
	long timeout;				/*when is this connection considered defunct?*/
	long t_timer;				/*total time it takes to send data*/
	long t_k;					/*total bytes sent */
	long asr_time, last_query_time;	/*time of last ASR, time of last event query*/
	unsigned short terminate_reason;	/*why was the ASR terminate event returned?*/
	unsigned long flags;		/*used to track progress through the state machine and other conditions*/
	short lastState, lastPend, lastEvt;	/*housekeeping for status displays*/
	short commandDone;
	short is_http10;
	unsigned short httpResponseCode;	/*response code returned for logging purposes*/
	short found;				/*was the file found? was it a version request?*/
	LogAction log_this;			/*is this a real request that should be logged?*/
	ContentType fileType;
	long content_size;			/*Size of data fork*/
	long content_length;		/*value of content-length header field*/
	ByteRangePtr content_range;
	unsigned long request_buffer_size;	/*actual size of allocated request buffer (can vary with GET or POST)*/
	unsigned long request_byte_count;	/*number of bytes stored in request buffer*/
	unsigned long post_arg_byte_count;  /*size of the post args currently buffered*/
	unsigned long creation_date, modification_date;
	FILE *f;
	OSType ftype, fcreator;
	char *post_args;			/*buffer allocated to hold PUT or POST arguments*/
	char *reply_str;			/*buffer for results returned from CGI execution*/
	Size reply_len;				/*length of reply_str*/
	RealmStructPtr whichRealm;	/*which realm does the requested file belong to?*/
	ActionTakenKind actionTaken;/*the action to be performed.*/
	ActionPtr action;			/*pointer to action data, if it exists*/
	char url_fname [ARG_SIZE];	/*?relative file path/name portion of URL from original HTTP request, used (mostly) for logging*/
	char url_realname [URL_SIZE];	/*?relative file path/name portion of URL as modified for virtual domains, etc.*/
	char url_referer [URL_SIZE];
	char user_agent [FILE_NAME_SIZE];
	char mac_fname [FILE_NAME_SIZE];	/*?similar to url_realname, but converted from / separators to : for Mac-style paths used in native calls*/
										/*%CTS we should add a real_mac_fname which is the complete path to a Mac file, with all aliases translated.*/
	char suffix [SUFFIX_LEN];
	char path_args [PATH_ARG_SIZE];
	char search_args [PATH_ARG_SIZE];
	char mime_type [MIME_TYPE_SIZE];
	char content_type [MIME_TYPE_SIZE];
	char range_boundary[MIME_TYPE_SIZE];
	char if_modified_date [DATE_SIZE];
	char host_name [HOST_NAME_SIZE];
	char user_name [USER_NAME_SIZE];
	char password  [PASSWORD_SIZE];
	char from_user [FROM_USER_SIZE];
	char hdr_host_name [HOST_NAME_SIZE];	// the Host: name from the HTTP header. Not used for security because it could be spoofed.
	FSSpec *virtual_dir;
	char *request;							// incoming data buffer for HTTP requests
} TCPStream, *TCPStreamPtr, **TCPStreamHandle;

/***********************************************************/
/*defined in http.c */

void safecpy (char *d, char *s, short len);
void HTTP_Init();
short HTTP_AddData(char *s, unsigned long slen, TCPStreamPtr stream);
void HTTP_DoGetCommand(TCPStreamPtr stream);
void HTTP_LogMessage(char *s);
void HTTP_Shutdown();
short HTTP_LoggingEnabled();
void HTTP_InitLogging();
void HTTP_StopLogging();
Boolean HTTP_CheckDNSExclude (long ip);


ContentType HTTP_TokenType(char *token);
FILE *HTTP_fopen(char *fname, char *mode);
void HTTP_LoadConfig();
short HTTP_IsComplete (TCPStreamPtr stream, unsigned long *post_start);
unsigned char HexChar(unsigned char c);
void HTTP_TranslateString(char *str, unsigned short size);
short HTTP_ExtractMethod (TCPStreamPtr stream, char *s);
void HTTP_ExtractPath (TCPStreamPtr stream, char *s, char *filename, char *args);
void HTTP_ExtractSuffix (char *s, char *suffix);
void HTTP_FindFileType (TCPStreamPtr stream, char *filename, char *suffix);
void HTTP_ExtractPostArgs (TCPStreamPtr stream);
short HTTP_SecurityCheck (TCPStreamPtr stream);
HostFolderPtr HTTP_GetHostFolderListHead();
HostFolderPtr HTTP_GetHostFolderPtr (TCPStreamPtr stream);
short HTTP_GetHostFolder (TCPStreamPtr stream, char *foldername);
short HTTP_strcmp (char *s1, char *s2);
short HTTP_strncmp (char *s1, char *s2, size_t n);
void HTTP_AddRealm (char *r, char *rname);
void HTTP_GetRealm (short num, StringPtr s);
void HTTP_DeleteAllActions ();
void HTTP_SaveDefaultFileInfo (TCPStreamPtr stream, MinimalTCPStreamPtr min);
void HTTP_RestoreDefaultFileInfo (MinimalTCPStreamPtr min, TCPStreamPtr stream);
OSErr HTTP_DefaultNameToFileInfo (char *name, MinimalTCPStreamPtr min);
void HTTP_GetMIMETypeForDefaults ();
void HTTP_CutLogFile ();
void HTTP_IfModified (TCPStreamPtr stream, char *s);
void HTTP_DisposeContentRange(TCPStreamPtr stream);
OSErr HTTP_CheckTriggers (TCPStreamPtr stream);
long HTTP_InterpretHeaderField (TCPStreamPtr stream, char *s);
void HTTP_ParseHeaderFields (TCPStreamPtr stream);
short HTTP_LookupPassword (char *name, char *pw, char *realm);
short HTTP_NeedsAuthentication (TCPStreamPtr stream);
short HTTP_AuthorizationCheck (TCPStreamPtr stream);
short HTTP_DontSendMacHTTP (TCPStreamPtr stream);
OSErr HTTP_ReadFromObjectBody (TCPStreamPtr stream, void *data, long *dataLen);



/***********************************************************/
// public routines useful to Plugin module authors

void HTTP_AddSuffix (ContentType kind, ActionPtr act, 
					short argct, char *arg, char *arg2, char *arg3, char *arg4, 
					short userDefined);

ActionPtr HTTP_FindAction (char *act);

ActionPtr HTTP_AddAction (char *atag, char *apath, ActionTakenKind kind, 
							short userDefined, void *ref);

//defined in logic.c
void LogHostName(char *s);



#include "globals.h"

#endif