/*globals.h*/
/******************************************************
 *
 * Lawyer stuff:
 *
 * MacHTTP 2.x, source code
 * Copyright �1993-2001 Chuck Shotton
 * All Rights Reserved.
 *
 * This source code is made available under the terms of the MacHTTP Source License.
 * This license grants you the right to use the source code to create new versions
 * of and derivative works from the original MacHTTP source code. Under the terms of
 * this license, any modifications made to the source code must be made available in
 * source code form to the general public and the MacHTTP.Org organization. You may not
 * redistribute source code or binary versions of the MacHTTP application that make use of
 * the MacHTTP name, logo, or icons without the expressed written consent of MacHTTP.Org
 * or Chuck Shotton.
 *
 * MacHTTP is a trademark of Chuck Shotton. Permission is granted
 * to MacHTTP.Org and its assignees use the MacHTTP name, logo, and icons.
 * Any use not authorized by MacHTTP.Org or Chuck Shotton is prohibited.
 *
 * Additional information can be found at http://www.machttp.org/
 *
 ******************************************************
 * Modifications:
 *
 * 3/1/01 - cshotton - initial verison
 ******************************************************/

#ifndef _globals_
#define _globals_ 1
extern ContentType defaultDocType;
extern char default_html[256];
extern char error_html[256];
extern char error_html_mime_type [MIME_TYPE_SIZE];
extern ContentType error_content_type;
extern char noaccess_html[256];
extern char noaccess_html_mime_type [MIME_TYPE_SIZE];
extern ContentType noaccess_content_type;

extern MinimalTCPStream default_info, error_info, noaccess_info;

extern char footer_html[256];
extern char footer_html_mime_type [MIME_TYPE_SIZE];
extern ContentType footer_content_type;
extern char defaultMIMEType [MIME_TYPE_SIZE];
extern char doc_root[256];
extern char log_file[256];

extern unsigned long lastLogCut;		//globals.c
extern unsigned long logCutInterval;	//globals.c

extern FSSpec	gServerRootFS;			//globals.c FSSpec for top level server directory

//find these and move to global.c!!!

extern unsigned short kHTTPPort;		/* TCP port assigned for HTTP protocol */
extern short MAX_STREAMS;				/* Max # of simultaneous users */
extern short MAX_TIMEOUT;				/* Max timeout for inactive connections in seconds*/
extern short MAX_LISTENS;      			/* Maximum number of queued listens */
extern long DUMP_BUF_SIZE;				/* Output chunk size for text file transmissions */
extern short PIG_DELAY	;				/* Ticks to steal from user while "still_writing"*/
extern short running_AUX;

extern long totalConnections;
extern short  currConnections;
extern short highConnections;
extern short busyConnections;
extern short deniedConnections;
extern short timeoutConnections;
extern short  currListens;
extern short debugLevel;
extern short done;						/*template.c*/
extern short no_dns;
extern short refuseConnections; 		/*logic.c*/
extern short logging;					/*http.c*/
extern short hideInBack;				/*template.c*/
extern WindowPtr theWin;				/*template.c*/
extern Rect theWinDefaultRect; 			/*template.c*/
extern char *methodTokens[];
extern Boolean gCancel;
extern unsigned long maxMem;
extern unsigned long connectionID;

extern short remove_notify; 			/*http_notification.c*/
extern long gHasComponents;
extern short inForeground;
extern short threadsOK;

extern unsigned long foregroundTicks;	//values passed to WaitNextEvent
extern unsigned long backgroundTicks;
extern unsigned short gUseThreads;		//override for whether or not threads are to be used

extern char *tcpStreamStateText [];

extern long gOSVersion;
extern unsigned long gTerminatedConnections;
extern unsigned long gDataBeforeListen;
#endif