/*** CTemplateAEVT.h ***/
/******************************************************
 *
 * Lawyer stuff:
 *
 * MacHTTP 2.x, source code
 * Copyright �1993-2001 Chuck Shotton
 * All Rights Reserved.
 *
 * This source code is made available under the terms of the MacHTTP Source License.
 * This license grants you the right to use the source code to create new versions
 * of and derivative works from the original MacHTTP source code. Under the terms of
 * this license, any modifications made to the source code must be made available in
 * source code form to the general public and the MacHTTP.Org organization. You may not
 * redistribute source code or binary versions of the MacHTTP application that make use of
 * the MacHTTP name, logo, or icons without the expressed written consent of MacHTTP.Org
 * or Chuck Shotton.
 *
 * MacHTTP is a trademark of Chuck Shotton. Permission is granted
 * to MacHTTP.Org and its assignees use the MacHTTP name, logo, and icons.
 * Any use not authorized by MacHTTP.Org or Chuck Shotton is prohibited.
 *
 * Additional information can be found at http://www.machttp.org/
 *
 ******************************************************
 * Modifications:
 *
 * 03/01/01 - cshotton - initial verison
 * 11/17/01 - rpatters1 - all prototypes moved here
 ******************************************************/

#define 		kAEGenericErr    -1799

#define kMyEventClass 			'WWW�'
#define kWSAPIEventClass 		'WAPI'

//Original 2.0 events

#define kMyAEMenu				'menu'
#define kMyAESuspendLogging		'flog'
#define kMyAEVerbose			'fvrb'
#define kMyAERefuseConnections	'fcon'
#define kMyAEHideWindow			'fwin'
#define kMyAEStatus				'stat'

//Add User event and keywords
#define kMyAEAddUser			'AUsr'
#define kAUsrPasswordKeyword	'AUpw'
#define kAUsrRealmKeyword		'AUrm'

//Delete User event and keywords
#define kMyAEDeleteUser			'DUsr'
#define kDUsrRealmKeyword		'DUrm'

//MacHTTP events
#define kMyAERestart			'Rest'

#define kMyAEValidateUser		'Vusr'
#define kMyAEDumpUsers			'DpUs'
#define kMyAELoadUsers			'LdUs'

#define kMyAEGetSuffix			'GSuf'
#define kMyAESetSuffix			'SSuf'
#define kMyAEGetRealms			'GRlm'
#define kMyAESetRealms			'SRlm'
#define kMyAEGetSecurity		'GSec'
#define kMyAESetSecurity		'SSec'

#define kMyAERequestReporting	'RqRp'
#define kMessagesKeyword		'Kmsg'
#define kStatusKeyword			'Ksta'


/*************************/
/* Property-related info */
#define typeMyApplProp     		'capp'
#define pDumpBufSize			'Dbuf'
#define pPigDelay				'PigD'
#define pMaxUsers				'MaxU'
#define pNoDNS					'Ndns'
#define pTimeOut				'TimO'
#define pMaxListens				'MaxL'

//3.0 properties
#define pLogging 				'Plog'
#define pVerboseMessages		'Pvrb'
#define pRefuseConnections		'Pcon'
#define pDefaultMIMEType		'Pmim'
#define pPort					'Pprt'
#define pIndexFile				'Pixf'
#define pErrorFile				'Perf'
#define pLogFile				'Plgf'
#define pNoAccessFile			'Pnaf'
#define pFooterFile				'Pftf'
#define pHideWindow				'Phid'
#define pSuffixMappings			'Psuf'
#define pAllowDeny				'Pa/d'
#define pRealms					'Prlm'
#define pActions				'Pact'
#define pLogFormat				'Plfm'
#define pPreProcessor			'Ppre'
#define pPostProcessor			'Ppst'
#define pVersionNumber			'Pvrs'
#define pPreferences			'Pref' //This property is not in the AETE resource!
#define pReportDelay			'Prdl'
#define pFileInfoCacheSize		'Pfic'
#define pKeepAliveConnections	'Pkac'
#define pKeepAliveTime			'Pkat'
#define pServerCName			'Pscn'
#define pPluginAdminInfo		'Padm'
#define pCGIBinOnly				'Pcbo'

typedef	ProcessSerialNumber appToken;
	
typedef struct {
	appToken tokenApplToken;
	DescType tokenApplProperty;
} applPropToken;
										

/*The following 3 events are SENT by MacHTTP*/
#define kMyAESearch				'srch'
#define kMyAESearchDoc			'sdoc'
#define kMyAEReceiveReport		'Rrep'
#define kMyAENotifyMessage		'kNfy'
#define kMyAERestartServer		'REST'

#define kForKeyword				'kfor'
#define kUserKeyword			'user'
#define kPasswordKeyword		'pass'
#define kFromUser				'frmu'
#define kAddressKeyword			'addr'
#define kPostKeyword			'post'
#define kMethodKeyword			'meth'
#define kServerName				'svnm'
#define kServerPort				'svpt'
#define kScriptName				'scnm'
#define kContentType			'ctyp'
#define kRefererKeyword			'refr'
#define kUserAgentKeyword		'Agnt'
//
#define kActionKeyword			'Kact'
#define kActionPathKeyword		'Kapt'
#define kClientIPAddress		'Kcip'
#define kFullRequestKeyword		'Kfrq'				
#define kConnectionIDKeyword	'Kcid'
#define kMoreKeyword			'Kmor'

/* W*API AppleEvents */
#define kAEWSAPIReadHTTPData	'WRHD'
#define kAEWSAPIGetIndexedParameter	'GETI'

#define kKeyWSAPILength			'LENG'
#define kKeyConnectionID		'Kcid'
#define kKeyWSAPIIndex			'INDX'

//------------------------------------------------------------------------
void FailErr(OSErr err, char *a);
OSErr SendMENUToSelf (short menuID, short menuItem);
OSErr SendFlagToSelf (long eventCode, Boolean value);
OSErr SendQuitToSelf ();
OSErr InitAppleEvents();

OSErr GotRequiredParams( AppleEvent *theAppleEvent );
pascal OSErr HandleOAPP( AppleEvent *theAppleEvent, AppleEvent *reply, long handlerRefcon);
pascal short MyWaitReplyIdleProc(EventRecord *event, RgnHandle mouseRgn,long sleeptime );
pascal OSErr HandleQUIT( AppleEvent *theAppleEvent, AppleEvent *reply, long handlerRefcon);
pascal OSErr HandleODOC( AppleEvent *theAppleEvent, AppleEvent *reply, long handlerRefcon);
pascal OSErr HandlePDOC( AppleEvent *theAppleEvent, AppleEvent *reply, long handlerRefcon);
pascal OSErr HandleMENU( AppleEvent *theAppleEvent, AppleEvent *reply, long handlerRefcon);
pascal OSErr HandleFLOG( AppleEvent *theAppleEvent, AppleEvent *reply, long handlerRefcon);
pascal OSErr HandleFVRB( AppleEvent *theAppleEvent, AppleEvent *reply, long handlerRefcon);
pascal OSErr HandleFCON( AppleEvent *theAppleEvent, AppleEvent *reply, long handlerRefcon);
pascal OSErr HandleFWIN( AppleEvent *theAppleEvent, AppleEvent *reply, long handlerRefcon);
pascal OSErr HandleSTAT( AppleEvent *theAppleEvent, AppleEvent *reply, long handlerRefcon);
pascal OSErr HandleAUsr( AppleEvent *theAppleEvent, AppleEvent *reply, long handlerRefcon);
pascal OSErr HandleDUsr( AppleEvent *theAppleEvent, AppleEvent *reply, long handlerRefcon);
pascal OSErr HandleVusr( AppleEvent *theAppleEvent, AppleEvent *reply, long handlerRefcon);
pascal OSErr HandleWRHD( AppleEvent *theAppleEvent, AppleEvent *reply, long handlerRefcon);
pascal OSErr HandleGETI( AppleEvent *theAppleEvent, AppleEvent *reply, long handlerRefcon);
pascal OSErr HandleReply( AppleEvent *theAppleEvent, AppleEvent *reply, long handlerRefcon);
pascal OSErr HandleEverythingElse( AppleEvent *theAppleEvent, AppleEvent *reply, long handlerRefcon);
pascal void GetRawDataFromDescriptor(const AEDesc *theDesc, Ptr destPtr, Size destMaxSize, Size *actSize);
pascal OSErr GetIntegerFromDescriptor(const AEDesc *sourceDesc, short *result);
pascal OSErr GetBooleanFromDescriptor(const AEDesc *sourceDesc, Boolean *result);
pascal OSErr GetApplicationProperty(const AEDesc *theObjToken, AEDesc *dataDesc);
pascal OSErr PropertyFromApplAccessor(DescType wantClass, const AEDesc *container,
										DescType containerClass, DescType form, 
										const AEDesc *selectionData, AEDesc *value,
										long theRefCon);
pascal OSErr HandleGetData(AEDesc *theObj, DescType whatType, AEDesc *dataDesc);
pascal OSErr DoGetData(const AppleEvent *theAppleEvent, AppleEvent *reply, long handlerRefCon);
pascal OSErr SetApplicationProperty(AEDesc *theObjToken, AEDesc *dataDesc);
pascal OSErr HandleSetData(AEDesc *theObj, AEDesc *dataDesc);
pascal OSErr DoSetData(const AppleEvent *theAppleEvent, AppleEvent *reply, long handlerRefCon);

