/*** Template.h ***/
/******************************************************
 *
 * Lawyer stuff:
 *
 * MacHTTP 2.x, source code
 * Copyright �1993-2001 Chuck Shotton
 * All Rights Reserved.
 *
 * This source code is made available under the terms of the MacHTTP Source License.
 * This license grants you the right to use the source code to create new versions
 * of and derivative works from the original MacHTTP source code. Under the terms of
 * this license, any modifications made to the source code must be made available in
 * source code form to the general public and the MacHTTP.Org organization. You may not
 * redistribute source code or binary versions of the MacHTTP application that make use of
 * the MacHTTP name, logo, or icons without the expressed written consent of MacHTTP.Org
 * or Chuck Shotton.
 *
 * MacHTTP is a trademark of Chuck Shotton. Permission is granted
 * to MacHTTP.Org and its assignees use the MacHTTP name, logo, and icons.
 * Any use not authorized by MacHTTP.Org or Chuck Shotton is prohibited.
 *
 * Additional information can be found at http://www.machttp.org/
 *
 ******************************************************
 * Modifications:
 *
 * 03/01/01 - cshotton - initial verison
 * 11/18/01 - rpatters1 - modernized and de-linted
 ******************************************************/


extern long gOSVersion;
extern short hideInBack;

void Error(char *msg);
void MenuItem(short menuID, short itemNumber);
void MHideWindow (Boolean hide);
void MVerboseMessages (Boolean markChar);
void MSuspendLogging (Boolean markChar);
void MFileQuit();
void MDisplayHostfolderStats();
void MRefuseConnections(Boolean refuse);

void CheckMulti();
void Shutdown();
void Die();
void WindowSetup();
void MenuSetup();
short CheckOS();
void Initialize();
void MDeskAbout();
void DoMenu(long menuResult);
void DoMouseDown();
void DoKeyDown();
void DrawOnlyGrowIcon(WindowPtr win);
void DoUpdate();
void DoMulti(EventRecord *myEvent);
short CkEvents();

#define STAT_AREA_HEIGHT 46