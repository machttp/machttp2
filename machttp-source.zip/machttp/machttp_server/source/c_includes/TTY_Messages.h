/*** TTY_Messages.h ***/
/******************************************************
 *
 * Lawyer stuff:
 *
 * MacHTTP 2.x, source code
 * Copyright �1993-2001 Chuck Shotton
 * All Rights Reserved.
 *
 * This source code is made available under the terms of the MacHTTP Source License.
 * This license grants you the right to use the source code to create new versions
 * of and derivative works from the original MacHTTP source code. Under the terms of
 * this license, any modifications made to the source code must be made available in
 * source code form to the general public and the MacHTTP.Org organization. You may not
 * redistribute source code or binary versions of the MacHTTP application that make use of
 * the MacHTTP name, logo, or icons without the expressed written consent of MacHTTP.Org
 * or Chuck Shotton.
 *
 * MacHTTP is a trademark of Chuck Shotton. Permission is granted
 * to MacHTTP.Org and its assignees use the MacHTTP name, logo, and icons.
 * Any use not authorized by MacHTTP.Org or Chuck Shotton is prohibited.
 *
 * Additional information can be found at http://www.machttp.org/
 *
 ******************************************************
 * Modifications:
 *
 * 03/01/01 - cshotton - initial verison
 * 11/18/01 - rpatters1 - modernized and de-linted
 ******************************************************/


void TTY_InitMessages(WindowPtr theWin, Rect r, short font, short font_size, short scroll_bar);
/* Init for programs with windows already */

//void TTY_SAInitMessages();
/** Initialization for stand-alone, dumb tty applications. **/
/** Should be the FIRST call in your main program. **/

void TTY_RedrawMessages();
/*repaint the message area*/

void TTY_WriteMessage(char *str, short cr);
/** writes a message to the debug window, adding a CR at the end **/

void TTY_ClearMessages();
/** clear out top line and message area*/

void TTY_HandleScroll(EventRecord *event);

void TTY_Activate(short active);

void TTY_Idle ();

void TTY_Copy ();

void TTY_Resize();

void TTY_Die();
void TTY_AdjustScroll();
void TTY_Click();
short TTY_Lines();
void TTY_ScrollMessages(short delta);
void TTY_Scroll(short dv);
pascal void TTY_TrackScroll(ControlHandle h, short part);
void TTY_ScrollToEnd();
