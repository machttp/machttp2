/*HTTP_Response.h*/
/******************************************************
 *
 * Lawyer stuff:
 *
 * MacHTTP 2.x, source code
 * Copyright �1993-2001 Chuck Shotton
 * All Rights Reserved.
 *
 * This source code is made available under the terms of the MacHTTP Source License.
 * This license grants you the right to use the source code to create new versions
 * of and derivative works from the original MacHTTP source code. Under the terms of
 * this license, any modifications made to the source code must be made available in
 * source code form to the general public and the MacHTTP.Org organization. You may not
 * redistribute source code or binary versions of the MacHTTP application that make use of
 * the MacHTTP name, logo, or icons without the expressed written consent of MacHTTP.Org
 * or Chuck Shotton.
 *
 * MacHTTP is a trademark of Chuck Shotton. Permission is granted
 * to MacHTTP.Org and its assignees use the MacHTTP name, logo, and icons.
 * Any use not authorized by MacHTTP.Org or Chuck Shotton is prohibited.
 *
 * Additional information can be found at http://www.machttp.org/
 *
 ******************************************************
 * Modifications:
 *
 * 03/01/01 - cshotton - initial verison
 * 11/17/01 - rpatters1 - modernized and de-linted
 * 01/14/02 - instantware - added new response constants 206 and 416
 ******************************************************/


#define HTTP_RESP_CRLF "\r\n"
#define HTTP_RESP_2CRLF "\r\n\r\n"

#define HTTP_VERSION "HTTP/1.0"

#define HTTP_RESP_MIMEVERS "MIME-Version: 1.0"
// Now defined in config.h #define HTTP_RESP_SERVER   "Server: MacHTTP"

#define R_OK					200
#define R_ACCEPTED				202
#define R_PARTIAL_CONTENT		206
#define R_NOT_MODIFIED			304
#define R_FORBIDDEN				403
#define R_NOT_FOUND				404
#define R_RANGE_UNSATISFIABLE	416
#define R_TOO_BUSY				503

char *HTTP_GetVirtualHostname (TCPStreamPtr stream);	//returns virtual hostname or local host name, depending on HOSTFOLDER config

void HTTP_Respond (TCPStreamPtr stream, short err_code, char *msg);
void HTTP_ErrorResponse (TCPStreamPtr stream, short err_code, char *msg);
void HTTP_RefusedResponse (TCPStreamPtr stream);

void Response_InitDate ();
void HTTP_MakeDate (unsigned long secs, char *s);
void HTTP_AuthorizeResponse (TCPStreamPtr stream);
void HTTP_RedirectResponse (TCPStreamPtr stream, char *path);
void HTTP_DirRedirectResponse (TCPStreamPtr stream);
void HTTP_ResponseInit();
