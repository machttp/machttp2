/*Prefs.h*/
/******************************************************
 *
 * Lawyer stuff:
 *
 * MacHTTP 2.x, source code
 * Copyright �1993-2001 Chuck Shotton
 * All Rights Reserved.
 *
 * This source code is made available under the terms of the MacHTTP Source License.
 * This license grants you the right to use the source code to create new versions
 * of and derivative works from the original MacHTTP source code. Under the terms of
 * this license, any modifications made to the source code must be made available in
 * source code form to the general public and the MacHTTP.Org organization. You may not
 * redistribute source code or binary versions of the MacHTTP application that make use of
 * the MacHTTP name, logo, or icons without the expressed written consent of MacHTTP.Org
 * or Chuck Shotton.
 *
 * MacHTTP is a trademark of Chuck Shotton. Permission is granted
 * to MacHTTP.Org and its assignees use the MacHTTP name, logo, and icons.
 * Any use not authorized by MacHTTP.Org or Chuck Shotton is prohibited.
 *
 * Additional information can be found at http://www.machttp.org/
 *
 ******************************************************
 * Modifications:
 *
 * 03/01/01 - cshotton - initial verison
 * 11/17/01 - rpatters1 - modernized and de-linted
 ******************************************************/


void Prefs_GetPassword (StringPtr name, StringPtr password);
OSErr Prefs_WriteNewPassword (StringPtr name, StringPtr password, short interactive);
OSErr Prefs_DeletePassword (StringPtr name, short interactive);
OSErr Prefs_OpenPrefs();
OSErr Prefs_ReadSettings();
OSErr Prefs_WriteSettings();
OSErr Prefs_Init();

#define kPrefsVersion 0x00020400
#define kPrefsResID 128

typedef struct prefstruct {
	long version;
	Rect statusWinRect;
	Rect passwordWinRect;
	Rect reportWinRect;
	Rect unusedRect;
	short verboseFlag;
	short refuseFlag;
	short suspendFlag;
	short hideWinFlag;
	unsigned long lastLogCut;	//time in ticks of last log rollover
	short unusedShorts [10];
} PrefStruct, *PrefStructPtr, **PrefStructHandle;

extern PrefStruct prefs;

void Prefs_Shutdown();
void Unload_Seg();
