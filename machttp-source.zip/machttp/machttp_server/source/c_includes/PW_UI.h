/*PW_UI.h*/
/******************************************************
 *
 * Lawyer stuff:
 *
 * MacHTTP 2.x, source code
 * Copyright �1993-2001 Chuck Shotton
 * All Rights Reserved.
 *
 * This source code is made available under the terms of the MacHTTP Source License.
 * This license grants you the right to use the source code to create new versions
 * of and derivative works from the original MacHTTP source code. Under the terms of
 * this license, any modifications made to the source code must be made available in
 * source code form to the general public and the MacHTTP.Org organization. You may not
 * redistribute source code or binary versions of the MacHTTP application that make use of
 * the MacHTTP name, logo, or icons without the expressed written consent of MacHTTP.Org
 * or Chuck Shotton.
 *
 * MacHTTP is a trademark of Chuck Shotton. Permission is granted
 * to MacHTTP.Org and its assignees use the MacHTTP name, logo, and icons.
 * Any use not authorized by MacHTTP.Org or Chuck Shotton is prohibited.
 *
 * Additional information can be found at http://www.machttp.org/
 *
 ******************************************************
 * Modifications:
 *
 * 03/01/01 - cshotton - initial verison
 * 11/17/01 - rpatters1 - modernized and de-linted
 ******************************************************/


extern DialogPtr pw_dlog;

void UI_AddToList(char *s);

void /*OSErr*/ UI_DeleteCurrentCell ();
void UI_DeleteFromList(StringPtr name);

void UI_SetRealm (StringPtr s);
void UI_Error (StringPtr);
void HTTP_GetRealm (short num, StringPtr s);

Boolean UI_HasColorQD();
short UI_ScreenDepth();
void UI_3dRect(Rect *bounds, Boolean innie, short width, Boolean filled, Boolean frame);
pascal void ListDrawProc(WindowPtr theDialog, short theItem);
void UI_BuildRealmMenu (StringPtr s);
void UI_RealmPopUp ();
short UIRunDLOG (DialogPtr theDialog, EventRecord *theEvent, short *itemHit);
void UI_Init();
short UI_LastCommand();
void UI_GetUserName (StringPtr name);
void UI_GetPassword (StringPtr pass);
void UI_SetUserName (char *username);
void UI_SetPassword (StringPtr password);
void UI_GetCurrentSelection ();
void PW_NewButton();
void PW_DeleteButton();
void PW_Run(EventRecord *theEvent);
void UI_EmptyList();
void UI_Redraw();
void UI_FileError (char *s, OSErr err);
