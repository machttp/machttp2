/*Logic.h*/
/******************************************************
 *
 * Lawyer stuff:
 *
 * MacHTTP 2.x, source code
 * Copyright �1993-2001 Chuck Shotton
 * All Rights Reserved.
 *
 * This source code is made available under the terms of the MacHTTP Source License.
 * This license grants you the right to use the source code to create new versions
 * of and derivative works from the original MacHTTP source code. Under the terms of
 * this license, any modifications made to the source code must be made available in
 * source code form to the general public and the MacHTTP.Org organization. You may not
 * redistribute source code or binary versions of the MacHTTP application that make use of
 * the MacHTTP name, logo, or icons without the expressed written consent of MacHTTP.Org
 * or Chuck Shotton.
 *
 * MacHTTP is a trademark of Chuck Shotton. Permission is granted
 * to MacHTTP.Org and its assignees use the MacHTTP name, logo, and icons.
 * Any use not authorized by MacHTTP.Org or Chuck Shotton is prohibited.
 *
 * Additional information can be found at http://www.machttp.org/
 *
 ******************************************************
 * Modifications:
 *
 * 03/01/01 - cshotton - initial verison
 * 11/17/01 - rpatters1 - modernized and de-linted
 * 01/15/02 - instantware - added prototype for fread_Ranges()
 ******************************************************/


OSErr LogInit();
void LogShutdown();
void LogMakeStatusReport (char *s);
void LogRefuseConnections (short refuse);
void LogDebug(short level);
void LogRedraw();
void LogIdle();

OSErr LogAssignAppResults (unsigned short retID, char *temp, Size len, OSErr err);

void LogMemCheck(long *memfree);
void LogInitStream (TCPStreamPtr stream);
int StreamIsTerminated (TCPStreamPtr stream);
TCPStreamPtr MakeNewStream();
void InsertStream(TCPStreamPtr s);
void DeleteStream(TCPStreamPtr s);
pascal void MyASR ( StreamPtr s, unsigned short event, TCPStreamPtr userData,
					unsigned short termReason, struct ICMPReport *icmp);
short ASRIsValid(TCPStreamPtr stream);
OSErr LogOpenPassive (TCPStreamPtr s);
void LogCloseStream (TCPStreamPtr stream);
void LogReleaseStream (TCPStreamPtr stream);
void LogStartTimeout(TCPStreamPtr stream, short seconds);
short LogTimeout(TCPStreamPtr stream);
void LogQueueListens();
void LogConnection(TCPStreamPtr stream);
void LogDrawStatus();
void LogUpdateStats();
long LogDumpBinaryFile (TCPStreamPtr stream, Boolean header_needed);
size_t fread_Ranges (char *ptr, size_t size, size_t nmemb, TCPStreamPtr stream);
short LogStillWritingBinary (TCPStreamPtr stream);
long LogDumpTextFile (TCPStreamPtr stream);
short LogStillWritingText (TCPStreamPtr stream);
void LogMakeOSAGlobal (TCPStreamPtr stream, char *dest, char *source, char *args);
long LogExecuteScriptFile (TCPStreamPtr stream);
long LogExecuteAPPLFile (TCPStreamPtr stream);
long LogExecuteACGIFile (TCPStreamPtr stream);
long LogDumpFile (TCPStreamPtr stream);
short LogStillWriting (TCPStreamPtr stream);
void LogReportState (TCPStreamPtr stream, char *msg, byte state, unsigned short pending);
//void sleep(long ticks);
OSErr ReadData(unsigned long stream, char *s, unsigned long *bytesRead);
void GetDStr(short item, char *str);
void LogRun();
void LogStopWriting (TCPStreamPtr stream);
Boolean GiveTime(short sleepTime);

void LogDrawMemoryErrorIcon ();
void LogDrawRefuseIcon (short draw_it);
void LogMemoryError();
void LogLowMemoryReport (unsigned long memfree);
void LogHostName(char *s);
long LogExecuteCGIFile (TCPStreamPtr stream);
LogStillWritingACGI(TCPStreamPtr stream);
short LogNotConditionalGet (TCPStreamPtr stream);

void LogTCPIPReport (TCPStreamPtr cstream);		//dump a status report of streams, threads, etc.