/*HTTP_Properties.h*/
/******************************************************
 *
 * Lawyer stuff:
 *
 * MacHTTP 2.x, source code
 * Copyright �1993-2001 Chuck Shotton
 * All Rights Reserved.
 *
 * This source code is made available under the terms of the MacHTTP Source License.
 * This license grants you the right to use the source code to create new versions
 * of and derivative works from the original MacHTTP source code. Under the terms of
 * this license, any modifications made to the source code must be made available in
 * source code form to the general public and the MacHTTP.Org organization. You may not
 * redistribute source code or binary versions of the MacHTTP application that make use of
 * the MacHTTP name, logo, or icons without the expressed written consent of MacHTTP.Org
 * or Chuck Shotton.
 *
 * MacHTTP is a trademark of Chuck Shotton. Permission is granted
 * to MacHTTP.Org and its assignees use the MacHTTP name, logo, and icons.
 * Any use not authorized by MacHTTP.Org or Chuck Shotton is prohibited.
 *
 * Additional information can be found at http://www.machttp.org/
 *
 ******************************************************
 * Modifications:
 *
 * 03/01/01 - cshotton - initial verison
 * 11/17/01 - rpatters1 - modernized and de-linted
 ******************************************************/


Boolean Get_VerboseFlag ();
void Set_VerboseFlag (Boolean flag);

Boolean Get_RefuseConFlag ();
void Set_RefuseConFlag (Boolean flag);

Boolean Get_SuspendLogFlag ();
void Set_SuspendLogFlag (Boolean flag);

Boolean Get_HideWinFlag ();
void Set_HideWinFlag (Boolean flag);

void  Get_StatusWinRect (Rect *r);
void Set_StatusWinRect (Rect *r);

short Get_DumpBufSize ();
OSErr Set_DumpBufSize (short i);

short Get_PigDelay ();
OSErr Set_PigDelay (short i);

unsigned long Get_ForegroundTicks ();
OSErr Set_ForegroundTicks (unsigned long i);

unsigned long Get_BackgroundTicks ();
OSErr Set_BackgroundTicks (unsigned long i);

short Get_MaxStreams ();
OSErr Set_MaxStreams (short i);

Boolean Get_NoDNS ();
OSErr Set_NoDNS (Boolean i);

short Get_Timeout ();
OSErr Set_Timeout (short i);

short Get_MaxListens ();
OSErr Set_MaxListens (short i);

void Get_DefaultMIMEType (char *s, Size *len);
void Set_DefaultMIMEType (char *s);

unsigned short Get_IPPort ();
void Set_IPPort (unsigned short port);

unsigned long Get_LastLogCut ();		//should be considered a private property
void Set_LastLogCut (unsigned long llc);

unsigned long Get_LogCutInterval ();	
unsigned long Get_LogCutIntervalSecs ();
void Set_LogCutInterval (unsigned long lci); //ultimately will be a settable AE property

#define MAX_DUMP_BUF_SIZE 10240	/* Upper bound for DUMP_BUF_SIZE*/
