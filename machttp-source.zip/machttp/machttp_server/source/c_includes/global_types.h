/*global_types.h*/
/******************************************************
 *
 * Lawyer stuff:
 *
 * MacHTTP 2.x, source code
 * Copyright �1993-2001 Chuck Shotton
 * All Rights Reserved.
 *
 * This source code is made available under the terms of the MacHTTP Source License.
 * This license grants you the right to use the source code to create new versions
 * of and derivative works from the original MacHTTP source code. Under the terms of
 * this license, any modifications made to the source code must be made available in
 * source code form to the general public and the MacHTTP.Org organization. You may not
 * redistribute source code or binary versions of the MacHTTP application that make use of
 * the MacHTTP name, logo, or icons without the expressed written consent of MacHTTP.Org
 * or Chuck Shotton.
 *
 * MacHTTP is a trademark of Chuck Shotton. Permission is granted
 * to MacHTTP.Org and its assignees use the MacHTTP name, logo, and icons.
 * Any use not authorized by MacHTTP.Org or Chuck Shotton is prohibited.
 *
 * Additional information can be found at http://www.machttp.org/
 *
 ******************************************************
 * Modifications:
 *
 * 03/01/01 - cshotton - initial verison
 * 10/22/01 - rpatters1 - added FILE_HOST_FOLDER and log file recs for HOSTFOLDER
 * 10/28/01 - rpatters1 - added FILE_DNS_EXCLUDE and log file recs for DNS_EXCLUDE
 * 11/21/01 - rpatters1 - added connections field to HostFolderStruct
 * 11/24/01 - rpatters1 - added most_recent connection time to HostFolderStruct
 ******************************************************/

#ifndef _global_types_
#define _global_types_ 1

/* Configuration file tokens */
/* actual token values are defined in http.c */
typedef enum {FILE_BINARY, FILE_TEXT, FILE_SCRIPT, FILE_APPL, FILE_CGI, FILE_ACGI, FILE_PLUGIN,
				FILE_RAW, FILE_VERSION, FILE_DEFAULT, FILE_INDEX, FILE_ERROR, FILE_LOG, 
				FILE_ALLOW, FILE_DENY, FILE_NOACCESS, FILE_PORT,
				FILE_MAXUSERS, FILE_MAXLISTENS, FILE_TIMEOUT,
				FILE_MIME, FILE_DOC_ROOT, FILE_CONFIG_VERSION,
				FILE_PIG_DELAY, FILE_DUMP_BUF_SIZE, FILE_NO_DNS, FILE_REALM,
				FILE_ACTION, FILE_SUFFIX, FILE_LOG_FORMAT,
				FILE_LOG_ROLLOVER, FILE_HOST_FOLDER, FILE_DNS_EXCLUDE,
				FILE_FOREGROUNDTICKS, FILE_BACKGROUNDTICKS, FILE_USE_THREADS,
				FILE_UNKNOWN} ContentType;

/* HTTP Method tokens */

typedef enum {METHOD_GET, METHOD_HEAD, METHOD_POST, 
				METHOD_CONDITIONAL, METHOD_AUTHORIZE, METHOD_UNKNOWN} HTTPMethod;


/* state machine types */

typedef enum {inactive, listening, reading, writing, still_writing,
			closing, closed, terminated} TCPStreamState;

/* actions for logging */
typedef enum {L_UNKNOWN, L_LOG_IT, L_LOGGED_IT} LogAction;

/* Linked list for URL realm security, holds realm names */

typedef struct realm_struct {
	char realm [32]; 			/*string to match in URLs*/
	char realmName [64];		/*text describing realm*/
	struct realm_struct *next;
} RealmStruct, *RealmStructPtr;

/* Linked list for security (by address) information */

typedef struct access_ctl_struct {
	ContentType allow;
	char data [256];
	struct access_ctl_struct *next;
} AccessCtlStruct, *AccessCtlPtr;

/* Struct for caching username/password data */

typedef struct user_id_struct {
	long age;
	char username [256];
	char password [256];
} UserIDStruct;

/* Action Taken Kind*/

typedef enum {A_UNKNOWN, A_ACTION, A_CGI, A_ACGI, A_PREPROCESSOR, A_POSTPROCESSOR, A_PLUGIN,
			A_ERROR, A_NOACCESS, A_INDEX, A_VERSION, A_REDIRECT, A_DIR_REDIRECT, 
			A_GATEWAY_TIMEOUT, A_CLIENT_TIMEOUT, A_NONE} ActionTakenKind;

/* Action structure*/

typedef struct action_struct {
	ActionTakenKind kind;
	short userDefined;			// is this a user-defined action or from a plug-in?
	char tag [ACTION_TAG_SIZE];
	char path [FILE_NAME_SIZE];
	FSSpec fs;
	struct action_struct *next;
	void *refcon;				// normally used to hold a WPI_StructPtr for the plug-in
} ActionStruct, *ActionPtr;

/* File suffix mapping information */

typedef struct {
	ActionPtr action;
	char str[SUFFIX_LEN];
	ContentType kind;
	OSType ftype, fcreator;
	char mime_type [MIME_TYPE_SIZE];
	unsigned short userDefined;
} SuffixType, *SuffixTypePtr;

typedef struct suffixListNode {
	SuffixTypePtr suffix;
	struct suffixListNode *next;
} SuffixListNode, *SuffixListNodePtr;

typedef struct hostfolder_struct {
	char hostname[256];
	char foldername[256];
	unsigned long connections;
	unsigned long most_recent;
	FSSpec fs;
	struct hostfolder_struct *next;
} HostFolderStruct, *HostFolderPtr;

typedef struct dns_exclude_struct {
	char ip_string[256];
	short ip_strlen;		//cache it so we only calculate once
	struct dns_exclude_struct *next;
} DNSExcludeStruct, *DNSExcludePtr;

typedef struct minimal_tcp_stream {
	struct minimal_tcp_stream *next;
	short found;				/*was the file found? was it a version request?*/
	ContentType fileType;
	ActionTakenKind actionTaken; /*the action to be performed.*/
	ActionPtr action;			/*pointer to action data, if it exists*/
	ActionPtr saved_action;
	OSType ftype, fcreator;
	FSSpec fs;
	char mime_type [MIME_TYPE_SIZE];
	char mac_fname [FILE_NAME_SIZE];
} MinimalTCPStream, *MinimalTCPStreamPtr;



#endif