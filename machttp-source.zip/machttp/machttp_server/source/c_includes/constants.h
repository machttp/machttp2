/*constants.h*/
/******************************************************
 *
 * Lawyer stuff:
 *
 * MacHTTP 2.x, source code
 * Copyright �1993-2001 Chuck Shotton
 * All Rights Reserved.
 *
 * This source code is made available under the terms of the MacHTTP Source License.
 * This license grants you the right to use the source code to create new versions
 * of and derivative works from the original MacHTTP source code. Under the terms of
 * this license, any modifications made to the source code must be made available in
 * source code form to the general public and the MacHTTP.Org organization. You may not
 * redistribute source code or binary versions of the MacHTTP application that make use of
 * the MacHTTP name, logo, or icons without the expressed written consent of MacHTTP.Org
 * or Chuck Shotton.
 *
 * MacHTTP is a trademark of Chuck Shotton. Permission is granted
 * to MacHTTP.Org and its assignees use the MacHTTP name, logo, and icons.
 * Any use not authorized by MacHTTP.Org or Chuck Shotton is prohibited.
 *
 * Additional information can be found at http://www.machttp.org/
 *
 ******************************************************
 * Modifications:
 *
 * 3/1/01 - cshotton - initial verison
 ******************************************************/
#ifndef _constants_
#define _constants_ 1

#define APPL_CREATOR		CREATOR_CODE
#define APPL_FTYPE_RAW		'RAW!'
#define APPL_FTYPE_RSRC		'rsrc'
#define WEBSTAR_CREATOR		'WWW�'

#define MIN_MEMORY  	32768	/* Minimum amount of free memory required */
#define DESIRED_FREE_MEM 180000	/* Desired amount of free memory when all connections active*/
#define STREAM_AVG_SIZE	50000	/* Average amount of memory required for each connection*/
#define kBufSize		16384	/* Size for TCP stream buffer and receive buffer */
#define kTimeOut		5		/* Timeout for TCP commands */
#define MAX_LINE_LENGTH 1024	/* Max line length for input text files */
#define REQUEST_SIZE 	4096	/* Size of a single HTTP client request buffer */
#define POST_ARG_SIZE	24000	/* Size of post arg buffer received from client */
#define SCRIPT_SIZE 	32768	/* Max size for AppleScript source files */
#define ARG_SIZE 		1024	/* Size of path or search arguments from URL */
#define URL_SIZE 		1024	/* Max size of a URL string */
#define PATH_ARG_SIZE 	1024	/* Size of path arguments passed to CGI */
#define HOST_NAME_SIZE 	128		/* Size of a DNS host name */
#define USER_NAME_SIZE 	64		/* Size of a user name from HTTP request */
#define PASSWORD_SIZE 	64		/* Size of a password from HTTP request */
#define FROM_USER_SIZE	128		/* Size of the from_user AE var (remote e-mail addr) */
#define DATE_SIZE		128		/* size of date field for if-modified-since date */
#define CLOSE_TIMEOUT 	15		/* Close all connections 15 seconds after completion*/

#define FILE_NAME_SIZE 258		/*size of text representations of file paths*/
#define MIME_TYPE_SIZE 64		/* Size of buffer holding MIME type info in streams*/
#define DEFAULT_MIME_TYPE	"text/html"
#define REALM_SIZE 		34
#define REALM_NAME_SIZE	66
#define ACTION_TAG_SIZE	34
#define SUFFIX_LEN	34

#define SUCC_STR "GET"			

#define MAX_TOKEN 34 			/*number of tokens for config file parsing*/

#define ACGI_REPLY_CHUNK_SIZE 32768		/*send back ACGI replies in 32k chunks to keep MacTCP happy*/

#define CONNECTION_MASK 0x00003FFF		/*mask used to clean up connection id params to/from AppleEvents*/

/*copyright information*/

#define COPYRIGHT_NAME ":M_A_C_H_T_T_P_V_E_R_S_I_O_N"

/* file names */

#define DEFAULT_HTML "Default.html"
#define ERROR_HTML ":Error.html"
#define NOACCESS_HTML ":NoAccess.html"
#define DEFAULT_DOC_ROOT ""
#define CONFIG_FILE "MacHTTP.config"
#define LOG_FILE ""

#define CodeRedErr	-23050

//masks that are used with TCPStreamPtr->flags to note progress thru the state machine, etc.
#define STREAM_FLAG_LISTEN 				0x00000001
#define STREAM_FLAG_LISTEN_TERMINATE	0x00000002
#define STREAM_FLAG_LISTEN_DATA			0x00000004
#define STREAM_FLAG_LISTEN_BUSY 		0x00000008
#define STREAM_FLAG_LISTEN_OTHEREVT		0x00000010
#define STREAM_FLAG_LISTEN_READING		0x00000020
#define STREAM_FLAG_TERMINATED		 	0x80000000

#endif