#pragma once
/******************************************************
 *
 * Lawyer stuff:
 *
 * MacHTTP 2.x, source code
 * Copyright �1993-2001 Chuck Shotton
 * All Rights Reserved.
 *
 * This source code is made available under the terms of the MacHTTP Source License.
 * This license grants you the right to use the source code to create new versions
 * of and derivative works from the original MacHTTP source code. Under the terms of
 * this license, any modifications made to the source code must be made available in
 * source code form to the general public and the MacHTTP.Org organization. You may not
 * redistribute source code or binary versions of the MacHTTP application that make use of
 * the MacHTTP name, logo, or icons without the expressed written consent of MacHTTP.Org
 * or Chuck Shotton.
 *
 * MacHTTP is a trademark of Chuck Shotton. Permission is granted
 * to MacHTTP.Org and its assignees use the MacHTTP name, logo, and icons.
 * Any use not authorized by MacHTTP.Org or Chuck Shotton is prohibited.
 *
 * Additional information can be found at http://www.machttp.org/
 *
 ******************************************************
 * Modifications:
 *
 * 3/1/01 - cshotton - initial verison
 ******************************************************/



typedef enum {
	
	PathBufferTooSmallErr = 1339,	//	Path is larger than the buffer provided to store it;
									//		original path is wrecked. This can ONLY occur if
									//		the original path designated an alias file.
									//		Giving-up in response to this error is almost 
									//		certainly the correct thing to do, anyway.
	
	PathTooLongForPascalErr			//	Original path won't fit in a Pascal string (Str255), 
									//		so it can't be resolved; original path will be 
									//		returned unharmed. The file specified by this
									//		path could be an alias, or a real file; there's
									//		no way of knowing.
} ResolvePathErrors;


//dead code: OSErr	HTTP_ResolvePath(char *PathName, long PathNamePyLen, short makeFullPath, Boolean *wasAlias);

OSErr ResolvePathAlias (char* path, char* result, unsigned short resultSize, FSSpec *spec, Boolean *isFolder, Boolean *isAlias);
