/*config.h*/
/******************************************************
 *
 * Lawyer stuff:
 *
 * MacHTTP 2.x, source code
 * Copyright �1993-2001 Chuck Shotton
 * All Rights Reserved.
 *
 * This source code is made available under the terms of the MacHTTP Source License.
 * This license grants you the right to use the source code to create new versions
 * of and derivative works from the original MacHTTP source code. Under the terms of
 * this license, any modifications made to the source code must be made available in
 * source code form to the general public and the MacHTTP.Org organization. You may not
 * redistribute source code or binary versions of the MacHTTP application that make use of
 * the MacHTTP name, logo, or icons without the expressed written consent of MacHTTP.Org
 * or Chuck Shotton.
 *
 * MacHTTP is a trademark of Chuck Shotton. Permission is granted
 * to MacHTTP.Org and its assignees use the MacHTTP name, logo, and icons.
 * Any use not authorized by MacHTTP.Org or Chuck Shotton is prohibited.
 *
 * Additional information can be found at http://www.machttp.org/
 *
 ******************************************************
 * Modifications:
 *
 * 03/01/01 - cshotton - initial verison
 * 11/19/01 - rpatters1 - made MPW-compatibile
 * 01/14/02 - instantware - further MPW changes
 ******************************************************/

#define CREATOR_CODE 'WWWz'
#define PRODUCT_NAME "MacHTTP"

#define VERSION_STR "\p2.6.1"
#define C_VERSION_STR "2.6.1"
#define HTTP_RESP_SERVER   "Server: MacHTTP/2.6.1"
#define COPYRIGHT1 "MacHTTP 2.6.1, Copyright �1994-2003 Chuck Shotton, All rights reserved.\r"
#define COPYRIGHT2 "Please visit www.machttp.org for additional info.\r"


#define BETA_MSG " A final release will be made prior to this date.\r"
#define BETA_EXP_YEAR 2004
#define BETA_EXP_MONTH 4
#define BETA_EXP_DAY 1

#define INTERACTIVE				1	/*set to 0 for background only*/
#define BETA_VERSION			0
#define THREAD_SUPPORT			1
#define AUX_SUPPORT 			0
#define REMOTE_TCP_REPORT		0	/*set to 1 to enable remote status reporting on tcp connection stats via verion URL.*/


#ifndef MPW
#define MPW 					0
#endif

#ifndef MPW_PPC
#define MPW_PPC					0
#endif

#ifdef __MWERKS__
#if __powerc == 1
#define CODEWARRIOR         	0
#define CODEWARRIOR_PPC     	1
#else
#define CODEWARRIOR         	1
#define CODEWARRIOR_PPC     	0
#endif
#else
#define CODEWARRIOR         	0
#define CODEWARRIOR_PPC     	0
#endif

#if MPW
#define NEEDS_QD				1    
#define NEEDS_QD_DEFINED		1
#define PROCESSOR_STRING 		"680x0 (MPW)"
#define PARM_UNUSED(X)			X
#endif

#if MPW_PPC
#define NEEDS_QD 				1 
#define NEEDS_QD_DEFINED 		1 
#define PROCESSOR_STRING 		"PowerPC (MPW)"
#define USESROUTINEDESCRIPTORS  1
#define PARM_UNUSED(X)			X
#endif

#if CODEWARRIOR
#define NEEDS_QD 				1 
#define NEEDS_QD_DEFINED 		0  
#define PROCESSOR_STRING 		"680x0 (CW)"
#define PARM_UNUSED(X)
#endif

#if CODEWARRIOR_PPC
#define NEEDS_QD 				1 
#define NEEDS_QD_DEFINED 		0 
#define PROCESSOR_STRING 		"PowerPC (CW)"
#define USESROUTINEDESCRIPTORS  1
#define PARM_UNUSED(X)
#endif

#ifdef THINK_C
#define PROCESSOR_STRING 		"680x0 (TC)"
#define PARM_UNUSED(X)			X
#include <Think.h>
#include <pascal.h>

/*the following needs to go when Symantec upgrades*/
#include "MixedMode.h" 		
#define ControlActionUPP ProcPtr
#define UniversalProcPtr ProcPtr
#define NewAEEventHandlerProc(x) (EventHandlerProcPtr) x
#define NewControlActionProc(x)	 (ProcPtr) x
#endif /*think c*/

#if MPW || MPW_PPC
#ifndef TRUE
#define TRUE true
#endif
#ifndef FALSE
#define FALSE false
#endif
#define CtoPstr c2pstr
#define PtoCstr p2cstr
#endif

#if CODEWARRIOR
#define AEEventHandlerProcPtr AEEventHandlerUPP
#endif

#if THINK_C
#define AEEventHandlerProcPtr EventHandlerProcPtr
#endif