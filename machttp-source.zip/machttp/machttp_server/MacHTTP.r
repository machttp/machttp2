/* Source File for the SIZE resource for building with MPW */

include ":source:resource:Template.rsrc";
include ":source:resource:PW_UI.rsrc";

#include "Types.r"

resource 'SIZE' (-1) {
	dontSaveScreen,
	acceptSuspendResumeEvents,
	enableOptionSwitch,
	canBackground,				/* we can background. Our sleep value */
								/* guarantees we don't hog the Mac. */
	multiFinderAware,			/* this says we do our own activate/deactivate; don't fake us out. */
	backgroundAndForeground,	/* this is definitely not a background-only application! */
	dontGetFrontClicks,			/* change this is if you want "do first click" behavior like the Finder. */
	ignoreChildDiedEvents,		/* essentially, I'm not a debugger (sub-launching). */
	is32BitCompatible,			/* this app should be run in 32-bit address space. */
	isHighLevelEventAware,		/* accepts the core apple-events. */
	localAndRemoteHLEvents,		/* change to 'reserved' if you don't like remote-control. */
	notStationeryAware,			/* not stationery-aware. */
	dontUseTextEditServices,	/* can't handle inline input of chinese, etc. */
	reserved,
	reserved,
	reserved,
	5 * 1024 * 1024,
	1024 * 1024
};
