/*Plugin.c*/
/******************************************************
 *
 * Lawyer stuff:
 *
 * MacHTTP 2.x, source code
 * Copyright �1993-2001 Chuck Shotton
 * All Rights Reserved.
 *
 * This source code is made available under the terms of the MacHTTP Source License.
 * This license grants you the right to use the source code to create new versions
 * of and derivative works from the original MacHTTP source code. Under the terms of
 * this license, any modifications made to the source code must be made available in
 * source code form to the general public and the MacHTTP.Org organization. You may not
 * redistribute source code or binary versions of the MacHTTP application that make use of
 * the MacHTTP name, logo, or icons without the expressed written consent of MacHTTP.Org
 * or Chuck Shotton.
 *
 * MacHTTP is a trademark of Chuck Shotton. Permission is granted
 * to MacHTTP.Org and its assignees use the MacHTTP name, logo, and icons.
 * Any use not authorized by MacHTTP.Org or Chuck Shotton is prohibited.
 *
 * Additional information can be found at http://www.machttp.org/
 *
 ******************************************************
 * Modifications:
 *
 * 11/09/01 - cshotton - initial version
 * 11/17/01 - rpatters1 - modernized and de-linted
 * 11/19/01 - rpatters1 - made MPW-compatibile
 *
 * Description:
 *
 * This file contains a skeletal implementation of link-time extentions to MacHTTP.
 * This framework allows custom filter functions and/or action handlers to be linked into
 * MacHTTP as if they were static plug-ins. This is useful for building custom versions
 * of MacHTTP tailored to implement dedicated server types.
 ******************************************************/
 
#include "config.h"

#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <cstring>

#include <MacWindows.h>
#include <Files.h>
#include <Threads.h>

#include "MacTCPCommonTypes.h"
#include "TCPPB.h"
#include "TCPHi.h"
#include "constants.h"
#include "global_types.h"
#include "http.h"
#include "HTTP_Response.h"
#include "TTY_Messages.h"
#include "Plugin.h"
#include "x10tools_i.h"

//X10Events.h
#define X10FOLDER ":X10Tools:"
#define X10FOLDERURL "/X10Tools/"
#define X10PUBLIC "Public.X10"

void X10Image (TCPStreamPtr pb, char *unit, char *arg, char *next, Boolean isService);
void X10Set (TCPStreamPtr pb,  char *unit, char *arg, char *next, short mode, Boolean isService);
void X10Dim (TCPStreamPtr pb,  char *unit, char *arg, char *next, short mode, Boolean isService);
void X10Lights (TCPStreamPtr pb,  char *unit, char *arg, char *next, short mode, Boolean isService);
void X10Units (TCPStreamPtr pb,  char *unit, char *arg, char *next, short mode, Boolean isService);
void X10Toggle (TCPStreamPtr pb,  char *unit, char *next, short mode, Boolean isService);
void X10Value (TCPStreamPtr pb,  char *unit, char *next, short mode, Boolean isService);

#define MYACTION 	"X10Tools"
#define kMySuffix	".X10"							// normal X10 functions
#define kMyPSuffix	".PX10"							//"public" X10 functions
#define MYMIME		"text/html"
#define MYINFO		"X10Tools provides a Web interface to the XTension home automation software."

//----------------------

typedef void (*FunctionPtr) (TCPStreamPtr pb, char *data); //used in CallService below

#define VERSION_STRING "\rX10Tools Plug-in, Copyright �1998, Chuck Shotton, BIAP Systems, Inc. All rights reserved.\r"

#define MyPlugInAction 	"X10Tools"					//up to 31 char action name for W* suffix
													//mapping transfer type. Must be unique.
													
#define MyPlugInName 	"X10Tools"				  	//up to 31 char unique ID for your plug-in
													//must conform to same rules as Action paths
													
#define MyVersionNumber "1.0"						//version of this plug-in
#define MyAdminURLPath	"/pi_admin.X10"			//path portion ONLY of a URL to invoke your plug-in's

#define kMySuffix	".X10"							// normal X10 functions
#define kMyPSuffix	".PX10"							//"public" X10 functions

typedef enum {toff, ton, tx10image, tx10set, tx10dim, tx10lights, tx10units, tx10toggle, tx10command, 
				tx10value, tunit, targ, tnext, tmode, tdirect, tredirect, tlast} TTokenType;
char *token [tlast] = {"OFF", "ON", "IMAGE", "SET", "DIM", "LIGHTS", "UNITS", "TOGGLE", "COMMAND",
				"VALUE","UNIT", "ARG", "NEXT", "MODE", "DIRECT", "REDIRECT"};

#define PUBLIC_BUFFER_SIZE 4096
char publicBuffer [PUBLIC_BUFFER_SIZE+2];

// Local routine prototypes
static OSErr CreateAndSendHTTPResponse (TCPStreamPtr pb);
static OSErr MyInit ();
static OSErr MyShutdown ();
static char *MyGetParameterValue (TCPStreamPtr pb, OSType which, char *buffer, unsigned long *dsize);

void ExecuteCommand (TCPStreamPtr pb, TTokenType command, char *unit, char *arg, char *next, TTokenType mode, Boolean isService, short isPublicURL);
void ParseArgs (char *s, TTokenType *command, char *unit, char *arg, 
				char *next, TTokenType *mode);
OSErr X_SendHTTPData (TCPStreamPtr pb, void *data, long dataLen);

/*********************************************/
/* X10Plugin_Register
 * This routine is called once on start-up, allowing the plug-in code to register itself via action
 * and suffix mapping definitions.
 */
 
void X10Plugin_Register () {
	
	OSErr err = noErr;
	
	ActionPtr act = NULL;
	
	act = HTTP_AddAction (MYACTION, MYACTION, A_ACTION, FALSE, MYINFO);
}

/*********************************************/
/* Plugin_Init
 * This routine is called once on start-up, allowing the plug-in code to register itself via action
 * and suffix mapping definitions.
 */
 
void X10Plugin_Init () {
	
	OSErr err = noErr;
	
	err = MyInit ();
}

/*********************************************/
/* Plugin_Filter
 * This routine is called for every incoming HTTP request, after the request has been read and parsed but
 * before it has been processed. This allows you to rewrite, modify, or otherwise manage the interpretation
 * of the request prior to turning it over to MacHTTP for processing.
 */
 
void X10Plugin_Filter (TCPStreamPtr PARM_UNUSED(stream)) {
	//do nothing in this sample
}

/*********************************************/
/* Plugin_Action
 * Called to process actions handled by this plug-in. This code is responsible for generating the entire HTTP
 * response header and results.
 */
 
unsigned long X10Plugin_Action (TCPStreamPtr stream, PluginRole role) {

	OSErr err;
	unsigned long bytes = 0;
	
	if (role == Plugin_Standard_Role)
		err = CreateAndSendHTTPResponse (stream);
	
	return bytes;
}

/*********************************************/
/* Plugin_Shutdown
 * Called to perform one time clean-up before MacHTTP terminates.
 */
 
void X10Plugin_Shutdown () {
	MyShutdown ();
}

/*********************************************/
/* Plugin_Idle
 * Called periodically to allow the plug-in module to perform housekeeping tasks as necessary. Long duration operations
 * should yield to other threads as required. Invoked from the main MacHTTP thread, so the UI will be blocked until
 * processing here is complete.
 */
 
void X10Plugin_Idle () {
	//do nothing in this sample
	//YieldToAnyThread();
}

//-------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------

//X10 plug-in
/*
X10 plug-in accepts URLs like:
	image.x10$unit%20name?arguments
	
	where path args are the the unit name and search args are the parameters.
	The file name root is the command to perform.
	
	Valid file roots are:
		X10image		- return the appropriate image (on or off) for a unit
						  path args are the unit name
		X10set			- turn a given unit on/off by name - path is unit name, on/off. search is next file.
		X10lights		- turn on/off all lights - path is the house code, on/off. search is next file.
		X10units		- turn off all units - path is the house code, on/off. search is next file
		X10command		- search or post is:
							command=<cmd>&unit=<unit>&arg=<val>&next=<complete_url>&mode=<mode>
							<cmd> ::= SET | DIM | LIGHTS | UNITS | TOGGLE | IMAGE
							<unit> ::= house code | unit name
							<arg> ::= ON | OFF | number
							<next> ::= url | local file path
							<mode> ::= REDIRECT | DIRECT
*/

/******************************** Globals *******************************************/
/* 
You may define your own global variables here, but they are global across all
threads of execution, so you'll need to use semaphores to control concurrent access.
*/

char *header = "HTTP/1.0 200 OK\r\nMIME-Version: 1.0\r\nServer: MacHTTP\r\nContent-type: text/html\r\n\r\n";
char *forbiddenHeader = "HTTP/1.0 403 Forbidden\r\nMIME-Version: 1.0\r\nServer: MacHTTP\r\nContent-type: text/html\r\n\r\nAccess Denied.";
static char hostname [256], port [16];

short myResRef = 0;	//the resource file ref for the code fragement's resources

/******************************** Functions *****************************************/
/*
WSAPI_Dispatch:
This is the only subroutine you are REQUIRED to implement. It is called from the main
routine in the WSAPI_Lib and you are passed a pointer to a CommandPB structure as defined 
in WSAPI.h
*/

#if 0
OSErr WSAPI_Dispatch (TCPStreamPtr commandPtr);
OSErr WSAPI_Dispatch (TCPStreamPtr commandPtr)
{
OSErr err = noErr;
char s[80];
	//check that the API versions match
	if (0 /*commandPtr->api_version < WSAPI_VERSION*/) {
		//this *may* be a problem. You'll have to decide in the future
		return WSAPI_E_MessageNotHandled;
	}
	else { 
		switch (commandPtr->command) {
			case WSAPI_Register:
				//return plug-in name and abilities, register actions and suffixes.
				
				//your code must make at least one of the following WSAPI_RegisterAction calls or 
				//there's no way for WebSTAR to pass CGI requests to your plug-in
				
				if (err = WSAPI_RegisterAction (commandPtr, MyPlugInAction, MyPlugInName))
					//this was a bad thing. Do something smart instead of just printin a message.
					TTY_WriteMessage ("X10Tools: Couldn't register the action.", 1);
					
				if (err = WSAPI_RegisterSuffix (commandPtr, MyPlugInAction, kMySuffix, '*   ', '*   ', "text/html"))
					TTY_WriteMessage ("X10Tools: Couldn't register the suffix.");

				if (err = WSAPI_RegisterSuffix (commandPtr, MyPlugInAction, kMyPSuffix, '*   ', '*   ', "text/html"))
					TTY_WriteMessage ("X10Tools: Couldn't register the suffix.", 1);

				//finally, fill in info about the plug-in itself
				strcpy (commandPtr->param.init.pluginName, MyPlugInName);
				strcpy (commandPtr->param.init.version, MyVersionNumber);
				strcpy (commandPtr->param.init.adminURL, MyAdminURLPath);
				break;
				
			case WSAPI_Init:
				//set up global data, resources, etc.
				err = MyInit (commandPtr);
				break;
				
			case WSAPI_Shutdown:
				//deallocate memory, close files, etc.
				err = MyShutdown (commandPtr);
				break;
				
			case WSAPI_Idle:
				//do any global processing on a regular basis here, outside the context of a
				// specific connection with a HTTP client.
				WSAPI_DisplayMessage (commandPtr, "X10Tools: It's alive!!!");
				//commandPtr->param.idle.ticksToSleep = idlet; //sleep for 5 more seconds
				break;
				
			case WSAPI_Run:
				//main processing entry point. Do your CGI-like processing here.

				// if we're running as a post processor (or security or logging role), there's no client
				//   to talk to, so let's just put a message on the WebSTAR screen to prove we got called
				if (commandPtr->param.run.role == WSAPI_PostProcessor_Role || 
						commandPtr->param.run.role == WSAPI_Security_Role ||
						commandPtr->param.run.role == WSAPI_Logging_Role ) {
					
//					sprintf (s, "demo-plugin called with role: %s", roles [commandPtr->param.run.role]);
//					WSAPI_DisplayMessage (commandPtr, s);
				}
				else { //build some sort of response for the client
					err = CreateAndSendHTTPResponse (commandPtr);
				}
				break;
				
			case WSAPI_Emergency:
				//bad things are going on inside WebSTAR. Free up memory, disk space, etc.
				break;
				
			case WSAPI_ServerStateChanged:
				break;
			
			case WSAPI_AccessControl:
				break;
				
			case WSAPI_Filter:
				break;
				
			case WSAPI_UIActivate:
				WSAPI_DisplayMessage (commandPtr, VERSION_STRING);
				break;

			default:
				sprintf (s, "X10Tools: received bad message, %d", commandPtr->command);
				WSAPI_DisplayMessage (commandPtr, s);
				return WSAPI_E_MessageNotHandled;
		}
	}
	
	return err;
}
#endif

/*********************************************************************/

OSErr X_SendHTTPData (TCPStreamPtr pb, void *data, long dataLen)
{
OSErr err = noErr;

	if (pb->state == closed) { /*The ASR must've done this. Client is gone, clean up.*/
//		LogStopWriting (pb);
		return -1;
	}
	else {
		err = SendData (pb->stream, data, dataLen, false);
		return err;
	}
}

/********************************************/
// Perform plug-in specific initializations

static OSErr MyInit ()
{
//short oldres;
//Handle h;
char s[256];
//OSErr err;
//unsigned long dsize;
unsigned short pnum;
FILE *f;
short i,j;
//char *test = NULL;

// ignore GIF/resource code for now. Use files on disk instead.

//	myResRef = pb->param.init.resRef;	//save the resource reference number for future use
	
	LogHostName(hostname);
	pnum = kHTTPPort;
	
	if (pnum == 80)
		port [0] = '\0';
	else
		sprintf (port, ":%hu", pnum);
	
	//grab some plug-in specific resources -- Mac-specific
/*	oldres = CurResFile();
	UseResFile (myResRef);
	if (ResError() == noErr) {
	}
	else {
	}
	UseResFile (oldres);
*/	
	//get the buffer of public unit names
	sprintf (s, "%s%s", X10FOLDER, X10PUBLIC);
	if (f=fopen (s, "r")) {
		i = fread (publicBuffer, 1, PUBLIC_BUFFER_SIZE, f);
		publicBuffer [i] = '\0';
		fclose (f);
		
		for (j=0;j<i;j++)
			publicBuffer [j] = toupper (publicBuffer [j]);
	}
	else
		TTY_WriteMessage ("\rUnable to find Public.X10 security file.", 1);
	
	return noErr;
}

/********************************************/
// Perform plug-in specific shutdown

static OSErr MyShutdown ()
{
	return noErr;
}

#if 0
/********************************************/
// ## Retrieve the string data for a specific parameter
// Warning! This routine is for demo purposes only and will crash if you extract data
//  from a descriptor that is larger than the buffer you pass in. If you care, you should
//  fix this!!!

static char *MyGetParameterValue (TCPStreamPtr pb, OSType which, char *buffer, unsigned long *dsize)
{
WSAPI_DescPtr d;
OSType dtype;
WSAPI_ErrorCode err;
char s[32];
	buffer [0] = '\0';
	
	//get the actual parameter data
	err = WSAPI_GetParameter (pb, which, &d);
	if (err == WSAPI_I_NoErr) {
		//pull the data out of the descriptor and copy it to the buffer var
		err = WSAPI_GetDescriptor (pb, d, &dtype, buffer, dsize);
		if (err != WSAPI_I_NoErr)
			WSAPI_DisplayMessage (pb, "X10Tools: Error getting data from descriptor");
		else {
			//if this is character data, make sure a null is on the end of the buffer.
			if (dtype == typeChar)
				buffer [*dsize] = '\0';
		}
		//dispose of the descriptor
		err = WSAPI_DisposeDescriptor (pb, &d);
		if (err != WSAPI_I_NoErr) {
			sprintf (s, "Dispose error %d", err);
			WSAPI_DisplayMessage (pb, s);
		}
			
		return buffer;	
	}
	else {
		WSAPI_DisplayMessage (pb, "X10Tools: Error getting parameter");
		sprintf (s, "Parameter : %4.4s", (char *) &which);
		WSAPI_DisplayMessage (pb, s);
		return NULL;
	}

}
#endif

/********************************************/

TTokenType FindToken (char *t);
TTokenType FindToken (char *t) 
{
TTokenType i;
int j, len;
	len = strlen (t);
	for (j=0; j<len;j++)
		t[j] = toupper (t[j]);
		
	for (i=toff; i<tlast; i++)
		if (!strcmp (t, token [i]))
			break;
	return i;
}

/*********************************************/

static unsigned char HexChar (unsigned char c);
static unsigned char HexChar (unsigned char c)
{
char *hex = "0123456789ABCDEF";
short k;
	c=toupper(c);
	for (k=0;k<16;k++) 
		if (c==hex[k]) return k;
	return 0;
}

/*********************************************/

void UpperCase (char *s);
void UpperCase (char *s)
{
	while (*s) {
		*s = toupper (*s);
		s++;
	}
}

/*********************************************/


void DecodeString (char *str);
void DecodeString (char *str)
{
char temp[512];
short i,j;
unsigned char bite;
	i=j=0;
	while (str[i] && j<512) {
		if (str[i]=='+') {
			i++;
			temp [j++] = ' ';
		}
		else if (str[i]=='%') {
			i++;
			bite = HexChar(str[i++])<<4;
			bite += HexChar(str[i++]);
			temp[j++] = bite;
		}
		else temp[j++] = str[i++];
	}
	temp[j]='\0';
	strcpy (str,temp);
}

/********************************************/

void ParseArgs (char *s, TTokenType *command, char *unit, char *arg, 
				char *next, TTokenType *mode)
{
char token [256];
short done=false;
int i=0,j;
int len = strlen (s);
TTokenType t;
	unit [0] = arg [0] = next [0] = '\0';
	*command = *mode = 0;
	
	while (i<len) {
		//extract a token
		j=0;
		while (s [i] != '=' && i<len)
			token [j++] = s [i++];
		token [j] = '\0';
		if (s[i] == '=')
			i++;
		
		t = FindToken (token);
		
		j=0;
		while (s [i] != '&' && i<len)
			token [j++] = s [i++];
		token [j] = '\0';
		if (s[i] == '&')
			i++;
		
		switch (t) {
			case tx10command:
				*command = FindToken (token);
				break;
				
			case tunit:
				strncpy (unit, token, 254);
				break;
				
			case targ:
				strncpy (arg, token, 32);
				break;
			
			case tnext:
				strncpy (next, token, 254);
				break;
				
			case tmode:
				*mode = FindToken (token);
				break;
				
			default:
				break;
		}
	}
}

/********************************************/

short IsPublicUnit (char *unit);
short IsPublicUnit (char *unit)
{
short i;
	for (i=0;i<strlen (unit); i++)
		unit [i] = toupper (unit[i]);
		
	if (strstr (publicBuffer, unit))
		return true;
		
	return false;
}

/********************************************/

short IsPX10 (char *url);
short IsPX10 (char *url)
{
short i;
char temp [32], *s;

	s = strrchr (url, '.');
	if (s) {
		strcpy (temp, s);
		for (i=0;i<strlen (temp); i++)
			temp [i] = toupper (temp[i]);
		if (strcmp (temp, kMyPSuffix))
			return false;
		else
			return true;
	}
	else
		return false;
}

/********************************************/

void ReturnSecurityError (TCPStreamPtr pb, Boolean isService);
void ReturnSecurityError (TCPStreamPtr pb, Boolean isService)
{
OSErr err = noErr;

	if (isService) {
		err = X_SendHTTPData (pb, "X10Tools: FORBIDDEN", 19);
	}
	else {
		err = X_SendHTTPData (pb, forbiddenHeader, strlen (forbiddenHeader));
	}
}

/********************************************/

void ExecuteCommand (TCPStreamPtr pb, TTokenType command, char *unit, char *arg, char *next, TTokenType mode, Boolean isService, short publicURL)
{
TTokenType on = toff;
char temp [512];
short publicUnit = true;

	if (unit [0]) {
		DecodeString (unit);
		if (publicURL) {
			strcpy (temp, unit);
			publicUnit = IsPublicUnit (temp);
		}
	}
	
	switch (command) {
		//X10image		- return the appropriate image (on or off) for a unit
		//				  arg is the icon to use
		case tx10image:
			X10Image (pb, unit, arg, next, isService);
			break;
			
		//X10set		- turn a given unit on/off by name - arg is on/off
		case tx10set:
			UpperCase (arg);
			if (publicUnit)	
				X10Set (pb, unit, arg, next, (short) (mode-tdirect), isService);
			else
				ReturnSecurityError (pb, isService);
			break;
		
		//X10dim		- dim a unit to a specific value - arg is numeric value
		case tx10dim:
			if (publicUnit)	
				X10Dim (pb, unit, arg, next, (short) (mode-tdirect), isService);
			else
				ReturnSecurityError (pb, isService);
			break;
			
		//X10lights		- turn on/off all lights - arg is on/off
		case tx10lights:
			UpperCase (arg);
			if (publicUnit)	
				X10Lights (pb, unit, arg, next, (short) (mode-tdirect), isService);
			else
				ReturnSecurityError (pb, isService);
			break;
			
		//X10units		- turn off all units - arg is ignored
		case tx10units:
			if (publicUnit)	
				X10Units (pb, unit, arg, next, (short) (mode-tdirect), isService);
			else
				ReturnSecurityError (pb, isService);
			break;
			
		//X10toggle		- toggle a given unit on/off
		case tx10toggle:
			if (publicUnit)	
				X10Toggle (pb, unit, next, (short) (mode-tdirect), isService);
			else
				ReturnSecurityError (pb, isService);
			break;
			
		//X10value		- unit value
		case tx10value:
			X10Value (pb, unit, next, (short) (mode-tdirect), isService);
			break;
			
		default:
			//not a valid command
			break;
	}
}

/********************************************/
// Build a HTTP response and send it back


static OSErr CreateAndSendHTTPResponse (TCPStreamPtr pb)
{
char s[512], unit [256], arg [34], next [256];
unsigned long dsize;
OSErr err = noErr;
TTokenType command, mode;
short isPX10 = false;

	dsize = sizeof (s)-1;
	safecpy (s, pb->url_fname, dsize);	//get the base file path out of the URL
	
	isPX10 = IsPX10 (s);
	
	dsize = sizeof (s)-1;
	safecpy (s, pb->search_args, dsize);	//get the search args out of the URL
	
	ParseArgs (s, &command, unit, arg, next, &mode);
	
	ExecuteCommand (pb, command, unit, arg, next, mode, false, isPX10);
	
	return err;
}

//***********************************************************************************
//***********************************************************************************
//***********************************************************************************
//***********************************************************************************
// Old X10Events.c included below
//***********************************************************************************

#define APP_SIG			'SHEx'
#define EVENT_SUITE		'xten'
#define EVENT_STATUS	'chek'
#define EVENT_VALUE		'Valu'
#define EVENT_TURNON	'tron'
#define EVENT_TURNOFF	'toff'
#define EVENT_DIM		'dimm'
#define EVENT_ALLON		'Alon'
#define EVENT_ALLOFF	'Alof'
#define EVENT_ALLUOFF	'AUof'
#define KEYWORD_DIMTO	'dmlv'

char *gifHeader = "HTTP/1.0 200 OK\r\nMIME-Version: 1.0\r\nServer: MacHTTP\r\nContent-type: image/gif\r\nPragma: No-Cache\r\nExpires: Thu, 01 Dec 1994 16:00:00 GMT\r\n\r\n";
char *htmlHeader = "HTTP/1.0 200 OK\r\nMIME-Version: 1.0\r\nServer: MacHTTP\r\nContent-type: text/html\r\nPragma: No-Cache\r\nExpires: Thu, 01 Dec 1994 16:00:00 GMT\r\n\r\n";
char *errHeader = "HTTP/1.0 404 File Not Found\r\nMIME-Version: 1.0\r\nServer: MacHTTP\r\nContent-type: text/html\r\nPragma: No-Cache\r\nExpires: Thu, 01 Dec 1994 16:00:00 GMT\r\n\r\nFile Not Found.";

short sendEventBusy = false;

extern OSErr X_SendHTTPData (TCPStreamPtr pb, void *data, long dataLen);

/***************************************************/

static unsigned short X10SendEvent (OSType sig, OSType suite, OSType eventCode,
					void *arg, long argLen, OSType argType,
					AEKeyword arg2key, void *arg2, long arg2Len, OSType arg2Type,
					void *data, long *dataLen, OSType dataType);

static unsigned short X10SendEvent (OSType sig, OSType suite, OSType eventCode,
					void *arg, long argLen, OSType argType,
					AEKeyword arg2key, void *arg2, long arg2Len, OSType arg2Type,
					void *data, long *dataLen, OSType dataType)
{
OSErr err = noErr;
AEDesc theAddress;
AppleEvent ourEvent,ourReply;
DescType typeCode;
unsigned short ok=false;
char s[256];

//critical section
	while (sendEventBusy)
		YieldToAnyThread ();
	sendEventBusy = true;

	//Get the unit status
	err = AECreateDesc(typeApplSignature, (Ptr) &sig, sizeof(sig), &theAddress);

	if (!err)
		err = AECreateAppleEvent(suite, eventCode, &theAddress, kAutoGenerateReturnID, 
    			kAnyTransactionID, &ourEvent);
    else
    	TTY_WriteMessage ("X10: Error Creating AE address", 1);
    	
    if (!err)
    	err = AEPutParamPtr(&ourEvent, keyDirectObject, argType, arg, argLen);
    else
    	TTY_WriteMessage ("X10: Error Creating AE", 1);

    if (!err) {
    	if (arg2)
    		err = AEPutParamPtr(&ourEvent, arg2key, arg2Type, arg2, arg2Len);
    }
    else
    	TTY_WriteMessage ("X10: Error inserting direct param", 1);

    if (!err)
		err=AESend(&ourEvent, &ourReply, kAECanInteract + kAEWaitReply + kAECanSwitchLayer, kAENormalPriority,
               kAEDefaultTimeout,/*(IdleProcPtr)*/nil , nil);
    else
    	TTY_WriteMessage ("X10: Error inserting secondary param", 1);
    
    if (err)
    	TTY_WriteMessage ("X10: Error sending event", 1);
    
    //extract the direct param from the reply if necessary
    if (data != NULL) {
		if (!err) 
    		err = AEGetParamPtr( &ourReply, keyDirectObject, dataType, &typeCode,
					(Ptr) data, *dataLen, dataLen );
   	 else
    		TTY_WriteMessage ("X10: Error waiting for reply", 1);
    }
    
    if (!err) {
    	ok = true;
	}
    else {
    	sprintf (s, "X10: Error extracting direct param err=%d", err);
    	TTY_WriteMessage (s, 1);
    }
    	
    //get rid of the address descriptor if necessary
    err = AEDisposeDesc (&theAddress);
    err = AEDisposeDesc (&ourEvent);
    err = AEDisposeDesc (&ourReply);
    
    sendEventBusy = false;
//end critical section
    
    return ok;
}

/***************************************************/
char *redirectHeader = "HTTP/1.0 302 Found\r\nLocation: ";

void RedirectFile (TCPStreamPtr pb, char *next, short ok);
void RedirectFile (TCPStreamPtr pb, char *next, short ok)
{
char filename [512];
OSErr err = noErr;
	//sprintf (filename, "%shttp://%s%s%s%s%s\r\n\r\n", redirectHeader, hostname, port, X10FOLDERURL, next, ok ? "_OK.html" : "_ERR.html");
	strcpy (filename, redirectHeader);
	strcat (filename, "http://");
	strcat (filename, hostname);
	strcat (filename, port);
	strcat (filename, X10FOLDERURL);
	strcat (filename, next);
	if (ok)
		strcat (filename, "_OK.html\r\n\r\n");
	else
		strcat (filename, "_ERR.html\r\n\r\n");
		
	err = X_SendHTTPData (pb, filename, strlen (filename));
	//WSAPI_DisplayMessage (pb, filename);
}	
	
/***************************************************/
#define READ_SIZE 4096

void ReturnFile (TCPStreamPtr pb, char *next, short mode, short ok);
void ReturnFile (TCPStreamPtr pb, char *next, short mode, short ok)
{
char filename [256];
FILE *f;
char *buffer;
size_t len;
OSErr err = noErr;

	if (mode) {
		RedirectFile (pb, next, ok);
		return;
	}
	

	sprintf (filename, "%s%s%s", X10FOLDER, next, ok ? "_OK.html" : "_ERR.html");
	buffer = NewPtr (READ_SIZE);
	if (buffer) {
		f = fopen (filename, "rb");
		if (f) {
			err = X_SendHTTPData (pb, htmlHeader, strlen (htmlHeader));
			while (!feof(f) && !err) {
				len = fread (buffer, 1, READ_SIZE, f);
				if (len>0)
					err = X_SendHTTPData (pb, buffer, len);
			}
			fclose (f);
		}
		else {
			err = X_SendHTTPData (pb, errHeader, strlen (errHeader));
		}
		
		DisposePtr (buffer);
	}
	else {
		err = X_SendHTTPData (pb, errHeader, strlen (errHeader));
	}

}

/***************************************************/

OSErr ReturnGIFFile (TCPStreamPtr pb, char *next);
OSErr ReturnGIFFile (TCPStreamPtr pb, char *next)
{
char filename [256];
FILE *f;
char *buffer;
size_t len;
OSErr err = noErr;

	sprintf (filename, "%s%s.gif", X10FOLDER, next);
	buffer = NewPtr (READ_SIZE);
	if (buffer) {
		f = fopen (filename, "rb");
		if (f) {
			err = X_SendHTTPData (pb, gifHeader, strlen (gifHeader));
			while (!feof(f) && !err) {
				len = fread (buffer, 1, READ_SIZE, f);
				if (len>0)
					err = X_SendHTTPData (pb, buffer, len);
			}
			fclose (f);
		}
		else {
			err = X_SendHTTPData (pb, errHeader, strlen (errHeader));
			return -1;
		}
		
		DisposePtr (buffer);
	}
	else {
		err = X_SendHTTPData (pb, errHeader, strlen (errHeader));
		return -1;
	}
	
	return noErr;
}

/***************************************************/

void X10Image (TCPStreamPtr pb, char *unit, char *arg, char *next, Boolean isService)
{
Boolean stat = false, ok=false;
long statSize = sizeof(stat);
char s [256];
OSErr err = noErr;
Handle h = (Handle) NULL;

	ok = X10SendEvent (APP_SIG, EVENT_SUITE, EVENT_STATUS, unit, strlen (unit), typeChar,
						'****', NULL, 0, '****',
						&stat, &statSize, typeBoolean);
						
	//Find the resource matching the unit name
	if (ok) {
		
		if (isService) {
			//return a file name
			sprintf (s, "%s%s%s", X10FOLDERURL,arg, stat ? ".on.gif" : ".off.gif");
			err = X_SendHTTPData (pb, s, strlen (s));
			return;
		}
		else {
			sprintf (s, "%s%s", arg, stat ? ".on" : ".off");
		}
		
		err = ReturnGIFFile (pb, s);
		if (err) {
			TTY_WriteMessage ("X10Tools: no such image.",1);
		}
	}
}

/***************************************************/

void X10Set (TCPStreamPtr pb,  char *unit, char *arg, char *next, short mode, Boolean isService)
{
Boolean ok=false;
OSType evt;
	evt = strcmp (arg, "OFF") ? EVENT_TURNON : EVENT_TURNOFF;

	ok = X10SendEvent (APP_SIG, EVENT_SUITE, evt, unit, strlen (unit), typeChar,
						'****', NULL, 0, '****',
						NULL, 0, typeBoolean);
						
	if (!isService)
		ReturnFile (pb, next, mode, ok);
}

/***************************************************/

void X10Dim (TCPStreamPtr pb,  char *unit, char *arg, char *next, short mode, Boolean isService);
void X10Dim (TCPStreamPtr pb,  char *unit, char *arg, char *next, short mode, Boolean isService)
{
Boolean ok=false;
OSType evt=EVENT_DIM;
short v;
	v = atoi (arg);
	ok = X10SendEvent (APP_SIG, EVENT_SUITE, evt, unit, strlen (unit), typeChar,
						KEYWORD_DIMTO, &v, sizeof (v), typeSMInt,
						NULL, 0, typeBoolean);
						
	if (!isService)
		ReturnFile (pb, next, mode, ok);
}

/***************************************************/


void X10Lights (TCPStreamPtr pb,  char *unit, char *arg, char *next, short mode, Boolean isService)
{
Boolean ok=false;
OSType evt;
	evt = strcmp (arg, "OFF") ? EVENT_ALLON : EVENT_ALLOFF;

	ok = X10SendEvent (APP_SIG, EVENT_SUITE, evt, unit, strlen (unit), typeChar,
						'****', NULL, 0, '****',
						NULL, 0, typeBoolean);
						
	if (!isService)
		ReturnFile (pb, next, mode, ok);
}

/***************************************************/


void X10Units (TCPStreamPtr pb,  char *unit, char *arg, char *next, short mode, Boolean isService)
{
Boolean ok=false;
OSType evt = EVENT_ALLUOFF;

	ok = X10SendEvent (APP_SIG, EVENT_SUITE, evt, unit, strlen (unit), typeChar,
						'****', NULL, 0, '****',
						NULL, 0, typeBoolean);
						
	if (!isService)
		ReturnFile (pb, next, mode, ok);
}


/***************************************************/


void X10Toggle (TCPStreamPtr pb,  char *unit, char *next, short mode, Boolean isService)
{
Boolean stat = false, ok=false;
long statSize = sizeof(stat);
char s [256];
OSErr err = noErr;
OSType evt;

	ok = X10SendEvent (APP_SIG, EVENT_SUITE, EVENT_STATUS, unit, strlen (unit), typeChar,
						'****', NULL, 0, '****',
						&stat, &statSize, typeBoolean);
	
	if (ok) {
		X10Set (pb, unit, stat ? "OFF":"ON", next, mode, isService);
	}
	else {
		if (!isService)
			ReturnFile (pb, next, mode, ok);
	}
}

/***************************************************/


void X10Value (TCPStreamPtr pb,  char *unit, char *next, short mode, Boolean isService)
{
short stat = 0;
Boolean ok=false;
long statSize = sizeof(stat);
char s [256];
OSErr err = noErr;
OSType evt;

	ok = X10SendEvent (APP_SIG, EVENT_SUITE, EVENT_VALUE, unit, strlen (unit), typeChar,
						'****', NULL, 0, '****',
						&stat, &statSize, typeSMInt);
	
	if (isService) {
		if (ok) {
			sprintf (s, "%hd", stat);
			err = X_SendHTTPData (pb, s, strlen (s));
		}
		else {
			sprintf (s, "Error: Unit %s not valid.", unit);
			err = X_SendHTTPData (pb, s, strlen (s));
		}
	}
	else {
		ReturnFile (pb, next, mode, ok);
	}
}

