/*SSI_Plugin.c*/
/******************************************************
 *
 * Lawyer stuff:
 *
 * MacHTTP 2.x, source code
 * Copyright �1993-2001 Chuck Shotton
 * All Rights Reserved.
 *
 * This source code is made available under the terms of the MacHTTP Source License.
 * This license grants you the right to use the source code to create new versions
 * of and derivative works from the original MacHTTP source code. Under the terms of
 * this license, any modifications made to the source code must be made available in
 * source code form to the general public and the MacHTTP.Org organization. You may not
 * redistribute source code or binary versions of the MacHTTP application that make use of
 * the MacHTTP name, logo, or icons without the expressed written consent of MacHTTP.Org
 * or Chuck Shotton.
 *
 * MacHTTP is a trademark of Chuck Shotton. Permission is granted
 * to MacHTTP.Org and its assignees use the MacHTTP name, logo, and icons.
 * Any use not authorized by MacHTTP.Org or Chuck Shotton is prohibited.
 *
 * Additional information can be found at http://www.machttp.org/
 *
 ******************************************************
 * Modifications:
 *
 * 07/30/02 - cshotton - initial version
 *
 * Description:
 *
 * This file contains a skeletal implementation of link-time extentions to MacHTTP.
 * This framework allows custom filter functions and/or action handlers to be linked into
 * MacHTTP as if they were static plug-ins. This is useful for building custom versions
 * of MacHTTP tailored to implement dedicated server types.
 ******************************************************/
 
#include "config.h"

#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <cstring>

#include <MacWindows.h>
#include <Files.h>
#include <Threads.h>

#include "MacTCPCommonTypes.h"
#include "TCPPB.h"
#include "TCPHi.h"
#include "constants.h"
#include "global_types.h"
#include "http.h"
#include "HTTP_Response.h"
#include "TTY_Messages.h"
#include "Plugin.h"
#include "ssi_plugin.h"


#define MYACTION 	"SSI"
#define kMySuffix	".SSI"
#define MYMIME		"text/html"
#define MYINFO		"Server side include processing for HTML files"

//----------------------

typedef void (*FunctionPtr) (TCPStreamPtr pb, char *data); //used in CallService below

#define VERSION_STRING "\rSSI Plug-in, Copyright �2002, Chuck Shotton, MacHTTP.Org. All rights reserved.\r"

#define MyPlugInAction 	MYACTION					//up to 31 char action name for W* suffix
													//mapping transfer type. Must be unique.
													
#define MyPlugInName 	MYACTION				  	//up to 31 char unique ID for your plug-in
													//must conform to same rules as Action paths
													
#define MyVersionNumber "1.0"						//version of this plug-in
#define MyAdminURLPath	"/pi_admin.SSI"			//path portion ONLY of a URL to invoke your plug-in's

typedef enum {texec, tlast} TTokenType;
char *token [tlast] = {"EXEC"};

#define READ_BUFFER_SIZE 8192

#define SSI_TAG_START 	"<!--#"
#define SSI_TAG_END   	"-->"
#define SSI_TAG_LEN		512
#define SSI_TOKEN_LEN	32

typedef struct {
	short lookingForStart;
	unsigned short bufferLen;
	char *buffer;
	unsigned short tokenLen;
	char token [SSI_TOKEN_LEN];
} SSIState, *SSIStatePtr;


// Local routine prototypes
static unsigned long CreateAndSendHTTPResponse (TCPStreamPtr pb, SSIStatePtr state);
static OSErr MyInit ();
static OSErr MyShutdown ();

static unsigned long ExecuteCommand (TCPStreamPtr pb, TTokenType command, char *arg, SSIStatePtr state);
static OSErr X_SendHTTPData (TCPStreamPtr pb, void *data, long dataLen);
static unsigned long ReturnFile (TCPStreamPtr pb, char *fname, char *mode, SSIStatePtr state);

/*********************************************/
/* SSIPlugin_Register
 * This routine is called once on start-up, allowing the plug-in code to register itself via action
 * and suffix mapping definitions.
 */
 
void SSIPlugin_Register () {
	
	OSErr err = noErr;
	
	ActionPtr act = NULL;
	
	act = HTTP_AddAction (MYACTION, MYACTION, A_ACTION, FALSE, MYINFO);
}

/*********************************************/
/* SSIPlugin_Init
 * This routine is called once on start-up, allowing the plug-in code to register itself via action
 * and suffix mapping definitions.
 */
 
void SSIPlugin_Init () {
	
	OSErr err = noErr;
	
	err = MyInit ();
}

/*********************************************/
/* SSIPlugin_Filter
 * This routine is called for every incoming HTTP request, after the request has been read and parsed but
 * before it has been processed. This allows you to rewrite, modify, or otherwise manage the interpretation
 * of the request prior to turning it over to MacHTTP for processing.
 */
 
void SSIPlugin_Filter (TCPStreamPtr PARM_UNUSED(stream)) {
}

/*********************************************/
/* SSIPlugin_Action
 * Called to process actions handled by this plug-in. This code is responsible for generating the entire HTTP
 * response header and results.
 */

unsigned long SSIPlugin_Action (TCPStreamPtr stream, PluginRole role) {

	unsigned long bytes = 0;
	SSIStatePtr state = NULL;
	
	if (stream == NULL)
		return 0;
		
	if (stream->action == NULL)
		return 0;
		
	if (strcmp (stream->action->tag, MYACTION))
		return 0;
		
	if (role == Plugin_Standard_Role) {

		state = (SSIStatePtr) NewPtr (sizeof (SSIState));
		if (state != NULL) {
			state->lookingForStart = true;
			state->tokenLen = 0;
			state->token [0] = '\0';
			state->bufferLen = 0;
			state->buffer = (char *) NewPtr (SSI_TAG_LEN);
			
			if (state->buffer) {
				bytes = CreateAndSendHTTPResponse (stream, state);
				DisposePtr (state->buffer);
			}
			DisposePtr ((char *) state);
		}
	}
	
	return bytes;
}

/*********************************************/
/* SSIPlugin_Shutdown
 * Called to perform one time clean-up before MacHTTP terminates.
 */
 
void SSIPlugin_Shutdown () {
	MyShutdown ();
}

/*********************************************/
/* SSIPlugin_Idle
 * Called periodically to allow the plug-in module to perform housekeeping tasks as necessary. Long duration operations
 * should yield to other threads as required. Invoked from the main MacHTTP thread, so the UI will be blocked until
 * processing here is complete.
 */
 
void SSIPlugin_Idle () {
	//do nothing in this sample
	//YieldToAnyThread();
}

//-------------------------------------------------------------------------------------------------

/******************************** Globals *******************************************/
/* 
You may define your own global variables here, but they are global across all
threads of execution, so you'll need to use semaphores to control concurrent access.
*/

char *htmlHeader = "HTTP/1.0 200 OK\r\nMIME-Version: 1.0\r\nServer: MacHTTP\r\nContent-type: text/html\r\nPragma: No-Cache\r\nExpires: Thu, 01 Dec 1994 16:00:00 GMT\r\n\r\n";
char *errHeader = "HTTP/1.0 404 File Not Found\r\nMIME-Version: 1.0\r\nServer: MacHTTP\r\nContent-type: text/html\r\nPragma: No-Cache\r\nExpires: Thu, 01 Dec 1994 16:00:00 GMT\r\n\r\nFile Not Found.";

static char hostname [256], port [16];

short myResRef = 0;	//the resource file ref for the code fragement's resources


/*********************************************************************/

static OSErr X_SendHTTPData (TCPStreamPtr pb, void *data, long dataLen)
{
OSErr err = noErr;

	if (pb->state == closed) { /*The ASR must've done this. Client is gone, clean up.*/
//		LogStopWriting (pb);
		return -1;
	}
	else {
		err = SendData (pb->stream, data, dataLen, false);
		return err;
	}
}

/********************************************/
// Perform plug-in specific initializations

static OSErr MyInit ()
{
unsigned short pnum;

	LogHostName(hostname);
	pnum = kHTTPPort;
	
	if (pnum == 80)
		port [0] = '\0';
	else
		sprintf (port, ":%hu", pnum);
	TTY_WriteMessage ("\rSSI plug-in initialized.", 1);
	
	return noErr;
}

/********************************************/
// Perform plug-in specific shutdown

static OSErr MyShutdown ()
{
	return noErr;
}

/********************************************/

static TTokenType FindToken (char *t);
static TTokenType FindToken (char *t) 
{
TTokenType i;
int j, len;
	len = strlen (t);
	for (j=0; j<len;j++)
		t[j] = toupper (t[j]);
		
	for (i=texec; i<tlast; i++)
		if (!strcmp (t, token [i]))
			break;
	return i;
}

/*********************************************/

static unsigned char HexChar (unsigned char c);
static unsigned char HexChar (unsigned char c)
{
char *hex = "0123456789ABCDEF";
short k;
	c=toupper(c);
	for (k=0;k<16;k++) 
		if (c==hex[k]) return k;
	return 0;
}

/*********************************************/

static void UpperCase (char *s);
static void UpperCase (char *s)
{
	while (*s) {
		*s = toupper (*s);
		s++;
	}
}

/*********************************************/


static void DecodeString (char *str);
static void DecodeString (char *str)
{
char temp[512];
short i,j;
unsigned char bite;
	i=j=0;
	while (str[i] && j<512) {
		if (str[i]=='+') {
			i++;
			temp [j++] = ' ';
		}
		else if (str[i]=='%') {
			i++;
			bite = HexChar(str[i++])<<4;
			bite += HexChar(str[i++]);
			temp[j++] = bite;
		}
		else temp[j++] = str[i++];
	}
	temp[j]='\0';
	strcpy (str,temp);
}

/********************************************/

static unsigned long ExecuteCommand (TCPStreamPtr pb, TTokenType command, char *arg, SSIStatePtr state)
{
	switch (command) {
		//exec
		case texec:
			ReturnFile (pb, arg, "rb", state);
			break;
			
		default:
			//not a valid command
			break;
	}
	
	return 0;
}

/********************************************/
// Build a HTTP response and send it back


static unsigned long CreateAndSendHTTPResponse (TCPStreamPtr pb, SSIStatePtr state)
{
char s[512];

	strcpy (s, pb->mac_fname);
	
	return ReturnFile (pb, s, "rb", state);
}

/***************************************************/

static short ScanFor (SSIStatePtr state, char lookFor, char *buffer, size_t len, size_t *bptr);
static short ScanFor (SSIStatePtr state, char lookFor, char *buffer, size_t len, size_t *bptr)
{
	while (*bptr < len) {
		if (buffer [*bptr] == lookFor)
			return true;
		else
			*bptr = *bptr + 1;
	}
	return false;
}

/***************************************************/

static unsigned long SSI_Parse (TCPStreamPtr pb, char *buffer, size_t len, SSIStatePtr state);
static unsigned long SSI_Parse (TCPStreamPtr pb, char *buffer, size_t len, SSIStatePtr state) 
{
OSErr err = noErr;
size_t bptr = 0, ssi_start=0, ssi_end=0;
size_t lookLen=0;
char *lookFor = NULL;

	if (state->lookingForStart) {
		lookFor = SSI_TAG_START;
		lookLen = strlen (lookFor);
		do {
			if (ScanFor (state, lookFor [state->tokenLen], buffer, len, &bptr)) {
				state->tokenLen++;
				do {
					if (buffer [++bptr] == lookFor [state->tokenLen])
						state->tokenLen++;
					else {
						state->tokenLen = 0; //not our token, start over
						break;
					}
				} while (bptr < len && state->tokenLen < lookLen);
				bptr++;
				if (state->tokenLen == lookLen) {
					ssi_start = bptr;
					err = X_SendHTTPData (pb, buffer, bptr - lookLen);			
					err = X_SendHTTPData (pb, lookFor, lookLen);
					state->lookingForStart = false;
				}
			}
		
			if (!state->lookingForStart) {
				//looking for the end comment token
				lookFor = SSI_TAG_END;
				lookLen = strlen (lookFor);
				state->tokenLen = 0;
				if (ScanFor (state, lookFor [state->tokenLen], buffer, len, &bptr)) {
					state->tokenLen++;
					do {
						if (buffer [++bptr] == lookFor [state->tokenLen])
							state->tokenLen++;
						else {
							state->tokenLen = 0; //not our token, start over
							break;
						}
					} while (bptr < len && state->tokenLen < lookLen);
					bptr++;
					if (state->tokenLen == lookLen) {
						ssi_end = bptr;
						state->bufferLen = (bptr-lookLen) - ssi_start;
						if (state->bufferLen>=SSI_TAG_LEN)
							state->bufferLen = SSI_TAG_LEN - 1;
						strncpy (state->buffer, &buffer [ssi_start], state->bufferLen);
						err = X_SendHTTPData (pb, state->buffer, state->bufferLen);		
						err = X_SendHTTPData (pb, lookFor, lookLen);
						state->lookingForStart = true;
					}
				}
			}
		} while (bptr < len);
	}
	else {
	}

//	err = X_SendHTTPData (pb, &buffer [bptr], len-bptr);
	
	return len;
}

/***************************************************/

static unsigned long ReturnFile (TCPStreamPtr pb, char *fname, char *mode, SSIStatePtr state)
{
char filename [256];
FILE *f;
char *buffer;
size_t len;
OSErr err = noErr;
unsigned long bytes = 0;

	sprintf (filename, "%s", fname);
	buffer = NewPtr (READ_BUFFER_SIZE);
	if (buffer) {
		f = fopen (filename, mode);
		if (f) {
			err = X_SendHTTPData (pb, htmlHeader, strlen (htmlHeader));
			while (!feof(f) && !err) {
				len = fread (buffer, 1, READ_BUFFER_SIZE, f);
				if (len>0) {
					bytes += SSI_Parse (pb, buffer, len, state);
				}
			}
			fclose (f);
		}
		else {
			err = X_SendHTTPData (pb, errHeader, strlen (errHeader));
		}
		
		DisposePtr (buffer);
	}
	else {
		err = X_SendHTTPData (pb, errHeader, strlen (errHeader));
	}
	return bytes;
}